# Conversion Notes

Source: EBS Guidelines for Uganda_ May 2026.pdf (69 PDF pages).

This is a formatting conversion, not clinical approval or a change to national guidance. The PDF is authoritative. The damaged pasted extraction was not used as the primary source.

- One H1 document title; H2 front matter and chapters; nested H3–H5 sections.
- Tables, lists, references, signatures and diagrams are retained. Header/footer decorations are excluded. Source PDF page comments are provenance only, not verified clinical PDF mappings in MediGuide.
- The complex six-page Annex III framework is reproduced as high-resolution page images, not a searchable Markdown table. Its layout extraction split columns and damaged characters, so that transcription has deliberately not been used.
- The cover title and subtitle were verified visually. Likelihood percentages on printed page 16 and KPI targets on printed pages 33–34 were verified visually and repaired after font-encoding corruption. The signal form's “affected” was repaired from the visible source.
- Broken “Error! Bookmark not defined.” cross-reference artifacts were removed. Numeric superscript references are represented as bracketed numbers.
- The source's “Structure of the guidelines” describes eleven chapters, while the actual contents and chapter headings contain ten. This discrepancy is retained for editorial review rather than inventing or renumbering source content.
- Source spelling, duplicated headings and claims otherwise remain unchanged; this conversion does not certify publication readiness.

Keep the images folder beside the Markdown file. For MediGuide upload, import the images as managed assets and replace local image references with their managed URLs before regeneration, figure review and publication. The ZIP contains the Markdown, these notes and only the referenced images.
