# Alignment Notes

Source: National Mortality Surveillance Guidelines for Uganda.pdf (96 PDF pages), August 2025, first edition 2025, coverage 2025/26–2029/30.

The PDF was used as the authoritative source. The supplied pasted Markdown was not overwritten. It starts at section 1.0, omits the front matter and correct chapter structure, and contains hundreds of false headings created from fragmented table cells.

This version restores publication information, contents, front matter, six named chapters, references, Annex 1, figures and supporting matrices. Source-page comments identify every PDF page, but are not verified clinical page mappings in MediGuide.

There is one H1 document title, H2 chapters and front matter, and nested H3–H6 section headings. Chapter numbers and titles are combined into single headings. Original numbering and substantive wording are preserved. The PDF itself repeats section 1.11.8 and skips section 2.3.2; those source discrepancies are not silently corrected. References in the source to chapters not present in the document require editorial review.

The complex performance-indicator matrix (PDF pages 70–73) and tool/system matrices (77–91) are reproduced as high-resolution page images, rather than a misleading transcription of merged cells. These portions are not searchable Markdown text. Other tables retain extracted Markdown plus an exact source-page image for comparison. Diagrams and the original cover are included.

Keep the images folder beside the Markdown. The ZIP includes only referenced images, the Markdown and these notes. To publish in MediGuide, import images as managed assets, replace local image references with managed URLs, regenerate, and complete human clinical and figure review. This formatting alignment is not clinical approval.
