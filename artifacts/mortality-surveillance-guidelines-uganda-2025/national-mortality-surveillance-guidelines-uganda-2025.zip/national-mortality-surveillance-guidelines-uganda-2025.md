# National Mortality Surveillance Guidelines for Uganda

**Republic of Uganda — Ministry of Health**

**2025/26–2029/30**

**First edition: 2025 — August 2025**

<!-- Source PDF page 1 -->

![Original cover](images/cover.png)

<!-- Source PDF page 2 -->

## Publication Information

**National Mortality Surveillance Guidelines**

First edition: 2025

Published by the Ministry of Health, Republic of Uganda _._

Copies may be obtained from:

**Ministry of Health, Headquarters,**

Plot 6 Lourdel Road, P.O. Box 7272,

Kampala, Uganda.

Website: www.health.go.ug

© 2025 Ministry of Health, Republic of Uganda.

<!-- Source PDF page 3 -->

## TABLE OF CONTENTS

- LIST OF TABLES — page vi
- LIST OF FIGURES — page vii
- FOREWORD — page viii
- ACKNOWLEDGEMENT — page ix
- ABBREVIATIONS AND ACRONYMS — page xi
- GLOSSARY — page xiv
- CHAPTER ONE — page 1
- INTRODUCTION TO MORTALITY SURVEILLANCE AND RESPONSE — page 1
- 1.0. Background — page 1
- 1.1. Introduction — page 1
- 1.2 Problem Statement — page 2
- 1.3 Rationale for Establishing a Mortality Surveillance System — page 3
- 1.4 Scope — page 4
- 1.5 Goal — page 5
- 1.6 Guiding principles — page 5
- 1.7 Expected Outcomes and Impact of Mortality Surveillance — page 6
- 1.8 Process of Formulating the MS Guidelines (2025/26 - 2029/30) — page 6
- 1.9 Intended users of the guidelines — page 7
- 1.10 Implementation Experiences in Mortality Surveillance in Uganda — page 7
- 1.11 Examples of Experiences and lessons learned from disparate MS interventions — page 7
- CHAPTER TWO — page 13
- LEGAL AND ETHICAL CONSIDERATIONS FOR MORTALITY SURVEILLANCE — page 13
- 2.0 Introduction — page 13
- 2.1 Legal Frameworks Enabling Mortality Surveillance in Uganda — page 13
- 2.2 Non-Legal & Strategic Frameworks supporting MS in Uganda — page 14
- 2.3 Ethical Considerations for Mortality Surveillance in Uganda — page 14
- CHAPTER THREE — page 17
- IDENTIFICATION AND NOTIFICATION OF DEATH — page 17
- 3.1 Introduction — page 17
- 3.2 What is Death? — page 17
- 3.3 Identification of death — page 17
- 3.4 Notification of death — page 17
- 3.5 Tools for death identification and notification — page 19
- 3.6 Timeline for death notification — page 20
- 3.7 Death identification and notification in complex settings/situations — page 20
- 3.8 Identification and Notification of death in the Community — page 24
- CHAPTER FOUR — page 25

<!-- Source PDF page 4 -->

- REVIEWING OF ALL DEATHS — page 25
- 4.0 Introduction — page 25
- 4.1 Which Deaths Should Be Reviewed — page 25
- 4.2 Who Should Conduct Mortality Reviews? — page 25
- 4.3 Levels and Functions of Death Review Committees — page 25
- 4.4 Procedure and Tools for Effective Death Reviews — page 26
- 4.5 Conducting a Death Review Session — page 26
- 4.6 Dos and Don’ts while conducting Death Reviews — page 26
- 4.7 Procedure for Medical Certification of Cause of Death — page 27
- 4.8 General Instructions while completing the HMIS 100 — page 28
- 4.9 Specific Instructions: — page 28
- 4.10 Guiding Principles for Reviewers — page 30
- 4.11 Community-Based Death Reviews — page 31
- 4.12 Death Review Summary and Reporting — page 31
- 4.13 Role of Laboratory in Mortality Surveillance — page 31
- CHAPTER FIVE — page 34
- MORTALITY SURVEILLANCE DATA MANAGEMENT AND USE — page 34
- 5.0 Introduction — page 34
- 5.1 Mortality Surveillance Data Collection — page 34
- 5.2 Mortality Surveillance Data Reporting — page 37
- 5.3 Mortality Surveillance Data Aggregation and Analysis — page 38
- 5.4 Mortality Surveillance Data Quality Assurance and Control — page 40
- 5.5 Use of Mortality Data — page 41
- 5.7 Some of the Data Sources — page 44
- CHAPTER SIX — page 45
- MONITORING AND EVALUATION FOR MORTALITY SURVEILLANCE
- GUIDELINES IMPLEMENTATION — page 45
- 6.1 Introduction — page 45
- 6.2 General Objective of M&E for Mortality Surveillance Guidelines — page 45
- 6.3 Monitoring and Evaluations at Different Levels — page 45
- 6.4 Tools for M&E — page 47
- 6.5 Data Sources — page 47
- 6.6 Feedback & Learning Loops — page 48
- 6.7 Data quality assessment in the mortality surveillance program — page 48
- 6.8 Indicators for monitoring performance of a mortality surveillance system — page 52
- 6.9 Dissemination of Mortality Surveillance Information — page 56
- References — page 74
- ANNEX — page 75

<!-- Source PDF page 5 -->

<!-- Source PDF page 6 -->

## LIST OF TABLES

- Table 1: Legal Frameworks Enabling Mortality Surveillance in Uganda — page 13
- Table 2: Leadership for mortality review committees at various levels — page 25
- Table 3: Mortality Data Collection tools matrix-showing some of the data management tools — page 37
- Table 4: Key Mortality Surveillance Analytics, Rationale, and Indicators — page 43
- Table 5: Showing communication channels of dissemination to target audience — page 57
- Table 6: Showing the different committees, their composition, and Terms of Reference — page 58

<!-- Source PDF page 7 -->

## LIST OF FIGURES

- _Figure 1: Current (June, 2025) Data Flowchart_ — page 12
- _Figure 2: Identification and Notification of death in the Community through the NIRA_ _pathway_ — page 24
- _Figure 3: Identification and Notification of death in the Community through MOH pathway_24
- _Figure 4: Schema to summarize the steps for Mortality Surveillance at the health facility, and_ _the respective data management tools used_ — page 36

**_Figure 5: Framework for quality assessment of mortality surveillance programs (Adopted from Continental Framework on Strengthening Mortality Surveillance Systems in Africa - CDC_** .. 49

<!-- Source PDF page 8 -->

## FOREWORD

It is with great pleasure that I present the Mortality Surveillance Guidelines for Uganda, a landmark contribution to our national public health information and response systems. This document reflects our collective commitment to building a responsive, data-driven, and people-centered health system that leaves no one behind.

Mortality surveillance is not merely an accounting of deaths but rather an essential part of saving lives. Accurate and timely mortality data enables us to understand the causes and distribution of death across the population, identify emerging threats, evaluate health system performance, and shape interventions that are targeted, equitable, and evidence based. In an era where health systems are increasingly challenged by pandemics, climatesensitive diseases, and shifting epidemiological patterns, the ability to track mortality in real-time is more critical than ever.

These guidelines serve as a comprehensive reference for all actors involved in mortality surveillance in Uganda. They are intended for use by health facility staff, community health workers, district health teams, civil registration authorities, implementing partners, and all stakeholders responsible for collecting, reporting, analyzing, and using mortality data. By providing standardized procedures and tools, this document ensures consistency, complete, quality, and timely information for use by all actors.

More broadly, the implementation of these guidelines will strengthen Uganda’s capacity to monitor key mortality indicators such as crude death rates, maternal and child mortality, and excess mortalities by age, gender, location, and cause. This, in turn, supports national health planning, emergency preparedness, and our progress toward Universal Health Coverage and the Sustainable Development Goals.

I urge all technical departments at the Ministry of Health and our Partners to embrace these guidelines, support their implementation, and use them in an integrated manner to build a robust mortality surveillance system for this country, where we shall be able to fulfil our mandate of not only identifying and notifying all deaths, but to accurately review them, identify challenges with our health system, detect epidemics early, and respond in time to prevent further deaths.

I commend all those who contributed to the development of this important document through the coordination efforts of the Department of Integrated Epidemiology, Surveillance & Public Health Emergencies; other technical departments of the Ministry; other Ministries, Departments & Agencies; District Local Governments, our Partners, Civil Society; Health Facility & Community stakeholders. Your collaboration exemplifies the power of partnerships and shared responsibility in building resilient health systems.

**Let us all adopt these guidelines with commitment and purpose, and ensure that every death is counted, every cause is understood, and every life is valued.**

**Dr Diana Atwine PERMANENT SECRETARY**

<!-- Source PDF page 9 -->

## ACKNOWLEDGEMENT

The Ministry of Health wishes to express its sincere and deepest appreciation to Government Ministries Department & Agencies, Government sectors, various development partners, nongovernmental organizations, Civil Society, and all those who contributed directly and indirectly to the development of the 2025 Mortality Surveillance Guidelines for Uganda.

The Ministry wishes to acknowledge the Mortality Surveillance Coordination Committee through the Mortality Surveillance Secretariate, whose technical input, expertise and review of these guidelines have been instrumental in shaping the content and relevance of this document.

Special thanks go to our financial Partners including Africa CDC, WHO, CDC, Baylor Foundation Uganda, Jhpiego, USAID, IDI, Civil Society (HEPS), CDC Foundation, for funding the numerous engagements that were part of the development process; technical teams and Partners including Ministries, Departments and Agencies; Technical departments of the Ministry of Health, Local Government Staff, Health workers, who were part of the development process of the Mortality Surveillance Guidelines for Uganda. The Ministry of Health is particularly grateful to Ms Caroline Kyozira - the Mortality Surveillance Focal Person, for her leadership and commitment in accomplishing this task.

This guiding document outlines fundamental steps and instructions for establishing an effective and robust mortality surveillance system through its pages. It details key steps to be followed in identification, notification, reviewing, assignment of medical cause of death, reporting and feedback mechanisms to ensure utilization of findings to inform the response function, as well as evidence-based decision making to resolve systematic issues that could have been found out.

These guidelines will go a long way in enhancing the global health security agenda of the country through implementing a coordinated robust mortality surveillance system where all deaths occurring within this country are identified by person, place and time; where the review of each death is done to understand what is actually leading to the death, corrective actions discussed and arrived at by the respective health teams involved, a standard medical cause of death assigned, and sharing of feedback to relevant stakeholders done to inform response, inform decision making on how to improve, and as well inform positive reactions by communities. Through the routine analysis of this data and concerted efforts, we shall have highly infectious diseases, clusters of mortalities identified, enhancing early detection and response to outbreaks. This will ultimately improve the sensitivity of our public health surveillance system.

![Source illustration — PDF page 9](images/illustration-009-002.png)

Dr Charles Olaro **DIRECTOR GENERAL HEALTH SERVICES**

<!-- Source PDF page 10 -->

## LIST OF CONTRIBUTORS

The persons listed in the table below have actively participated at various stages of developing this national MS guidelines document. This process has been spearheaded and coordinated by the national MS secretariate in the department of Integrated Epidemiology, Surveillance and Public Health Emergencies, at the Ministry of Health.

|**NAME** |**INSTITUTION** |**NAME** |**INSTITUTION** |
|---|---|---|---|
|DR CHARLES OLARO|DGHS|DR KIZZA DOMINIC K|BAYLOR FOUNDATION UGANDA|
|DR ALLAN MURUTA|MOH/IES&PHE|DR MARIAM NAMBUYA|MOH/IES&PHE|
|DR STAVIA TURYAHABWE|MOH/NDC|DR MUCUNGUZI ATUKUNDA|MOH/IES&PHE|
|DR CHARLES OYOO|MOH/NCD|DR ALFRED WEJULI|MOH/IES&PHE|
|DR GEORGE OPENYTHO|MOH/COMMUNITY|DR MUWEREZA PETER|JHPIEGO|
|DR ISSA MAKUMBI|MOH/NPHEOC|ERIC SSEGUJJA|MakSPH|
|DR BWIRE GODFREY|MOH/IES&PHE|DR SOLOME OKWARE|WHO|
|DR OPOLOT JOHN|MOH/IES&PHE|DR ROSEMARY AMOLO|MOH/NTLP|
|DR MWANGA MICHEAL|MOH/IES&PHE|MOSES RUBANGAKENE|WHO|
|DR RONNIE BAHATUNGIRE|MOH/CLINICAL|LINDA PHIONA|WHO|
|MS CAROLINE KYOZIRA|MOH/IES&PHE|DR STELLA MARIS LUNKUSE|MOH/IES&PHE|
|DR ATIM DANSAN|MOH/IES&PHE|DR TABARO CATHY ASIIMWE|MOH/DHI|
|DR MOSES EBONG|MOH/IES&PHE|MR PHILIP WAISWA|MOH/DHI|
|MR BULAMU MARTIN|MOH/IES&PHE|MR TANDISUWALA TOM BATEGHEKA|BUNDIBUGYO HOSPITAL|
|DR PANDE STEPHEN LEGESI|MOH/MOROTO RRH|MR AKOL GEORGE MICHEAL|MOH/DHI|
|DR BAHIZI ARCHBALD|MOH/FORTPORTAL RRH|MR MOIIR AYENE|AFRICA CDC|
|DR FREDRICK ISABIRYE|JINJA CITY|MS ATUHEIRE EMILY|AFRICA CDC|
|MR ROBERT JOHN OFFITI|HEPS/CIVIL SOCIETY|DR GEBREMICHAEL MOLLA|AFRICA CDC|
|DR WALYOMO RICHARD WALEX|KCCA|MR FRED WANGARA OGOLA|NIRA|
|MR ALLAN LUBULYA|JINJA CITY|MS KIRABO SUZAN|NIRA|
|COL DR BAKEHENA FRANCIS|UPDF|MR IRANKUNDA NATHAN|KISORO DLG|
|COL STEVEN  SSALI BERNES|UPDF|MS KALIISA RUTH|KOFIH|
|MR MULWANA FRANCIS|UPDF|MR PATRICK JAIKA|UGANDA HEART INSTITUTE|
|DR KALUNGI SAM|MULAGO HOSPITAL PATHOLOGY|MR MULUMBA YUSUF|UGANDA CANCER INSTITUTE|
|DR STELLA LUNKUSE|MOH/IES&PHE|MR KATO ROBERT|MOH/IES&PHE|
|DR PROSSY NAMUWENGE|MOH/ACP|MS KATUSIIME MAUREEN|METS/MakSPH|
|DR IGNATIUS SSENTEZA|IDI|MS KAYAGA  JALIAT|MULAGO NRHOSPITAL|
|DR AGGREY BYARUHANGA|MOH/IES&PHE|MR KENNETH BALONDEMU|LAWYER|
|MR AHIMBISIBWE EXPEDITUS|MOH/PLANNING|MS KANSIIME PRIMROSE|BAYLOR FOUNDATION UGANDA|
|MR AKONYU CHARLES AMEJE|KOBOKO DLG|MR DRICIMA EMMANUEL|UGANDA CANCER INSTITUTE|
|BULAFU DOUGLAS|MakSPH|MRS LYDIA MUKOMBA MULWANYI|MOH/IES&PHE|
|DR SIMON KASASA|MakSPH|WILLIAM OKIROR|MBALE REOC|
|MR OUMO PETER|UGANDA POLICE FORCE|MS VIVIAN NTONO|IDI|
|MS AYEBARE AMABLE|KCCA|MR MALOXIM MARVIN|IDI|
|MR CHEPKURUI DENIS|UGANDA POLICE FORCE|MS LYDIA NAKIIRE|IDI|
|DR KATONGOLE ABDUL|UGANDA POLICE FORCE|MR MANENGA  EMMANUEL|ARUA RRH|
|MR EILU ROGER  MICHEAL|IDI/UNHLS|MS MARIAM NANKYA|JHPIEGO|
|MR EMMANUEL OKIROR OKELLO|UNIPH|MS MBABAZI MOUREEN|MOH/IES&PHE|
|DR CAROL NANZIRI|UNIPH/CDCF|MR MORUKILENG JOB|UNIPH/CDCF|
|MR BAMWOZE PAUL|MOH/PLANNING|MR OCENG BRUNO|IDI|
|MR BITSING  NOAH|MULAGO HOSPITAL PATHOLOGY|MR OCENG GERALD|AIDS INFORMATION CENTRE|
|MR EMMA SAM ARINAITWE|MOH/IES&PHE|MR OMONUK JUDE|FUNERAL SERVICES ASSOCIATION|
|MR OWOR BENARD|MAKERERE SCHOOL OF MEDICINE|MS AGWANG DAPHINE|MakSPH|
|MS MAY NAMUKWAYA|MOH/IES&PHE|DR MUGANGA KENNETH|MOH|
|MS DEBORAH AUJO|JINJA RRH|MR PAUL  ORYEMA|GLOBAL FUND|
|DR EBONG QUINTO|MOH/MALARIA|MR OKABO  JOSEPH|ARUA RRH|
|MS ASIO ALICE|BAYLOR FOUNDATION UGANDA|||
|DR ROBERT MAJWALA|BAYLOR FOUNDATION UGANDA|||
| OPIO GREGORY| BAYLOR FOUNDATION UGANDA|||

![Original table layout — PDF page 10](images/table-source-page-010.png)

<!-- Source PDF page 11 -->

## ABBREVIATIONS AND ACRONYMS

|AFENET|African Field Epidemiology Network|
|---|---|
|AMR|Antimicrobial Resistance|
|APAI-|African Programme for the Accelerated Improvement of Civil|
|CRVS|Registration and Vital Statistics|
|ART|Antiretroviral Therapy|
|AU|African Union|
|CDC|Centers for Disease Control and Prevention|
|CHEWs|Community Health Extension Workers|
|CHO|City Health Officer|
|CMR|Crude Mortality Rate|
|CMR|Crude Mortality Rate|
|CoNCoD|Communicable and Non-Communicable Diseases|
|CPHL|Central Public Health Laboratory|
|CRVS|Civil Registration and Vital Statistics|
|CSMR|Cause-Specific Mortality Rates|
|DALYs|Disability-Adjusted Life Years|
|DGAL|Department of Government Analytical Laboratory|
|DHI|Division of health information|
|DHIS2|District Health Information Software 2|
|DHO|District Health Officer|
|DNA|Deoxyribonucleic Acid|
|DNR|Death Notification Record|
|DQA|Data Quality Assessment|
|DRC|Death Review Committee|
|DSR|Death Surveillance and Response|
|DVO|District veterinary officer|
|eCHIS|Electronic Community Health Information System|
|eIDSR|Electronic Integrated Disease Surveillance and Response|
|EMR|Electronic Medical Record|
|EOCs|Emergency Operation Centres|
|HDSS|Health and Demographic Surveillance Site|
|HEPS|Coalition for Health Promotion and Social Development|
|HF|Health Facility|
|HIV|Human Immunodeficiency Virus|
|HMIS|Health Management Information System|
|HPAC|Health Policy Advisory Committee|
|HSSIP IV|Health Sector Strategic & Investment Plan IV|
|iCCM)|Integrated Community Case Management|
|ICD-11|International Classification of Diseases, 11th Revision|
|ICER|Incremental Cost-Effectiveness Ratio|
|ICT|Information and Communications Technology|
|IDI|Infectious Diseases Institute|
|IDSR|Integrated Disease Surveillance and Response|
|IES|Integrated Epidemiology and Surveillance|
|IHR|International Health Regulations|

![Original table layout — PDF page 11](images/table-source-page-011.png)

<!-- Source PDF page 12 -->

|IMHDSS|Iganga-Mayuge Health and Demographic Surveillance Site|
|---|---|
|IMT|Incident Management Team|
|IPD|Inpatient department|
||Johns Hopkins Program for International Education in|
|JHPIEGO|Gynaecology & Obstetrics|
|KCCA|Kampala Capital City Authority|
|LC|Local Council|
|M&E|Monitoring and evaluation|
|MAAIF|Ministry of Agriculture, Animal Industry and Fisheries|
|MakSPH|Makerere University School of Public Health|
|MCCD|Medical Certification of Cause of Death|
|MDAs|Ministries, Departments, and Agencies|
|METS|Monitoring and Evaluation Technical Support Program|
|MMR|Maternal Mortality Ratio|
|MoH|Ministry of Health|
|MPDSR|Maternal and Perinatal Death Surveillance and Response|
|MPR|Missing Person Report|
|MS|Mortality Surveillance|
|mTrac|Mobile Tracking System|
|MVRS|Mobile Vital Registration System|
|NCDs|Non communicable diseases|
|NCHS|National Community Health Strategy|
|NDP IV|National Development Plan IV|
|NIN|National identification number|
|NIRA|National Identification and Registration Authority|
|NPA|National Planning Authority|
|NTRL|National Tuberculosis and Leprosy Reference Laboratory|
|OPD|Out Patient Department|
|OPM|Office of the Prime Minister|
|PFP|Private for Profit|
|PHE|Public Health Emergencies|
|PHEOC|Public Health Emergency Operations Center|
|PNFP|Private Not for Profit|
|PoE|Point of Entry|
|PPE|Personal Protective Equipment|
|QALYS:|Quality-Adjusted Life Years|
|QI|Quality Improvement|
|RDS|Results Dispatch System|
|RMS|Rapid Mortality Surveillance|
|ROPA|Registration of Persons Act|
|ROPA|The registration of persons act|
|RRHs|Regional Referral Hospitals|
||Standards, Compliance, Accreditation and Patient Protection|
|SCAPP|Department|
|SDGs|Sustainable Development Goals|
|SMGL|Saving Mothers, Giving Life|
|SMS|Short message service|

![Original table layout — PDF page 12](images/table-source-page-012.png)

<!-- Source PDF page 13 -->

|TB|Tuberculosis|
|---|---|
|TWG|Technical working group|
|UBOS|Uganda Bureau of Statistics|
|UCI|Uganda Cancer Institute|
|UDHS|Uganda Demographic and Health Survey|
|UHC|Universal Health Coverage|
|UHF|Uganda Healthcare Federation|
|UNCST|Uganda National Council for Science and Technology|
|UNHCO|Uganda National Health Consumers’ Organization|
|UNHCR|United Nations High Commissioner for Refugees|
|UNHLDS|Uganda National Health Laboratory and Diagnostic Services|
|UNICEF|United Nations Children's Fund|
|UNIPH|Uganda National Institute of Public Health|
|UPDF|Uganda People's Defense Forces|
|UPF|Uganda Police Force|
|UPS|Uganda Prisons Service|
|USAID|United States Agency for International Development|
|UVRI|Uganda Virus Research Institute|
|VA|Verbal Autopsy|
|VHTs|Village Health Teams|
|WHO|World Health Organization|
|WIT|work improvement team|

![Original table layout — PDF page 13](images/table-source-page-013.png)

<!-- Source PDF page 14 -->

## Glossary

**Accountability** : Responsibility to stakeholders for ethical and legal adherence in mortality surveillance.

**All-cause mortality** : Mortality data capturing all deaths regardless of cause.

**All-Cause Death Review Tool** : Standardized instrument used to review and document deaths from any cause.

**Antecedent Cause of Death** : Intermediate conditions in the causal chain between the underlying and immediate cause of death (recorded in Lines b and c of Frame A).

**Anonymity** : Removal of personal identifiers to prevent tracing data back to individuals.

**Autonomy** : Right of individuals to make informed decisions about their participation.

**Beneficence** : Ethical principle to act in the best interest of others.

**Biosafety** : Containment principles and practices preventing unintentional exposure to pathogens.

**Biocontainment** : Measures to control exposure to infectious agents in laboratories.

**Cause-specific Mortality Rate** : Death rate from a specific cause within a defined population.

**Catchment Area** : Geographic area served by a health facility.

**Central Public Health Laboratory (CPHL)** : National reference lab for public health surveillance and diagnostics.

**Civil Registration** : Official recording of vital events such as births and deaths.

**Civil Registration and Vital Statistics (CRVS)** : System for registering births, deaths, and other vital events and producing statistics based on these records.

**Community** : Group of people in a defined area sharing common values, norms, and culture.

**Community Death** : Death occurring outside a health facility setting.

**Community Gatekeepers** : Individuals such as VHTs, religious leaders, teachers, or local leaders who identify and report deaths.

**Community-Based Death Review** : Mortality review process conducted in communities through verbal autopsies and family interviews.

**Community-based Reporting** : Collection of health and mortality data directly from households or community sources.

<!-- Source PDF page 15 -->

**Community death** : death that occurs outside of a formal health facility setting; meaning the individual dies at home, in the community, or any place other than a hospital or clinic.

**Confidentiality** : Ethical obligation to protect information from unauthorized access or disclosure.

**Confidentiality Agreement** : Formal agreement to protect sensitive information during and after the death review process.

**Crude Mortality Rate (CMR)** : Total number of deaths in a population over a certain period, usually expressed per 1,000 individuals.

**Data Protection and Privacy Act (2019)** : Law ensuring secure, ethical use of personal and health data.

**Data Utilization** : Active use of collected data for decision-making, planning, and evaluation.

**Death** : Permanent cessation of all vital functions without the possibility of resuscitation (WHO definition).

**Death Identification** : Process of detecting or recognizing a death event.

**Death Notification** : Formal process of informing authorities or civil registration offices of a death occurrence.

**Death Review** : Systematic evaluation of circumstances and contributing factors surrounding a death to identify preventable causes and guide future interventions.

**Death Review Committee (DRC)** : Multidisciplinary group responsible for conducting death reviews at facility, district, regional, or national levels.

**Death Review Form (HMIS 100 Frame A)** : Official health facility reporting tool for recording medical certification of cause of death.

**Designated Health Facility** : Health facility recognized to handle death certification and postmortems.

**Digital Health Strategy** : Coordinated national plan to use digital technologies and systems to improve health outcomes.

**Disease Burden Tables** : Analytical summaries of mortality and morbidity used in planning.

**Displaced Populations** : Groups forced to leave their homes, relevant in refugee mortality tracking.

**DNA Analysis** : Forensic method used to identify disfigured or unidentifiable remains.

**Epidemic Preparedness** : Capability of a health system to detect, respond to, and mitigate disease outbreaks and emergencies.

<!-- Source PDF page 16 -->

**Epidemic Response** : Measures taken to detect, report, and control outbreaks of diseases.

**Electronic Medical Records (EMR)** : Electronic system within health facilities used to manage patient information and mortality data.

**eIDSR Platform (6767)** : SMS-based electronic platform used to notify deaths to the Ministry of Health.

**Facility-Based Death** : Death that occurs in a health facility or in transit with referral documentation from a facility.

**Form 12** : Official NIRA death notification form used at community and health facility levels.

**Health Facility Death** : Death occurring within a formal healthcare facility.

**Health Management Information System (HMIS)** : National platform for collecting and managing health-related data.

**Health Policy Advisory Committee (HPAC)** : Group advising on health policies.

**Health Security** : Measures to prevent and manage threats to public health.

**ICD-11** : International Classification of Diseases, 11th Revision, a standardized coding system for diseases and causes of death.

**Immediate Cause of Death** : Final condition that directly caused death (recorded in Line a of Frame A).

**Informed Consent** : Permission granted with full knowledge of the purpose, risks, and benefits of participation.

**Integrated Disease Surveillance and Response (IDSR)** : Strategy for strengthening national public health surveillance and response systems.

**Interoperability** : Ability of different data systems and organizations to access, exchange, and use health information effectively.

**Legal Identity** : Recognition of an individual by the state, supported through death registration.

**Medical Certification of Cause of Death (MCCD)** : Official documentation of the cause of death completed by a medical professional.

**Medical Doctor Certification** : Final confirmation and documentation of cause of death by a qualified physician.

**Missing Person Report (MPR)** : Police-issued report officially documenting a missing individual.

<!-- Source PDF page 17 -->

**Mortality Surveillance (MS)** : Systematic collection, analysis, and dissemination of deathrelated data to guide public health action.

**National Development Plan IV (NDP IV)** : Uganda's strategic framework for development, including health sector goals and benchmarks.

**Notification of Death** : Formal process to report a death event to relevant authorities or systems.

**One Health** : Approach integrating human, animal, and environmental health for holistic public health strategies.

**Operational Zone** : Area where military or emergency operations are actively taking place.

**Personal Protective Equipment (PPE)** : Specialized clothing or equipment worn for protection against health or safety hazards.

**Points of Entry (PoE)** : Designated national borders (airports, land crossings) where monitoring of incoming health risks, including deceased individuals, is conducted.

**Postmortem Examination** : Medical investigation to determine the cause of death.

**Presumed Death** : Legal declaration of death for a person missing for seven years or more.

**Presumption of Death Order** : Court order declaring a missing person legally dead.

**Police Form 48A** : Police form used to document death scene information.

**Police Form 48B** : Used for recording findings of a transported body.

**Police Form 48C** : Completed when a postmortem is conducted on-site.

**Public Health Action** : Timely response, intervention, or policy formulation informed by health data to prevent illness or death.

**Public Health Act (Uganda)** : Law governing reporting and management of public health issues.

**Quality Improvement (QI) Teams** : Facility or district-level teams tasked with identifying gaps and implementing healthcare improvements.

**Radiology in Mortality Surveillance** : Use of imaging techniques to aid in determining cause of death in complex or forensic cases.

**Reference Laboratory** : Specialized lab responsible for confirmatory testing, quality assurance, and outbreak investigations.

**Registration Officer** : Authorized personnel mandated to record deaths under national law.

**Repatriation of Remains** : Process of returning a deceased person’s body to their home country.

<!-- Source PDF page 18 -->

**Results Dispatch System (RDS)** : Electronic platform for releasing laboratory results to health facilities.

**Sample Packaging and Transport** : Procedures for safely packaging, storing, and transporting biological samples to maintain integrity and biosafety.

**Short Death Certificate** : Community-issued notification record confirming a death occurred.

**Standard Curriculum** : Consistent training resource for mortality surveillance teams on ethics and procedures.

**Standard Operating Procedures (SOPs)** : Formal processes for conducting activities such as death reporting or audits.

**Surveillance Sub-Pillar** : Sub-unit under national or district health surveillance structures responsible for monitoring health events.

**Sustainable Development Goals (SDGs)** : Global goals adopted by the United Nations to address sustainable development issues by 2030.

**Temporary Holding Facility** : Location where remains are kept before official processing or repatriation.

**Transparency** : Openness about why and how data is collected and used.

**Universal Health Coverage (UHC)** : Ensuring all individuals receive the health services they need without financial hardship.

**Unclaimed Remains** : Human bodies not identified or claimed by relatives.

**Underlying Cause of Death** : Root disease or injury that initiated the chain of events resulting in death (recorded in Line d of Frame A).

**Uganda National Council for Science and Technology (UNCST)** : National ethics review body overseeing research involving human participants.

**Uganda Virus Research Institute (UVRI)** : Institution conducting viral disease research and public health responses.

**Verbal Autopsy (VA)** : Method used to determine probable cause of death based on interview with someone familiar with the deceased’s health history.

<!-- Source PDF page 19 -->

## Chapter One: Introduction To Mortality Surveillance And Response

### 1.0 Background

The importance of robust mortality surveillance (MS) and response systems cannot be overstated in an era marked by increasing global health challenges where health threats loom large and population dynamics continue to evolve. Accurate and timely mortality data is essential for identifying trends and reasons for death occurrences, identifying system gaps, detecting emerging health threats, evaluating the impact of interventions, and guiding evidence-based policy decisions.

According to the 2024 World Health Organization bulletin on the role of mortality surveillance, it is revealed that the coronavirus disease 2019 (COVID-19) pandemic exposed critical limitations in the availability of timely mortality data to inform situational assessments and guide evidence-based public health responses at local, national and global levels[1]. Less than half of the Member States of the World Health Organization (WHO) (73 out of 194) generated the required mortality data. In most countries, attempts were made to conduct mortality surveillance but yielded only partial data with limited utility. This experience highlighted the need for a series of strategic shifts to strengthen mortality surveillance programs in all countries, towards complete identification of deaths, recording them, reviewing the circumstances surrounding the deaths, identifying their causes, coupled with timely dissemination of review findings to the concerned stakeholders for purposes of strengthening the system, and informing early detection of emerging health threats. These shifts include modifying systems to enable streamlining of the compilation and use of death records from all sources while meeting the requirements of official registration processes; using electronic protocols for data management and release; and ensuring effective leadership, coordination and data use for public health action.

In 2023, the Africa Centres for Disease Control and Prevention (Africa CDC) developed a conceptual framework for strengthening national mortality surveillance and operational guidance for implementation[2]. The activities and resources for improving national mortality surveillance are aimed at informing global initiatives to support pandemic preparedness and response programs. They are to support enablement of global readiness for early epidemic detection and disease control measure prioritization, while also building routine mortality statistics programs for population health assessment, health policy and research.

### 1.1 Introduction

Mortality surveillance is a critical component of a country’s public health surveillance system and a cornerstone for monitoring public health priorities. Timely and accurate data on deaths and their causes is essential for informing health policies, planning interventions, evaluating the impact of health programs, and addressing emerging public health threats.

Reliable information on deaths by age, sex and cause of death in a population is essential for evidence-based health policy, program evaluation and epidemiological research.

<!-- Source PDF page 20 -->

During the earliest phase of infectious disease epidemics, timely mortality data are critical for identifying clusters of deaths from which further investigations can be triggered. The estimation of excess mortality by continuous tracking of deaths is needed to gauge and monitor disease severity and spread, and also serves as essential evidence for planning and implementation of measures for disease containment, suppression and mitigation.

Mortality surveillance refers to the ongoing systematic collection, collation, compilation, review, analysis and interpretation of death data, which is then continuously shared to relevant authorities for public health action to prevent future related deaths. For comprehensive mortality surveillance, all-cause-mortality data must be available in realtime and continuously utilized both at subnational and national level; and the only way to obtain this high-quality mortality data is through a robust Mortality Surveillance system.

### 1.2 Problem Statement

The COVID-19 pandemic highlighted the lack of availability of timely mortality data. During 2020–2021, only 73 of the 194 WHO Member States (37.6%) had complete monthly data on deaths by age and sex that could be used to estimate pandemic-related excess mortality (in many cases, only available several weeks after the end of the reference month)[1]. Of the remaining Member States, 37 (19.1%) generated partial data (e.g. either incomplete population coverage or time period) and no mortality data were available for 84 (43.3%). Furthermore, mobility restrictions and disruptions in government procedures impeded timely death registration, verification of causes of death and data compilation before release; many public health systems simply did not have the capacity to respond to the sudden increased demand for timely mortality data. These lack of data scenarios highlight the importance of establishing or strengthening mortality surveillance.

Despite considerable investments towards strengthening Uganda’s health system, mortality data collection remains fragmented, incomplete, and often untimely to serve the surveillance function. From Kasasa et al, we note that majority (63%) of the deaths occur in communities[3], while the rest are estimated to occur in health facilities, and yet the notification rate for community deaths is very low, with only about 1% of deaths being formally notified annually[3]. This is significantly lower than the estimated 33% of deaths that are notified at different levels, and even lower than the 4.5% of deaths that are legally registered with a death certificate[4]; and Verbal Autopsies (VA) are equally rarely done[5].  Furthermore, the national mortality surveillance roadmap reveals the quality of mortality data in health facilities as still suboptimal, and the Medical Certification of Cause of Death (MCCD) is inadequate i.e according to the HMIS for the financial year 20222023 extracted on 4th June 2024, 70077 deaths were reported, 4828 (6.9%) of these were notified and 4196 (6.0%) were medically certified[6].

Uganda’s MS landscape is currently characterized by multiple, disparate mortality mechanisms, driven by disease program specific interests; partner/funding interests; Ministries, Department and Agency (MDA) requirements; with respective information systems, often not interoperable, creating silos of mortality databases. Despite this

<!-- Source PDF page 21 -->

multitude of data collection efforts, significant challenges persist regarding completeness, quality, accessibility, and utilization of mortality data for public health decision-making. This fragmented and uncoordinated landscape often leads to duplication of efforts , hinders Uganda’s ability to comprehensively understand disease burden, challenges in identifying vulnerable populations, timely and accurate assessment of the population's health status, impedes effective response to public health threats, efficient allocation of resources for priority interventions and ultimately constrains Uganda's ability to achieve its national public health and development goals. Therefore, the development and implementation of a robust Mortality Surveillance Guidelines for Uganda is urgently needed.

These guidelines will standardize data collection, enhance data quality, improve accessibility, and promote the utilization of mortality data. This will accelerate the availability of complete mortality data and its utilization, facilitate timely detection& response to public health threats, and ultimately contribute to improved health outcomes and the advancement of Uganda's national public health and development agenda.

### 1.3 Rationale for Establishing a Mortality Surveillance System

Monitoring deaths aids in identifying and addressing their causes, allowing health systems to adapt and respond effectively. It triggers responses across multiple sectors based on the cause of death, such as the Ministry of Works and Transport for road traffic accidents; the Ministry of Agriculture, Animal Industry and Fisheries (MAAIF) for the rising prevalence of food-related events, among others.

The Africa Centres for Disease Control and Prevention (Africa CDC) has published the Continental Framework for Strengthening Mortality Surveillance Systems in Africa (the “Continental Framework”) 2024, to guide all African Union (AU) Member States on adopting a strategic approach to develop their national mortality surveillance programs based on country contexts.

Establishing a mortality surveillance system in Uganda enables the standardized collection, collation, compilation, analysis and dissemination of mortality data from both health facilities and communities. The system helps identify public health priorities by revealing who is dying, when, where, and from what causes. It enhances emergency preparedness by providing timely data for swift responses to outbreaks or disasters, as continuous monitoring allows for the detection of abnormal health trends. Mortality data analysis also supports the evaluation of public health interventions and programs. Additionally, it strengthens the national civil registration of vital statistics (CRVS) system.

A robust mortality surveillance system is critical for evidence-based public health action as it enables a comprehensive understanding of the population's health status, facilitates the measurement of progress against established indicators, and highlights regional disparities and vulnerable populations. Furthermore, it plays a vital role in the early detection and response to epidemics and supports effective planning, policy formulation, and equitable resource allocation.

Uganda's mortality surveillance system will incorporate both health facility-based and community-based reporting mechanisms, leverage existing digital platforms, and align

<!-- Source PDF page 22 -->

with global best practices such as the WHO standards for notification and assign cause-ofdeath by using the International Classification of Diseases (ICD-11).

### 1.4 Scope

These guidelines aim to promote consistency and standardization in the practices and procedures related to all-cause mortality identification, notification, medical certification, review of each death, as well as respond to the recommendations of the death reviews, at both health facility and community levels. These processes should be able to provide an efficient and sustainable framework for strengthening and maintaining integrated passive and active surveillance of all-cause mortality across the country.

The scope of these guidelines includes the One Health approach which integrates human, animal, and environmental health systems to effectively detect, prevent, and respond to emerging public health threats. Within the One Health framework, the guidelines aim to provide clarity on the surveillance of zoonotic diseases, antimicrobial resistance (AMR), vector-borne diseases, and foodborne illnesses, as well as environmental surveillance areas such as water pollution and the impact of climate change on human health. These components are critical for enabling proactive and coordinated public health responses.

The guidelines further provide standardized approaches for mortality surveillance in special contexts such as refugee/humanitarian settings, urban settlements, armed forces, unidentified persons, hard-to-reach areas (e.g., islands and slums), deaths of nationals abroad, and violent deaths ensuring accurate and timely reporting regardless of location or circumstance.

Emphasizing inter-sectoral collaboration, the guidelines aim to enhance the detection of unusual mortality patterns and produce reliable data to inform public health action, national policies, and global reporting. This is particularly critical during public health emergencies such as pandemics and outbreaks. Clear direction is provided on the core components needed to support effective implementation, integration, and long-term sustainability across existing surveillance systems.

The guidelines also emphasize the importance of capacity development, good governance, and improved systems for data collection, analysis, and dissemination. They promote enhanced coordination and collaboration across stakeholders, fostering strong partnerships. Such partnerships are essential for sharing data, expertise, and resources, and for ensuring a comprehensive and unified response to public health threats.

The establishment and strengthening of MS are grounded in several national and global policy frameworks. Nationally, the system aligns with registration of persons act 2024 (ROPA, 2024) which mandates that the Ministry of Health notifies all deaths for the CRVS system.

<!-- Source PDF page 23 -->

### 1.5 Goal

To provide a standardized framework for the systematic collection, analysis, interpretation, and use of mortality data to inform evidence-based public health actions.

#### 1.5.1 Specific Objectives

1. To strengthen leadership and governance for Mortality Surveillance implementation.

2. Strengthen a standardized approach to real-time identification, notification of all deaths at both health facility and community.

3. Strengthen a coordinated approach to medical certification of the cause of death (MCCD) for all deaths.

4. Strengthen implementation of all-cause death reviews to inform response actions for averting future deaths.

5. Strengthen the mortality surveillance system for early detection of public health threats and other disease conditions

6. To promote MS data analysis, assessment, utilization and feedback at all levels.

7. Promote interoperability of existing MS data systems with all relevant MDAs.

### 1.6 Guiding principles

1. **_Evidence-based:_** MS response interventions and decisions should be grounded in accurate, timely and disaggregated mortality data to ensure relevance, real-time detection of public health threats and impact.

2. **_Health systems approach:_** Implementation of MS should be integrated at all levels of the health system; from community to national to ensure continuity and comprehensiveness. MS data should also be integrated within the broader Health Management Information System (HMIS) at community and health facility levels.

3. **_Complementary:_** Building on existing programs and recognizing the strengths of different stakeholders in the planning, implementation, and evaluation of mortality surveillance.

4. **_Partnership and coordination:_** Promote collaboration and coordination for integration, coordination, and joint programming among stakeholders.

8. **_Clear definition of roles and responsibilities:_** Each stakeholder should have clearly defined roles to avoid fragmented implementation and promote accountability.

9. **_Transparency and accountability:_** There should be transparent sharing of mortality data, methodologies, and findings to foster trust, encourage stakeholder engagement, and support evidence-based decision-making. All actors should perform their roles responsibly, with clear oversight, defined responsibilities, and feedback mechanisms to ensure data quality and system effectiveness.

10. **_Integration within the Digital Health Strategy:_** MS should be integrated within the national digital health strategy and integrated within existing digital platforms such as eCHIS, eIDSR, DHIS2 and other electronic medical records systems to enhance interoperability, efficiency, and data use across the health system and beyond.

<!-- Source PDF page 24 -->

11. **_Quality improvement:_** MS should aim at providing critical insights that help health systems identify gaps, enhance services and design strategies for improved quality of care across all levels.

12. **_Community Participation:_** MS should foster decentralization of services that emphasize community participation in health service delivery and utilization.

### 1.7 Expected Outcomes and Impact of Mortality Surveillance

If Uganda establishes a robust standardized, and functional mortality surveillance & response system that includes real-time identification, notification, medical certification, and review of all deaths from both health facilities and communities, while strengthening leadership, governance, capacity, and data interoperability across key Ministries, Departments and Agencies, then the country will generate timely, accurate, and complete all-cause mortality data that informs public health response, guides targeted interventions, enhances epidemic preparedness, strengthens the CRVS system, and supports accountability & planning towards achieving national and global health goals such as SDGs, UHC, and National Development Plan (NDP) IV.

### 1.8 Process of Formulating the MS Guidelines (2025/26 - 2029/30)

The development of the of the Mortality Surveillance guidelines started in November, 2024. The Ministry of Health constituted and coordinated a series of stakeholder workshops in consultation with participants from across the country, comprising Government Ministries: Ministry of Health Technical departments (IES&PHER, Clinical Services, Reproductive Health, Planning Department-DHI, SCAPP, Multisectoral collaboration, NCDs, Communicable diseases - HIV, TB, Malaria, UNHLDS, Community Health, Health Promotion, UNIPH, the RRHs, General Hospitals, Health workers); Ministry of Internal Affairs (NIRA, Immigration, UPDF, UPF, UPS); Ministry of Finance, Planning and Economic Development (UBOS, NPA); Ministry of Local Government (DHOs, CHOs, Biostatisticians, Surveillance Focal Persons, Laboratory Focal Persons); Kampala Capital City Authority (KCCA); Private Sector (UHF); Civil Society  (UNHCO, HEPS); Community (VHTs, Religious Leaders, LCs); Academia (MakSPH); Development & Implementing Partners (WHO, CDC, Africa CDC, UNHCR, AFENET, Baylor Uganda, IDI, World Vision, CDC Foundation, JHPIEGO,  MakSPH-METS Program). Through these efforts, a draft national mortality surveillance guidelines document was developed.

A situation analysis was conducted to inform the country context. This included reviewing the performance of MS across the country; desk review of policy, strategic documents (including the Constitution of Uganda, NDP IV, National Health Policy, HSSIP IV, Public Health Act 2022, Africa CDC Continental framework), MS roadmap, programmatic reports and research, interpretation of available data (from surveys and routine DHIS2 data,); national and subnational stakeholder consultations. This was done to identify progress in MS implementation and document best practices, lessons learned, gaps and opportunities to overcome the challenges.

A validation workshop was then conducted in June, 2025, to validate the draft national MS guidelines, which were later presented to the MoH CONCOD TWG, then to the Senior Management Committee, HPAC and Top Management.

<!-- Source PDF page 25 -->

### 1.9 Intended users of the guidelines

These guidelines are intended to serve a wide range of stakeholders involved in the identification, collection, reporting, analysis, dissemination and use of mortality data in Uganda. Primary users include but are not limited to:

1. Community gatekeepers (VHTs, Religious Leaders, Police/Law enforcement etc.)

2. Health workers at all levels (CHEWS, health facility, district/City, regional and national levels), both Private for Profit (PFP), Private not for Profit (PNFP) and Public.

3. One health actors including animal and environmental health stakeholders.

4. Policy makers and planners.

5. Civil registration authorities including UBOS, NIRA.

6. Security agencies including Police, the Army and Prisons

7. Researchers and academic institutions

8. Development/implementing Partners

9. Private sector players including funeral service companies, mortuaries and cemeteries

Through coordinated implementation of these guidelines, Uganda aims to strengthen its mortality data ecosystem, public health surveillance, global health security, and advance evidence-driven health programming and policy- making.

### 1.10 Implementation Experiences in Mortality Surveillance in Uganda

Uganda has had mortality surveillance (MS) integrated into its broader Integrated Disease Surveillance and Response (IDSR) strategy since 2000. Over the years, other components such as the Maternal and Perinatal Death Surveillance and Response (MPDSR); and disease-specific mortality surveillance activities like audits for disease conditions such as HIV, tuberculosis (TB), malaria, and cancer came into play.

In October 2024, the Ministry of Health launched the National Mortality Surveillance Roadmap, a key document describing the gap in the current implementation modalities for mortality data collection and use, outlining strategies to enhance harmonized mortality data collection, analysis, and use. This roadmap emphasizes monitoring key indicators like crude mortality rates (CMR), life expectancy, and cause-specific mortality rates (CSMR), disaggregated by demographic factors.

### 1.11 Examples of Experiences and lessons learned from disparate MS interventions

#### 1.11.1 Digital platforms for MS

The introduction of electronic systems for Mortality Surveillance including e-IDSR, e- CHIS, MTrac and DHIS2 have supported notification, reporting and MCCD. e-IDSR is a multifaceted system currently utilized at community, Health facility and National level for real-time data collection, notification, generation of the death line lists and monitoring of MS performance. e-CHIS is a community system that has been customized to facilitate

<!-- Source PDF page 26 -->

death reporting at household level. MTrac system is also being used to report weekly epidemiological data (HMIS 033B). DHIS2 is the repository for all the death data generated through HMIS, Including HMIS 100 (MCCD). The National MS dashboard has also been developed using data from DHIS2. In 2022, for instance, the Malaria outbreak was detected following high numbers of Malaria death reported by Namutumba District through the DHIS2.

#### 1.11.2 Maternal and Perinatal Death Surveillance and Response (MPDSR)

The Ministry of Health has been actively implementing MPDSR since 1998 in her efforts to improve quality of care and reduce maternal and perinatal mortality. In 2008, due to the high maternal mortality ratio and slow progress towards MDG targets; maternal deaths were declared a national emergency by the President of the Republic of Uganda. Over the years MMR has improved from 438/100,000 livebirths (UDHS 2008) to 189/100,000live birth (UDHS 2022). There are functional MPDSR committees at facility and National levels which meet regularly to review maternal and perinatal deaths.

The MPDSR focuses on three key data collection activities: 1) Identification: Health facilities are required to identify all maternal and perinatal deaths that occur within their care. 2) Notification: The system utilizes a two-tiered notification process. Upon identifying a maternal or perinatal death at a health facility, a standardized notification form is filled and entered into the DHIS2 system within 24 hours. 3) Cause of death determination: Investigations are conducted to determine the underlying causes of each death using the:1) HMIS 100 for Certification: Health facilities utilize the HMIS 100 form, which aligns with the ICD-11. However, implementation progress varies from facility to facility and by district.

#### 1.11.3 Rapid Mortality Surveillance (RMS) pilot Project:

Launched in response to COVID-19 in 2020, the Rapid Mortality Surveillance (RMS) project established a sustainable real-time all-cause mortality tracking system at both facility and community levels in 15 districts. It successfully integrated with DHIS2 via Mtrac, enhancing access to real-time data for public health decision-making.

#### 1.11.4 Systematic All-Cause Mortality Surveillance at Community Level-Pilot in Kibuku District:

In 2024, the Ministry of Health- Incident Management Team (MOH-IMT) with support from MAKSPH-METS Program, piloted an all-cause community mortality surveillance system in Kibuku District. This followed the need to strengthen all-cause mortality surveillance during the district led response in 2022 to control Malaria upsurge. This pilot was implemented to bridge the gap in death reporting at community and facility level and to understand the magnitude of deaths. The pilot highlighted the gap of under reporting at facility level as reflected in DHIS2; meaning that a big number of deaths found had occurred at facility but reported by community.

#### 1.11.5 Saving Mothers, Giving Life (SMGL):

<!-- Source PDF page 27 -->

This initiative (2012–2014, expanded later) addressed maternal mortality by tackling the “three delays” in care. Implemented in selected Western Uganda districts, it improved maternal death reviews, recordkeeping, and data-driven responses. The initiative led to better maternal death reporting and reduced institutional maternal mortality in the focus areas. Data from this good initiative is not available in national systems to support decision making-a missed opportunity.

#### 1.11.6 Mortality Surveillance for HIV and TB:

The causes of mortality among HIV and TB patients are closely related. In 2023, the Aids Control Program, working with the National TB & Leprosy Program then, developed Death Surveillance and Response (DSR) Implementation Guidelines for TB and HIV. These guidelines provide a framework for examining the causes of preventable deaths, guide decision-making and quality of care. The framework helps to identify common delays that are associated with recognizing danger signs from health–care seeking, reaching/linking to care, and receiving care at the facility. At facility level, information to inform the death reviews is obtained through chart reviews for HIV and TB patients using a standardized case review form. At community level, the information shall be obtained through verbal autopsy (to leverage available verbal autopsy forms). All deaths of any confirmed HIV or TB patient whether enrolled in care or not as long as they are confirmed should be notified within 24 hours and reviewed within 7 days of the occurrence.

The death review process is undertaken by the HIV/ TB work improvement team (WIT) committee (in this case also called the HIV/TB DSR Committee) or any designated committee. Members of the committee make in-depth investigation/review of each death to; understand the chain of events that led to the death, identify the causes and circumstances surrounding the death and generate key recommendations and remedial actions. These efforts standardized data collection and strengthened surveillance for HIV and TB. The missed opportunity here is that the information from the reviews is not integrated within national systems to enhance decision making-a missed opportunity.

#### 1.11.7 Mortality Surveillance implementation at the Uganda Cancer Institute (UCI):

The Uganda Cancer Institute has been implementing programmatic mortality data collection and analysis, and have UCI customized data management tools in use. Because of the current efforts to harmonise mortality surveillance implementation, they have shared these tools and processes, and are willing to harmonise their tools as well following the developed mortality surveillance guidelines, as it is critical to have complete picture on mortalities of all cause, across the country.

#### 1.11.8 Health Demographic Surveillance Sites like the Iganga-Mayuge Health & Demographic Surveillance Site (IMHDSS)

The Iganga-Mayuge Health and Demographic Surveillance Site (IMHDSS) which is managed by Makerere University Centre for Health and population research (MUCHAP) was set up in 2005. The main aim was to monitor key demographic events of birth, deaths

<!-- Source PDF page 28 -->

and migrations in a geographically defined population, within Iganga and Mayuge districts of Eastern Uganda.

Mortality surveillance in the HDSS starts with death notification and reporting from the community which is done by a network of scouts that includes VHTS, Local Council Chairpersons, and other opinion leaders. Whenever a death occurs in the surveillance area, a community scout records basic information about the death and immediately submits a report to the HDSS offices to be verified by the HDSS research team. After a mourning period of 4-6 weeks, the death reported is followed up by a MUCHAP CRVS research assistant to the household of the deceased to conduct a verbal autopsy interview. The CRVS research assistant conducts a face-to-face interview using a standardized WHO Verbal autopsy questionnaire (version 2016). After conducting a Verbal autopsy interview, the data is uploaded to the HDSS server, where it is synchronized and cleaned for analysis. Absence of linkage of this data with the MOH National systems is another missed opportunity as far as providing a complete picture of mortalities in this country is concerned.

#### 1.11.8 Mortality Surveillance implementation by the Uganda Funeral Services Umbrella Organization:

Funeral Homes play a key role in mortality surveillance by taking record of community deaths, where a person passes on outside a health facility, and the relatives call in for funeral home services. Funeral homes have data on the deaths, probable/medical causes o deaths, and other key variables related to the deceased. They however currently manage their data independently, and is not shared with the Ministry of Health in any way - another missed opportunity. They could contribute by accurately documenting death details, including time, cause, and circumstances, which might otherwise be missed. By following Ministry of Health guidelines, funeral homes will ensure that MS data is properly recorded and shared with health authorities. This data helps identify trends, emerging health concerns, and informs public health interventions. Staff training and collaboration with medical examiners and authorities will further enhance the effectiveness of mortality surveillance, ensuring timely and accurate reporting of deaths. In short, funeral homes are crucial for filling gaps in mortality data, supporting public health decision-making, and improving community health outcomes.

#### 1.11.9 Mortality Surveillance implementation by the Uganda Police Force:

The Uganda Police Force is a key stakeholder as far as identifying community deaths is concerned. When the police identifies these dead bodies, they are taken to the city/municipal mortuaries, where a medical cause of death is assigned by the police pathologist. MS data management is done using police report tools. When the dead bodies are not claimed by relatives, police goes ahead and conducts mass burials. This data is currently not finding its way to the Ministry of Health, and yet still majority of these deaths are not registered by NIRA – another missed opportunity. It is recommended therefore, that harmonized mortality data collection tools be developed and placed at the City/Municipal mortuaries, for purposes of documenting both numbers and any available

<!-- Source PDF page 29 -->

details from the deceased that are managed by the Police. The collected data can then be captured by the Ministry of Health through the DHIS2. Incase the dead bodies are not identifiable; the Uganda Police can identify them using forensics or DNA.

#### 1.11.10 Mortality Surveillance implementation in the refugee sites-by UNHCR:

The UNHCR implement mortality surveillance in the refugee hosting sites, using a comprehensive system, however the data is not ultimately shared with the ministry of health, and hence a missed opportunity for understanding who dies, when they die, why they die, and where they die from. This creates a gap in the public health surveillance space, and hence a gap in evidence-based decision making.

#### 1.11.11 Mortality Surveillance implementation using eCHIS

The Electronic Community Health Information System (eCHIS) is a mobile-based digital platform developed by Uganda's Ministry of Health to support community health workers (CHWs) in collecting and reporting demographic and health service data at the household level. Its main goal is to strengthen community health systems by replacing paper-based reporting with real-time, accurate, and standardized digital data, in line with the Health Information and Digital Health Strategic Plan 2020/21–2024/25. One of its key objectives has been to digitize at least 30% of Uganda’s 150,000 CHWs by 2025. The system includes modules for Integrated Community Case Management (iCCM), reproductive and maternal health, family planning, nutrition, and mortality surveillance. In its mortality data workflow, Village Health Teams (VHTs) and Community Health Extension Workers (CHEWs) register household deaths, capturing details like name, age, sex, date and place of death, and cause. These entries are reviewed and verified by health facility-based supervisors before being integrated into national databases for analysis. Lessons learned from the eCHIS rollout include the need for improvements in system fields (e.g., pre-filled guidance examples), gaps in district coverage and supervisor accounts, and limited data sharing mechanisms. Despite these challenges, eCHIS has demonstrated potential by integrating with DHIS2 for automatic reporting, reducing paper workload, and offering zero-rated internet access to ease usage by CHWs. Its inclusion in Uganda’s mortality surveillance guidelines would reflect a step forward in strengthening real-time, community-based mortality data collection and use.

**_The figure below describes the disparate mortality data collection streams identified_**

<!-- Source PDF page 30 -->

![Source illustration — PDF page 30](images/illustration-030-007.png)

**_Figure 1: Current (June, 2025) Data Flowchart_**

<!-- Source PDF page 31 -->

## Chapter Two: Legal And Ethical Considerations For Mortality Surveillance

### 2.0 Introduction

Mortality surveillance in Uganda has been crafted based on the constitution, relevant laws, and strategies, including ethical principles, by promoting informed consent, confidentiality, fairness, and the respectful use of data to improve public health, while protecting the rights of individuals and avoiding harm or discrimination, especially among vulnerable groups. In case of ambiguity and/or conflict with any related legal provisions and policies shall prevail.

### 2.1 Legal Frameworks Enabling Mortality Surveillance in Uganda

Mortality surveillance is intricately linked with national laws which are in tandem with global, regional frameworks and guidelines as shown below.

**Table 1: Legal Frameworks Enabling Mortality Surveillance in Uganda**

||**Legal Frameworks Enabling Mortality S**|**urveillance**|
|---|---|---|
|**Global**|**Regional**|**National**|
|**United Nations Sustainable** **Development Goals:** _SDG_ _17.19.2 guides UN member_ _states on achieving 100% birth_ _and 80% death registration by_ _2030_|**Africa CDC Continental Framework on** **Strengthening Mortality Surveillance Systems** **in Africa:** _Encourages member states to_ _strengthen mortality surveillance_ _implementation by addressing challenges_ _related to data quality, completeness,_ _timeliness, standardization, capacity, and_|**The Constitution of the Republic of Uganda** **1995 as amended:** _Chapter Three of the_ _Constitution gives the state authority to_ _register every birth, marriage, and death_ _occurring in Uganda_._It places a duty on the_ _state to ensure that all deaths are officially_ _recorded, thereby supporting legal identity,_|
|**WHO International Health** **Regulations (IHR) 2005:** _Member states, including_ _Uganda, are guided to_ _strengthen national surveillance_|**Africa Agenda 2063:** _Calls for improving Civil_ _Registration and Vital Statistics Systems to:_ _Provide universal birth and death registration,_ _support the production of timely and accurate_ _statisticsfor development_|**The Public Health Act 2022:** _notification and_ _reporting of deaths, especially those related to_ _communicable diseases and other public_ _health concerns_|
||**The African Programme for the Accelerated** **Improvement of Civil Registration and Vital** **Statistics (APAI-CRVS):**_It aims to strengthen_ _CRVS systems in Africa so that every person,_ _for example, in Uganda, is counted, and every_ _vital event is registered, including death._|**The Registration of Persons Act** **(Amendment) Act 2024 (ROPA):**_Section 41 of_ _the Act mandates the compulsory registration_ _of all deaths within the country._|
|||**The Births-and-Deaths-Regulations-** **2015:**_Under Section 15, all deaths occurring in_ _Uganda shall be registered._|
|||**The Citizenship and Immigration Control Act** **of Uganda (1999, as amended):**_This is_ _particularly relevant in border districts or_ _refugee-hosting communities, where_ _unrecorded migrant deaths influence mortality_|

![Original table layout — PDF page 31](images/table-source-page-031.png)

<!-- Source PDF page 32 -->

### 2.2 Non-Legal & Strategic Frameworks supporting MS in Uganda

These provide a strong framework of strategies enabling mortality surveillance and interoperability in Uganda. They provide for death registration, standardizing cause-ofdeath reporting, and ensuring coordinated data collection and use across sectors. Worth mentioning are the Uganda Health Information and Digital Health Strategic Plan 2020/21 – 2024/25, and the National Community Health Strategy (NCHS) 2024.

#### Implications of Non-Adherence to the Law

Mortality surveillance entails many interactions and processes that sometimes include field challenges such as deliberate underreporting, inaccurate data, failure to notify of deaths, data tampering or leakage, interference in inquest processes, failure to conduct death reviews, non-compliance with MCCD procedures, disregard to rules during epidermic/ infectious disease response, and other forms of negligence.

**Legal Implications:** Non-adherence may result in legal action, professional sanctions, or administrative penalties. For example, failure by health facility staff to submit weekly death reports may be prosecuted under the Public Health Act.

### 2.3 Ethical Considerations for Mortality Surveillance in Uganda

In Uganda, ethical considerations are critical to ensure that surveillance respects human rights, cultural norms, and individual dignity while generating useful health data, and therefore should be upheld as supported by among others, the **Data Protection and Privacy Act 2019** and the **Public Health Act 2022** . Below are the key ethical principles and their specific applications:

#### 2.3.1 Privacy and Anonymity

Privacy refers to the **right of individuals to control access to their personal information,** including data about their health, identity, and death circumstances. **Mortality Surveillance** should ensure that death-related data is collected, stored, and used **only by authorized persons and for lawful purposes** . This is enforced under Uganda’s **Data Protection and Privacy Act (2019)** . For **example,** a death notification form containing a person's name, age, and cause of death must not be shared outside of authorized channels.

Anonymity refers to the removal or concealment of identifiers (like names, ID numbers, or addresses) so that individuals cannot be traced from the data provided. MS should employ techniques to remove and /or mask personal identifiers in data processing. It is a requirement that all discussions should be anonymous.

#### 2.3.3 Confidentiality

<!-- Source PDF page 33 -->

MS should ensure that data collected during surveillance is handled confidentially and protected from unauthorized access. Permission should be obtained to speak to family members and healthcare providers. Confidentiality should further be upheld through training the Mortality Surveillance teams in ethical conduct using a standard curriculum. Reference should be made to the Public Health Act 2022; Uganda Research Guidelines

#### 2.3.4 Integrity

Integrity should be adhered to during the collection, reporting, analysis, and use of mortality data. Health workers should ensure that mortality data is captured accurately, reported truthfully, using standardized nationally approved mortality surveillance tools, and used responsibly to inform public health decisions. All data collectors and handlers must remain impartial and committed to protecting the dignity of the deceased and the rights of bereaved families.

#### 2.3.5 Beneficence

Data for mortality surveillance should be collected in such a way that benefits others, promoting their well-being and legitimate interests.

#### 2.3.6 Autonomy

Mortality surveillance should respect the rights, safety, and well-being of all participants in all proceedings at all levels. Family and community members should be fully informed about the voluntary nature of the review process, their right to pause interviews, and should ideally give consent before being interviewed.

Consent to perform **verbal autopsies** is provided for in the Patient Rights and Responsibilities Charter. When conducting verbal autopsies or community death investigations, informed consent should be sought from the deceased’ closest relative or caregiver, or next of kin.

The families of the deceased must be told the purpose of the data collection, what information will be collected, and that participants can withdraw any time during the process.

The National Mortality Surveillance Secretariat shall adapt the WHO Verbal Autopsy tools, and give guidance on usage in the Uganda Public Health Surveillance Space.

#### 2.3.7 Non maleficence (Minimizing Harm and Psychological Distress)

To minimize harm and psychological distress, interviewers must be trained to engage grieving families with empathy, recognize signs of distress, choose appropriate timing, and provide support or referrals when needed.

#### 2.3.8 Cultural and Religious Sensitivity

<!-- Source PDF page 34 -->

Given the cultural sensitivity of death in Uganda, surveillance teams should respect local mourning practices, avoid disrupting ceremonies, and consult local leaders when necessary.

#### 2.3.9 Equity and Non-Discrimination

Mortality surveillance must be inclusive, avoiding bias based on gender, ethnicity, religion, location, or socioeconomic status. Special efforts should target marginalized groups and rural communities, with data used to promote health equity.

#### 2.3.10 Transparency and Accountability

Communities should be informed about why deaths are tracked, how data will be used, and how privacy is protected. Systems must allow for feedback and address concerns. This will be routinely done through MS review meetings organised at national, regional, district and health facility level, comprising all MS stakeholders at that level.

#### 2.3.11 Use of Data for the Public Good

MS data must inform health policies and benefit the public, not be used for political, commercial, or discriminatory purposes. Findings should be shared to encourage community action. Surveillance data not shared beats the reason for its collection, hence data use must be demonstrated at all levels e.g. through generation of disease burden tables, prediction of outbreaks, quality improvement projects developed to resolve challenges leading to further deaths, among others.

#### 2.3.12 Ethical Oversight for Research Purposes

Research-related components using mortality surveillance data must be reviewed by accredited by the MS Secretariat, then by ethics bodies, including UNCST, to ensure respect for rights and adherence to national and international ethical standards.

<!-- Source PDF page 35 -->

## Chapter Three: Identification And Notification Of Death

### 3.1 Introduction

This chapter highlights the processes of identification and notification of deaths both in the community and health facility. It clarifies the key informants reporting deaths, the tools used for identification and notification and the timeline for death notification. There are two levels across which identification and notification of deaths can be done, and these have been identified as community and health facility. The process involves various actors and systems to ensure proper documentation, reporting, and response. These processes are critical for legal, public health, and administrative purposes.

### 3.2 What is Death?

The World Health Organization (WHO) defines Death as t he permanent disappearance of all vital functions, without the possibility of resuscitation, after a live birth.

The World Health Organization (WHO) definition of "community death" refers to deaths that occur within the community.

A community is a specific group of people, usually living in a defined geographical area, who share common values, norms, culture and customs, and are arranged in asocial structure according to relations which the community has collectively developed over a period of time (National community Health Strategy).

### 3.3 Identification of death

Death Identification involves detecting death events as they occur, or retrospectively collecting data on deaths that have occurred through the community or health facility.

### 3.4 Notification of death

The process of informing relevant parties about a death.

#### 3.4.1 Identification and Notification of death in the Community

At the community level, deaths are often first identified or detected by family members, neighbors, or community gatekeepers through routine household visits, or when called upon. By definition, any death occurring outside a health facility is termed as a community death. Community deaths can occur in households, places of mass gatherings (worship, places of entertainment, shrine, schools, Markets) roads, water bodies, game parks and many others. Community informants may be the first to identify such a death. These individuals typically inform local authorities who normally fall in the category referred to as gatekeepers.

Accurate reporting on the numbers and causes of death remains essential for effective public health planning, disease surveillance, and policy development. One of the critical mechanisms for gathering this data, particularly in rural and hard-to-reach areas, is

<!-- Source PDF page 36 -->

through key informants - individuals within communities who play a central role in identifying and reporting deaths. These also fall in the category of community gatekeepers.

Community gatekeepers in Uganda include village health teams (VHTs), local council leaders, internal security personnel, funeral service providers, traditional healers, religious leaders, and sometimes schoolteachers or elders, among others. These individuals are well-integrated into their communities and are typically the first to be informed when a death occurs. Due to their accessibility and trust within the population, they are strategically positioned to collect information on deaths that occur outside formal health facilities, which are common in many parts of the country.

These community gatekeepers are tasked with recording basic information about each death, including the demographics of the deceased, place and date of death, and suspected cause. This should be done using standardized tools and involves interviewing next of kin or caregivers, about the symptoms and circumstances preceding the death.

For the purpose of surveillance, any person can notify of a community death by sending a message to MoH by using eIDSR platform (6767), as soon as the death is identified i.e. within 24 hours of the death occurence. This message should comprise the key parameters of person, place and time i.e. The person (Name, gender and age) who has died; place (district, sub county, parish and village); Time (date of death occurrence); and symptoms displayed by the patient before death. In case the human remains are identified at a location but outside the facility for instance mortuary, funeral homes among others, these locations should be part of the message.

In case of the need to process a death certificate through NIRA, Death notification at community level will involve the person present at the time of death notifying the death by informing the sub county chief or Town Clerk through word of mouth. Alternatively, the notifier can fill NIRA Form 12, and submit this to the sub county chief or Town Clerk. These Officers will then record this death in the mortality register, or in the NIRA MVRS system. Upon completion of this process, the notifier is issued with a death notification record, which is required for death registration.

This death notification record will then be presented to (any) NIRA office for purposes of registering the death and hence issuance of a death certificate.

#### 3.4.2 Identification and Notification of death in the health facility

At the health facility, death identification refers to the formal process in which a health worker recognizes and confirms that a death has occurred and documented accordingly using structured HMIS tools.

At facility level a Medical Officer is responsible for confirmation of death. Any trained health worker can identify and notify a death at a health facility. In cases of sudden or unexplained deaths, the health facility may involve forensic or legal authorities.

<!-- Source PDF page 37 -->

According to the World Health Organization (WHO), a health facility is a formally recognized place that provides healthcare services. This includes all types of health facilities, such as hospitals, health centers, clinics, health posts, and temporary structures during emergency situations, regardless of whether they are Public, PFP or PNFP.

A death notification in a health facility is the formal process by which the death is notified to the Ministry of Health. This should be done within 24 hours of occurrence of the death event. This should be done by the attending health worker or any authorized personnel who has reviewed the medical records of the deceased, and the process is compulsory and free of Charge. In a health facility setting, the family or relatives will assist the hospital in providing correct socio-demographic details of the deceased.

For conditions like Maternal or Perinatal deaths, there are pre-designed notification forms in the national HMIS which are used for notification within 24 hours of occurrence of these deaths, and audit forms for use within 7 days of occurrence of the deaths. All health facilities are supposed to record all deaths in the national reporting system HMIS/DHIS2 for ease of access by all relevant stakeholders.

The Ministry of Health is still finalizing modalities to have the DHIS2 speak to the NIRA MVRS system, but in the meantime, since it is a requirement by NIRA, to have all deaths registered, incase of a death within a health facility, the records department should support in completion of the NIRA Form 12, which is then captured into the NIRA MVRS system (where it exists), after which a notification record is issued by the health facility. This notification record should be stamped and signed off by the health facility administrator. This death notification record will then be presented to (any) NIRA office for purposes of registering the death and hence issuance of a death certificate.

### 3.5 Tools for death identification and notification

The sources of data on deaths from health facilities include registers, patient files and the Electronic medical records (EMRs) systems. Data from the registers is filled into relevant HMIS datasets/report forms or electronic medical records system as described in chapter 4 on data management. In addition, notifications to NIRA should be done using Form 12, available at the subcounty offices and health facilities.

When a death occurs on arrival from a community before being attended to by a health worker, it is notified as a community death.  In instances where a death occurs in transit within an ambulance, and the patient was referred with official documentation from one health facility to another, the death should be classified as a facility-based death attributed to the referring health facility. In a situation where an individual dies in the premises of the receiving facility after formally accepting the referral, this is considered a death of the receiving facility.

<!-- Source PDF page 38 -->

### 3.6 Timeline for death notification

Notification of death, whether in the community or health facility should be done within a period of 24 hours after identification of the death event.

### 3.7 Death identification and notification in complex settings/situations

Mortality surveillance in complex situations such as armed forces in operational zone, disasters, unclaimed & unidentifiable bodies, missing persons, conflict situations, Death of foreign national, Death of Ugandans abroad, and detention center requires tailored approaches due to distinct environmental, administrative, and health system challenges. These situation/settings are often not integrated well within the general health system but are critical to national health surveillance. This chapter provides comprehensive guidelines for implementing mortality surveillance in these situations/settings to ensure accurate and timely reporting of deaths regardless of location or circumstance.

#### 3.7.1 Armed forces (UPDF, UPF, UPS)

In the armed forces, deaths may occur in operational zones or training environments where standard reporting is disrupted; thus, UPDF, UPF or UPS health systems should be equipped with confidential and secure mortality documentation protocols.

##### 3.7.1.1 Deaths in the Operational Zone

When armed forces personnel die in the operational zone, a trained medical officer should verify the death by conducting a postmortem at a designated field facility/area.

The verified body should be taken to the health facility of choice if death occurred within the country, or a temporary holding facility for death occurring in a foreign country before being repatriated to a health facility in Uganda.

The health facility may conduct further examination to confirm the cause of death and issue the medical certification of cause of death.

The records officer should ensure that the death is notified and reported to the Ministry of Health. Thereafter, the next of kin shall register the death with NIRA for the issuance of a death certificate.

##### 3.7.1.2 Other deaths of armed forces outside the operational zone

Deaths of armed forces personnel that may occur outside the operational zone such as at health facilities or communities should be reported using the established health facility or the community structures.

##### 3.7.1.3 Deaths at Detention Centers

Mortality surveillance is critical in settings where individuals are held under state custody, such as prisons, police cells and other gazette centers. These facilities house

<!-- Source PDF page 39 -->

some of the most vulnerable populations, including pre-trial detainees, and convicted individuals, many of whom may already experience poor health, marginalization, or lack of access to care before incarceration.

Effective surveillance at detention centers requires coordination between correctional authorities, health departments, and forensic experts. It also necessitates timely death reporting, standardized classification of causes of death, and mechanisms for death reviews.

When a death occurs at any of the detention centers, the body should be taken to a designated health facility for postmortem or forensic examination to establish the cause of death.

All such deaths should be reported as community deaths by the responsible entity operating the detention center using SMS 6767 and subsequent filling of the NIRA Form 12.

#### 3.7.2 Disaster Situation

Disaster situations such as floods, landslides, droughts, earthquakes, and fires disrupt social services, displace populations, and challenge health systems and civil registries in recording and reporting deaths. Mortality surveillance is essential but difficult to manage in these chaotic environments. Proper identification of bodies, handling of unclaimed remains, and tracking missing persons require proactive and wellcoordinated approaches.

Body recovery and identification should involve collaboration among rescue teams, including police, community members, Office of the Prime Minister (OPM), and humanitarian agencies. Families should be given the opportunity to identify human remains of their persons, while forensic experts conduct post-mortem examinations on unidentified bodies. DNA analysis can assist in identifying severely disfigured remains, and unidentified body parts may be buried in mass graves. Maintaining an updated register of missing persons in coordination with authorities is vital for tracking individuals.

Extreme events may lead to delayed body recovery, requiring exhumation weeks or months later. All disaster-related deaths should be reported to designated authorities, including community gatekeepers, rescue teams, and national surveillance systems. Proper reporting mechanisms, such as Form 12 or SMS 6767 for community deaths and HIMS 100 for health facility deaths, ensure accurate mortality tracking and response planning

#### 3.7.3 Unidentified or unclaimed human remains

<!-- Source PDF page 40 -->

Unidentified or unclaimed human remains risk being excluded from mortality data, necessitating collaboration among health departments, security personnel, local governments, and the Ministry of Gender, Labor, and Social Development to ensure proper documentation and investigation. Exposited deaths, where bodies are abandoned in public places like streets, water bodies, and forests, demand urgent forensic and public health responses. Failure to address such cases weakens national mortality statistics, making a systematic approach vital.

Upon discovering an unidentified body, any community member should inform local authorities such LC chairperson, security organs, VHTs, CHEWs, health authorities or send a report to the Ministry of Health via SMS 6767. Police should open a case file, document the scene, and conduct searches for identification, filling out Police Form 48A for exposited deaths. If a postmortem is performed on-site, the medical officer completes Police Form 48C. If a postmortem cannot be conducted at the scene, the body is transported for further examination, and findings are recorded using Police Form 48B.

At the mortuary, the body should be assigned a number, photographed, and stored. Forensic experts may use DNA analysis, thumbprints, or iris recognition to confirm identity. All unidentified exposited bodies are classified as community deaths and Police should ensure that such deaths are notified and reported accordingly using their established procedures, while those who might die later in health facilities are documented following health facility protocols.

#### 3.7.4 Deaths of Ugandan in a foreign country

When a Ugandan citizen dies abroad, a coordinated effort is essential to ensure proper notification, identification, and repatriation of the remains. This process involves airlines, embassies, the Ministry of Foreign Affairs, and Interpol. Airlines should facilitate the transportation of the remains, adhering to international regulations. Embassies should assist in obtaining necessary documentation, such as death certificates, embalming certificates, and coordinate with local authorities.

The Ministry of Foreign Affairs should oversee the coordination of consular services, including the repatriation of remains, and provide guidance on required documentation and procedures. Interpol should facilitate cross-border communication and cooperation, assist in verifying identities and coordinate with international law enforcement agencies when necessary. This multi-agency approach should ensure that the remains of Ugandan citizens abroad are handled with dignity and respect, in accordance with both Ugandan and international standards.

For purposes of mortality surveillance, such death shall be captured at the point of entry into Uganda. However, if a Ugandan dies in transit to/from Uganda by road, such deaths should be reported to the authorities of the country where the death has occurred before

<!-- Source PDF page 41 -->

repatriation, and if the death occurs mid-air, the airplane crew should report such death to the authorities where the deceased boarded from and later to Uganda.

At the point of entry into Uganda, a medical cause of death certificate should be presented to the port health staff to capture the details of the deceased in the mortality register. However, if such documents are missing or when the death is suspicious, a laboratory sample or postmortem maybe conducted from the nearest health facility. The port health staff should do the necessary documentation, and notify the Ministry of Health accordingly.

For human remains that may enter through undesignated point of entry, the community gatekeepers should report such death using the SMS 6767 and the next of kin can use NIRA Form 12 to notify the death.

#### 3.7.5 Death of foreign nationals in Uganda

Deaths of foreign nationals whether tourists, migrant workers, asylum seekers, or expatriates present unique challenges for mortality surveillance. These cases often fall outside regular civil registration systems, requiring coordination with embassies, consulates, immigration departments, and international agencies. Proper documentation and respectful handling are crucial for national public health intelligence and maintaining diplomatic relations.

All deaths of foreign nationals especially outside the health facilities should be reported to authorities such as LCs or security agencies, with police collaborating with health officials for documentation.

The police should complete the relevant forms such as Police Form 48A, 48B, and NIRA Form 12 for notification of such deaths, and HMIS 100 should be completed in case of deaths occurring at the health facility.

#### 3.7.6 Missing Persons – Presumed Death

Uganda’s Registration of Persons Act (ROPA) 2024, as amended, presumes a missing person dead if they have not been heard from for seven years or more. However, the death is not automatically registered unless the family obtains a court declaration. These cases often arise due to armed conflict, abductions, migration, domestic violence, or natural disasters. Despite their social and legal significance, such deaths are rarely documented in civil registration systems, leading to data gaps.

Families must report missing persons to the police, who issue a Missing Person Report (MPR) and record the case in the Uganda Police Force’s register. If initial tracing efforts fail, public alerts such as radio announcements and posters may be used. During disasters like floods or landslides, local authorities coordinate with agencies like the Office of the Prime Minister (OPM) and Uganda Red Cross to search for survivors and recover bodies.

<!-- Source PDF page 42 -->

After seven years, families can petition the Chief Magistrate’s Court for a presumption of death order, providing evidence of the person’s prolonged absence and unsuccessful search efforts. Once granted, the order should be submitted to the National Identification and Registration Authority (NIRA), which registers the death and issues a certificate labeled “Presumed death – court declaration.”

### 3.8 Identification and Notification of death in the Community

#### a) Through NIRA reporting pathway

![Source illustration — PDF page 42](images/illustration-042-009.png)

**_Figure 2: Identification and Notification of death in the Community through the NIRA pathway_**

- **_a) Through MOH reporting pathway_**

![Source illustration — PDF page 42](images/illustration-042-010.png)

**_Figure 3: Identification and Notification of death in the Community through MOH pathway_**

<!-- Source PDF page 43 -->

## Chapter Four: Reviewing Of All Deaths

### 4.0 Introduction

This chapter highlights the processes for reviewing all deaths that occur in health facilities and communities across Uganda, regardless of the underlying medical condition. Reviews may involve audits, verbal autopsies, or both. Once reviewed, causes of death shall be coded using the International Classification of Diseases, 11th Revision (ICD-11). Conducting mortality reviews entails systematic data collection, analysis, and recommendations for improvement, and action planning/response based on the findings. Aggregated findings should guide multi-disciplinary responses at community, facility, district, regional, and national levels, to prevent avoidable deaths and inform health policy and programming.

### 4.1 Which Deaths Should Be Reviewed

All deaths occurring at health facility and community levels should be reviewed. Reviews should be conducted within seven days of the death occurrence for facility death and within 4 weeks for community deaths.

### 4.2 Who Should Conduct Mortality Reviews?

Mortality reviews should be conducted by facility or district-level Death Review Committees (DRCs). Review committees may be adapted from existing structures such as surveillance sub pillar, Maternal & Perinatal death committees (MPDSR), Medicines and Therapeutics Committees or Quality Improvement (QI) Teams. These committees are responsible for assessing the sequence of events leading to each death, identifying contributing factors, and recommend/ implement corrective actions.

### 4.3 Levels and Functions of Death Review Committees

Death Review Committees should be established at national, regional, district and health facility levels. Each committee shall have a distinct composition and mandate, with clearly defined Terms of Reference as guided in this MS guidelines document.

**Table 2: Leadership for mortality review committees at various levels**

|Level|Chairperson|
|---|---|
|National level|Director General of Health Services|
|Regional level|Senior Executive Consultant of the Regional Referral Hospital|
|District level|Executive consultant of the general hospital|
|Health facility level|Officer in charge of the respective health facility.|

![Original table layout — PDF page 43](images/table-source-page-043.png)

<!-- Source PDF page 44 -->

### 4.4 Procedure and Tools for Effective Death Reviews

To ensure successful death reviews, it is essential to have functional death review committees, accurate/clear/complete patient documentation, access to patient records, and use of a standardized all-cause death review tool. Committees should meet regularly as guided, and follow through on the implementation of their recommendations to ensure quality improvement to prevent further deaths due to similar conditions, as well as account for the deaths through analysis and trends. The harmonized all cause death review form discussed in this MS guidelines document is going to be used for reviewing all deaths.

![Source illustration — PDF page 44](images/illustration-044-012.png)

<!-- Start of picture text -->
Death confirmed at health facility level Death notified within 24 hours Death reviewed within 7 days Death is certified Modifiable factors and corrective actions generated <!-- End of picture text -->

### 4.5 Conducting a Death Review Session

Review sessions should be conducted regularly as guided (after 7 days of occurrence of death event at health facility level, and after 21 days of occurrence of a community death), and involve all committee members as per the schema below;

A thorough record of the deceased's care and circumstances should be compiled. This includes medical records from paper-based systems or Electronic Medical Records systems, death notification and review forms, verbal autopsy reports for community deaths, interviews with caregivers or staff and any available death certificates or autopsy reports.

All data must be anonymized and protected by confidentiality agreements, as guided by Chapter 2 of this implementation guideline. The death review form shall be used to compile information about the deceased into one document to make it available for the death review committee meeting.

### 4.6 Dos and Don’ts while conducting Death Reviews

#### DOs

- Maintain a blame-free environment

#### DOs

   - Maintain a blame-free environment

- Use standardized tools (Death Review Form and ICD-11)

- Involve all committee members for a multidisciplinary view.

- Ensure timely reviews within the set window (7 days).

- Uphold confidentiality and ethical handling

- Use standardized tools (Death Review Form and ICD-11)

- ● Involve all committee members for a multidisciplinary view.

- ● Ensure timely reviews within the set window (7 days).

- ● Uphold confidentiality and ethical handling

<!-- Source PDF page 45 -->

### 4.7 Procedure for Medical Certification of Cause of Death

The Medical Certificate of Cause of Death (MCCD) form was designed to standardize the reporting of causes of death across countries to facilitate intra- and inter-country comparisons of causes of death. Use of this standardized form is recommended to ensure the correct application of the ICD rules and principles for mortality coding and the resulting selection of the underlying cause of death by cause of death coders.

The cause of death is reported in a logical, sequential fashion using HMIS form 100 in Part 1 of Frame A, while Part 2 of Frame A is used to record other conditions which contributed to, but did not directly cause, the death as described in the figure below;

![Source illustration — PDF page 45](images/illustration-045-013.png)

#### 4.7.1 Frame A part 1

Part 1 focuses on the chain of events leading to the death, starting with the immediate cause of death and then listing the underlying causes.

**The underlying cause of Death (d)** is the disease or injury (or poisoning) that initiated the chain of events that led directly and inevitably to death, and it could be the root cause of death.

**The antecedent or intermediary cause of death (c), (b)** is the condition(s) that led to or precipitated the immediate cause of death but occurs at the time between the underlying cause of death and the immediate cause of death.

**The immediate cause of death (a)** is the final disease, injury, or complication—resulting from the underlying cause of death—that directly causes death.

They are written in that order, clearly depicting the sequence of events upwards to end with immediate cause (a).

The sequence will give the order of the relationship between events leading to death both concerning time and etiological or pathological relationship. The entire sequence gives the complete picture of the cause of death.

The importance of recording the sequence correctly lies in the fact that appropriate strategies can be adopted to cut the chain at its most vulnerable point and thus prevent death.

Due thought should be given to the last entry as it is picked up for statistical purposes as the underlying cause of death (d).

<!-- Source PDF page 46 -->

Consequently, if there is no chain of events and the underlying cause is the only event, it should be entered under (a) as it is both the immediate & underlying cause.

Line (a) must always have an entry

#### 4.7.2 Frame A part 2

This part addresses other significant conditions that contributed to the death but are not directly related to the primary cause.

If the individual was suffering from any other disease which is not related to the underlying cause and hence cannot be part of the sequence, but, in the opinion of the certifier, has contributed to death, such a condition too is to be recorded in the certificate.

However, if the co-existing disease has not contributed to death, it has no place in the medical certificate of cause of death.

### 4.8 General Instructions while completing the HMIS 100

1. Frame A has to be filled up by the doctor who has full knowledge of the events which led to death.

2. The names of the diseases should be written in full, legible handwriting, preferably in block capital letters. Abbreviations and short forms of diseases are not to be used as they are likely to lead to confusion.

3. Do not use mode of death as these represent the final common pathway for many of causes of death and does not provide detailed information about the underlying cause. Common modes of death are cardiac arrest, heart failure or respiratory failure. If at all entered, the disease which led to them must be entered in the next line. They cannot be the sole entries.

4. Only one condition or event should be entered per line in Part 1

5. A time interval must be recorded for the condition on each line listed in Frame A, indicating the elapsed time between the presentation of each condition (not the time of diagnosis) and the date of death. The listed time intervals can be estimates, using terms such as minutes, hours, days, weeks, months or years. The time intervals should either increase or stay stable in the causal sequence from Part 1a to Part 1d (or the lowest line used) but should not decrease.

6. Causes of death should be described using terms that are as diagnostically and etiologically specific as possible. For example, the term “Type 2 diabetes mellitus” should be used instead of “diabetes mellitus”; likewise, “end-stage renal failure” is more informative than the less specific “renal failure”.

7. In rare circumstances, it is possible to list the UCOD as “unknown cause”. The use of this term is discouraged, but is not prohibited, because in some cases there is no information or confirmation of the cause of death.

### 4.9 Specific Instructions:

Once a death has occurred, the nurse should call the doctor who attended to the deceased to confirm that the death has indeed occurred.

<!-- Source PDF page 47 -->

Steps to be followed;

1. A nurse, clinical officer, or intern doctor on duty should fill Section 1a, 1b, and frame C of the HMIS form 100 - the notification of death.

![Source illustration — PDF page 47](images/illustration-047-014.png)

![Source illustration — PDF page 47](images/illustration-047-015.png)

2. The medical records officer should get the deceased’s file containing the HMIS 100 with the filled-in parts 1a, part 1b, and Frame C (Death notification).

3. The medical records officer should then enter the information on Part 1a, part 1b, and Frame C into the EMR which will transmit data to MCCD/ICD11 app in DHIS2.

4. Once the information is entered into EMR, the records officer MUST return the filled HMIS form 100 to the ward for the Medical Doctor to certify the death/ fill in the sequence of cause of death and complete the other sections of the form if it has not yet been done already.

5. The doctor should then fill in frame A and complete the declaration section on the HMIS form 100 - for certification of the cause of death.

![Source illustration — PDF page 47](images/illustration-047-016.png)

#### Declaration – The last part of the form is a declaration, which appears as below;

I hereby certify that ( _tick as appropriate_ ) a) I attended to the deceased before the death  b) I examined the body after death

c) I conducted the post-mortem of the body

d) Other (specify) …………………………………

Medical Practitioner’s Name: ……………………………...Signature

………………...Date………/……/………….

6. Once information is captured, it should be transmitted into DHIS2 either by way of the EMR in use, or directly into DHIS2 where the EMR is not in place. This same data is shared with NIRA by use of the API.

<!-- Source PDF page 48 -->

### 4.10 Guiding Principles for Reviewers

Death reviews should be guided by core principles that ensure they are effective, ethical, and focused on improving health outcomes. They should be conducted in a confidential and nonpunitive environment, fostering open discussion without assigning blame. Respect and professionalism among multidisciplinary teams are essential, with a focus on evidence-based analysis using clinical data and standardized tools. Reviews should be timely and result in actionable recommendations aimed at preventing future deaths, with clear accountability for follow-up and implementation. Cultural sensitivity is important, especially when engaging with communities, and the process must support learning and continuous improvement across the health system.

#### Summary of the DOs while completing the MCCOD form

1. Do verify the name of the deceased person on the MCCD, and always ensure that you complete the form for the correct deceased person.

2. Do prepare a draft of the sequence of events and conditions and time intervals you plan to include in Frame A of the MCCD form, both in Part 1 (Causal sequence of events/conditions leading to death) and Part 2 (Contributory causes).

3. Do include in your draft clarifying details, as much as is available to you, for each medical condition and event you list. This allows for more diagnostic specificity and improves the quality of your information. For example, if the death was due to cancer, make a note of the type of malignancy, the site.

4. Do formulate specific causes. Use your best clinical judgement and the information available to you to clarify the terminology and provide the most a etiologically specific underlying cause of death (UCOD).

5. Do make sure that the causal sequence you have written makes sense. A useful check is as follows: Read the Part 1 Cause of Death statement from the highest to the lowest line, inserting “due to” between the lines. Make sure it makes logical and chronological sense. Then check the time interval column and ensure that the time intervals increase or stay stable from top to bottom.

6. Do complete all parts of the form, including the pertinent sections in Frame B.

7. If using a paper format, do write legibly and complete the form in pen using an acceptable color (i.e. black).

8. Do check for errors, and ensure your name and title are correctly listed before signing in pen or electronically.

#### The Don’ts

1. Do not leave Part 1 blank.

2. Do not make alterations or erasures or use correction fluid on a paper MCCD form

3. Do not use abbreviations. Some mortality coding offices may accept certain common abbreviations such as HIV and AIDS, but others may not. Using abbreviations may result in incorrect interpretation of the information on an MCCD and should be avoided.

4. Do not report modes of death without an associated underlying cause of death. Likewise, do not use etiologically nonspecific causes of death as an underlying cause of death unless no other additional information is available.

<!-- Source PDF page 49 -->

### 4.11 Community-Based Death Reviews

Deaths in the community are reviewed using verbal autopsies. Verbal autopsy (VA) is a method used to determine the cause of death through interviews with the deceased person's next of kin or caregivers. These interviews involve a standardized questionnaire to gather details on symptoms, medical history, and the circumstances leading to death. Healthcare professionals or algorithms then analyze this information to identify the likely cause of death. The primary goal of verbal autopsy is to describe the causes of death at the community level or population level in areas where there is no medical certification of deaths.

Community health workers identify and report deaths, caregivers are interviewed, and available health records are reviewed-this exercise is done by health workers (facility death review committee) in the facility where the respective community is attached. A medical officer then assigns an ICD-11 code based on the verbal autopsy tool to determine the probable cause of death. The findings should be reported to district health teams for integration into district mortality reports.

**Verbal Autopsy (VA) Procedure** : Upon receipt of information from the VHT about a death in the community, the health worker notifies the facility death review committee, which schedules to visit the household where the death has occurred, to conduct an interview with the next of kin of the deceased on the circumstances surrounding the death. The trained health worker shall conduct the interview based on the adapted WHO Verbal Autopsy standard tool. This should be done within 21 days of the occurrence of the death event.

After a Trained Community Health worker has done a verbal autopsy, a Medical Doctor within the health sub district accesses the record of the interview to review and come up with a probable cause of death. This shall also be done within 30 days period, from the occurrence of death.

### 4.12 Death Review Summary and Reporting

At the conclusion of the review process, all findings should be summarized in standardized reports. These reports feed into district, regional and national mortality reports, providing data for health systems improvement and public health interventions.

### 4.13 Role of Laboratory in Mortality Surveillance

The laboratory plays a crucial role in providing definitive diagnostic evidence that supports the accurate determination of causes of death. Laboratory services enhance the quality, reliability, and timeliness of mortality data, especially in cases where clinical diagnosis alone is insufficient. It verifies causes of death, supports disease outbreak detection, enables characterization of pathogens, and informs response strategies.

#### 4.13.1 Key Functions of the Laboratory in Mortality Surveillance

The laboratory professionals in collaboration with Morticians/Pathologists shall be responsible for the collection, packaging, transportation, and analysis of the mortality surveillance samples

<!-- Source PDF page 50 -->

to identify pathogens, toxins, biochemical markers, and cellular abnormalities to confirm the cause of death.

#### 4.13.2 The Role of Reference Laboratories

The reference laboratory shall be responsible for performing laboratory tests according to their mandate, especially in outbreak confirmation. They will ensure quality control and assurance for the lower or field laboratories. The reference laboratories currently include the following:

- i. Central Public Health Laboratory (CPHL)

- ii. Uganda Virus Research Institute (UVRI)

- iii. Department of Government analytical Laboratory (DGAL)

- iv. National Tuberculosis and Leprosy Reference laboratory (NTRL)

- v. Mulago hospital pathology laboratory

- vi. Accredited private laboratories

#### 4.13.3 Sample Packaging, Transportation, and storage

Proper packaging and transportation of mortality surveillance samples are critical in ensuring sample integrity, biosafety, and timely laboratory analysis. The laboratory personnel shall ensure that mortality samples shall be packaged, transported and stored in accordance with the established laboratory standard operating procedures.

#### 4.13.4 Transport Timelines

The laboratory personnel shall ensure that, samples are transported to the appropriate laboratory as soon as possible, ideally within 24–48 hours, as per the guidelines for the national hub system. Delays may reduce diagnostic accuracy, especially for virology or bacteriology. The laboratory personnel collecting and referring the sample should inform the reference laboratory immediately to ensure preparedness and appropriate sample handling on arrival.

#### 4.13.5 Guidance for laboratory support in mortality surveillance

##### 1) Health facility

At the health facilities with the laboratory services, the personnel should collect the appropriate sample as requested by the medical officer or pathologist, process, analyzed or refer the samples to the appropriate reference laboratory for analysis using the national hub system.

##### 2) Community Level

At the community level, identification of death relies on family members, community informers, VHTs, CHEWs, traditional healers,  religious leaders and local council chairpersons among others. Upon request from the surveillance team, the laboratory staff should support the collection of appropriate samples from a body whether at the household or at the facility if the body is brought to the facility for postmortem.

##### 3) Points of Entry

<!-- Source PDF page 51 -->

Appropriate laboratory samples should be taken from human remains entering Uganda at any point of entry (PoE) if the remains are not accompanied with a death certificate or if the death is considered suspicious by the relevant authority such as Police and medical screeners. In such a case, the remains should be taken to a holding Centre at the point of entry or the mortuary for postmortem and sample collection. The body should not be handed over to the family until when the laboratory results have been released.

**Human remains with a death certificate:** review documentation accompanying the death, notify the relevant authorities (Ministry of Health through SMS 6767), and document the cause of death in the health facility register.

**Human remains without a death certificate:** appropriate samples should be taken from human bodies that are suspected to have died from infectious diseases for investigation in a recognized government laboratory. This process should follow the already laid down guidelines for sample collection above.

#### 4.13.6 Reporting of Mortality Surveillance Results

For routine mortality surveillance, results should be released through the existing routine electronic systems like the facility EMR, Results Dispatch System (RDS), and other medical records as per the prevailing guidance from the Ministry of Health. For outbreak situations, the results shall follow the created hierarchy of release of results. The results should be released within the shortest possible time.

#### 4.13.7 Laboratory supplies for mortality surveillance

The mortality surveillance laboratory supplies should follow the existing logistics and supply management system. Therefore, each facility should factor in additional supplies to cater for the mortality surveillance supply needs. However, during a confirmed outbreak, emergency supplies should be obtained through the existing emergency supply procedures.

<!-- Source PDF page 52 -->

## Chapter Five: Mortality Surveillance Data Management And Use

### 5.0 Introduction

This chapter outlines the standards and procedures for managing mortality surveillance data within the national health information system framework. It provides guidance on the full data lifecycle—covering collection, flow, storage, quality assurance, analysis, visualization, and use—across national, sub-national, facility and community levels.

### 5.1 Mortality Surveillance Data Collection

Data collection for MS is a continuous process that begins with the identification of all deaths of any person of any age and cause, whether within a health facility or community.

#### 5.1.1 Community-based mortality surveillance

In its simplicity, a community death refers to a death that occurs outside a health facility. A death that occurs within an ambulance carrying a patient/client in transit from the community or home to the health facility is classified as a community death. However, if the patient was prior managed in a health facility and only died in an ambulance or on transit to a referral health facility, this will be taken as a facility death.

Community-based mortality surveillance should capture deaths that occur outside health facilities, especially in rural and underserved areas where health-seeking behavior is limited and vital events often go unreported.

The community health worker should collect the following key data components:

##### a. Basic Demographic Information

Name of the deceased (or anonymized identifier), Age at death, Sex, Date of death, Place of residence (village, parish, sub-county, district).

##### b. Manner of Death

Place of death (home, on the way to health facility, public space, etc.), reported symptoms prior to death, events surrounding the death (e.g., sudden, prolonged illness, accident).

##### c. Notification and Reporting Information

Name and cadre of the person reporting the death (e.g., VHT member, LC, etc), Date. This information is sent to 6767 by SMS, and also captured in the community mortality register.

#### 5.1.2 Health Facility Based Mortality Surveillance

A health facility death refers to a death that occurs within a health facility. This includes all types of facilities, such as hospitals, clinics, health posts, temporary structures for emergency situations; regardless of whether they are public, private or PNFP. A death occurring within an

<!-- Source PDF page 53 -->

ambulance that was carrying a patient/client who was on referral and had prior care from another health facility will be taken as a health facility death. This death will be assigned to the referring health facility. However, if the person died in the emergency room (after arrival) or after admission in the receiving health facility, this death will be assigned to the receiving health facility.

Health facilities provide more structured data on mortality, including medically certified causes of death and associated clinical information. The health worker should refer to the following collected data components from the deceased patient file:

##### a. Patient Identification and Demographics

Name, hospital number (whether OPD or IPD), NIN, deceased’s category (National, Refugee, foreigner), Nationality, place of death, date & time of death, age, sex, residence (district, subcounty, village), Marital status, occupation (As stipulated in section 1A of HMIS form 100).

##### b. Clinical History and Cause of Death

Documentation should include: immediate, intermediate and underlying cause of death - depending on the sequence of events surrounding the death (as per ICD-11 standards), date and time of admission and death, and other significant comorbidities, surgical or other interventions provided, laboratory and radiological findings (if any), manner of death, attending clinician’s name, signature and cadre.

##### c. Mortality Certification and Reporting

Every death occurring in a health facility should be immediately notified to MOH through eIDSR, recorded in the health facility mortality register, followed by completion of the notification section of HMIS 100. Within 7 days, the death is reviewed/audited, medical cause of death assigned and captured within the DHIS2.  The health facility should retain a carbonated copy of the completed HMIS Form 100 for proper record keeping.

##### d. Contextual and Risk Factors

Comorbid conditions (e.g., HIV, TB, hypertension, diabetes), Maternal status (for women of reproductive age), Injury mechanism (for accident-related deaths), Contributing factors (e.g., health system delays, socio-environmental factors), should also be documented.

<!-- Source PDF page 54 -->

##### Schema to summarize the steps for Mortality Surveillance at the health facility, and the respective data management tools used

![Source illustration — PDF page 54](images/illustration-054-017.png)

**_Figure 4: Schema to summarize the steps for Mortality Surveillance at the health facility, and the respective data management tools used_**

##### Principles of data Collection Processes at Various Levels

**Principle 1** - Cause of death information should _only_ be provided by a medical officer through an officially authorized MCCD (HMIS 100) for health facility deaths, and NIRA Form 12 for community deaths).

**Principle 2** - It is important to register the facts of a person’s death, with the information set out in Regulation 20(2), even where medically certified cause of death information is not available.

<!-- Source PDF page 55 -->

**Table 3: Mortality Data Collection tools matrix-showing some of the data management tools**

|**Form to be used**|**Health fa** **Who fills out the form**|**cility Level** **Data source**|**Data collection** **timelines**|
|---|---|---|---|
|Mortality Register|Health Worker in charge of the ward|Patient Files|As soon as the event takes place|
|Death Review Form|Health Facility Death Review Committee|Attending health worker|24 Hours|
|HMIS Form 100|Attending health worker (fills section 1A)|All pre/primary data collection tools at various service delivery points i.e: OPD and specialized clinic, IPD, Maternity, Mortuary, EMR, Patient Charts|24 Hours|
||Medical doctor (Completes Frame A)|All pre/primary data collection tools at various service delivery points i.e: OPD and specialized clinic, IPD, Maternity, Mortuary, EMR, Patient Charts|7 days|
|Dead body clearance form|Health facility In-charge|Patient Files|As soon as body is exiting the Health Facility|
|NIRA Death||||
|Notification Record|Health facility In-charge|Patient Files|24 Hours|
|eIDSR (SMS through||||
|6767)|Health facility In-charge|Patient Files|24 Hours|
|| **Commu**|**nity Level**||
|Community Mortality||Household where the death has||
| Register|VHT|occurred|7 days|
|NIRA Form 12|Sub County or Town clerk|Any deceased clinical notes if available|7 days|
||Community gate keeper|Community|24 Hours|
|WHO adapted Verbal|Health workers from the|Household where the death has|Within 2 - 4 weeks|
|Autopsy form|covering health facility|occurred|from death event|

### 5.2 Mortality Surveillance Data Reporting

Mortality surveillance data reporting refers to the systematic process of documentation and disseminating data on deaths from one level to another over time. This process should aim to identify causes of death, monitor mortality trends, detect unusual patterns (such as disease outbreaks or emerging health threats), and inform public health interventions and policy decisions.

#### 5.2.1 At the community level

On a quarterly basis, the VHT aggregates the number of deaths using the household summary (HMIS VHT 007, 008, 097b), and submits this data to the covering health facility, for attention of the Health Assistant – who supervises VHT work. The Health Assistant, after reviewing the report, then submits this data to the health facility where it is entered into the national DHIS2.

![Original table layout — PDF page 55](images/table-source-page-055.png)

<!-- Source PDF page 56 -->

From there, the data flows to the district/regional level and ultimately to the National level - the Ministry of Health.

In real time (as events occur), the VHT reports any deaths within their community that occur within the first 24 hours by sending a structured message to 6767 via the eIDSR system. The death notification is then flagged on the respective district eIDSR dashboard, prompting the respective District Surveillance Focal person to record it in the district death line list and mobilize the district rapid response team to respond accordingly e.g by collecting a sample if necessary.

**Note:**

- Keep the message **concise** (maximum **160** characters) while ensuring all 7 required sections are included i.e

   - **Keyword:** Alert

   - **Age:** 1yr or 20yrs or 4mnths

   - **Sex:** male or female and should be symbols ( **M** / **F)**

   - **Manner of death** (Conditions surrounding the death)

   - **Date of Onset:** 10Jan2021

   - **Location:** Villages, Parish, (Division for Cities), Sub County, District.

   - Name of the **reporter / sender**

- Send the alert message to **6767** (double-check the spelling of the word **"Alert"** ).

- This alert is **free of charge** for the reporter.

- Applicable **only to Ugandan-registered Airtel and MTN numbers** .

NIRA is to access MS data through DHIS2. In addition, NIRA can pick data from whichever level of the health service delivery through NIRA form 12, and also wherever the NIRA MVRS system is functional. MS Data can also flow from the community, through informants, opinion leaders, or any other witness, through the sub county chief/ town clerk - notification using Mobile Vital Registration System (MVRS) to NIRA. This process leads to what we term as registration of the death, and it is critical where a death certificate is to be obtained from NIRA.

After data is collected through health facilities, community sources, and NIRA tools, it is transmitted to district and Ministry of Health platforms such as eIDSR, eCHIS, and the DHIS2 repository for further analysis. These systems support advanced analytics to identify mortality patterns/trends, detect emerging public health threats, and highlight priority areas for response. Regular reports should be generated and disseminated to district health teams and policy and

### 5.3 Mortality Surveillance Data Aggregation and Analysis

Data aggregation is a process in which information gathered is expressed in a summary form, whereas data analysis is the process of examining raw data to establish trends to guide appropriate action. Mortality Surveillance data, aggregation and analysis should be done at all levels of the health system using both qualitative and quantitative approaches.

<!-- Source PDF page 57 -->

#### 5.3.1 Data analysis

Data analysis for Mortality Surveillance should be guided by the data analysis plan to assess data quality, completeness, track mortality trends, identify causes of death, evaluate quality of care, and inform actionable recommendations. A data analysis plan includes the following:

#### 5.3.2 Analysis packages

One of the commonly used analysis applications is the R studio, the MS secretariat working with stakeholders will develop R scripts to automate the generation of outputs for specific mortality indicators stipulated in the analysis plan. This will save time and ensure real time access to mortality indicator outputs. Other analysis applications including excel, STATA, EpiInfo can be used.

#### 5.3.3 Frequency of analysis

**Daily** : Dashboards will provide daily outputs on death events, trends, coverage and excess mortality

**Weekly** : Analysis for weekly MS briefs, and as part of the weekly epidemiological bulletins **Quarterly** : Analysis for quarterly MS bulletins **Yearly** : Analysis annual MS reports

#### 5.3.4 Type of Analysis & Visualization Techniques

Analysis at each level (National, Regional, Facility and Community) will cover the following: **Descriptive analysis:** Analyze the Time (date of death), Place (address of usual residence and place of death) and the Person (age, sex, and occupation) for each death.

**Qualitative analysis:** Explore the circumstances surrounding the deaths and the quality of care provided. This will be utilized to agree on recommendations to prevent similar deaths in the future.

**Cause of death analysis:** Identify the top 20 causes of deaths by sex and age group, and analysis of the quality of cause of death data (ill-defined causes of death)

**Analysis of excess mortality:** The expected mortality will be projected using historical data. The expected mortality will then be compared with the observed mortality to determine if the observed mortality is in excess of the expected.

**Visualization techniques:** Use the chats, maps, tables and text for qualitative data to visualize data. Display these on dashboards, noticeboards and reports. The Ministry of Health will customize mortality dashboards to enable visualisations using data captured in the DHIS2.

Interpretation of Mortality Surveillance data should be both qualitative and quantitative at all levels to inform appropriate actions.

<!-- Source PDF page 58 -->

**District/ Regional /National level Analysis** : At the district, regional and national levels, aggregated data will be used to provide information on the coverage of death notification and MCCD, and identify the subgroups that are at highest risk, as well as most affected geographical areas.

Analysis of all deaths including maternal and perinatal deaths review data should focus on prioritizing potential areas for action for example; cause of death, patterns of cause of death, subgroup analysis for high-risk populations e.g. adolescents, place of death, identifying gaps in healthcare provision, geographical areas or facilities where most deaths are occurring. Trend analysis should also be done: Crude mortality rate, all-cause mortality, age-specific mortality, maternal mortality ratio, perinatal mortality rate, excess mortality etc.

Further analysis of causality of death or underlying factors to death will be important in informing what nature of the response is required.

### 5.4 Mortality Surveillance Data Quality Assurance and Control

#### 5.4.1 Data quality assurance and control

All health facilities must use nationally standardized Mortality Surveillance tools. ICD-11 coding will be implemented to improve the accuracy of cause-of-death reporting. In addition, WHO-adapted verbal autopsy tools should be used in designated areas to capture data for deaths occurring in communities.

Capacity building for health workers on mortality surveillance data management shall be done routinely to facilitate proper application of the laid down procedures, including coding for causes of death, and use of the described digital tools as guided by the MS Secretariat.

To maintain data accuracy and accountability **,** national, regional, and district health teams should conduct regular mentorships and supervision visits to health facilities. Furthermore, quarterly review meetings at both district and national levels should be held to help identify and address inconsistencies or anomalies in mortality trends.  Regional/District teams should also be facilitated to do mentorships and support supervisions at health facility and community levels.

#### 5.4.2 Mortality data Security and Privacy

At all levels of the health systems, security and privacy of mortality surveillance data should be ensured. At health facility level, facility in-charges and medical record assistants/health information assistants should take on the mandate to ensure that data security and privacy is upheld as guided by the legal frameworks identified in Chapter 2 of this guidelines document. At district level, this mandate falls under the roles of the district Biostatistician, well as at the national level, this function falls within the department of planning, and in particular with the division of health information.

<!-- Source PDF page 59 -->

Uganda’s DHIS2 system ensures health data security through role-based access, encrypted transmission, automated backups, audit logs, and strict data sharing protocols, all in compliance with the Data Protection and Privacy Act (2019) and Ministry of Health ICT policies.

### 5.5 Use of Mortality Data

Near to real time, Weekly, monthly, and quarterly mortality briefs, bulletins and reports will be used to monitor trends, cause, place, person and time characteristics of all deaths. They will be generated to inform national, regional and district-level health planning, enabling evidencebased resource allocation and prioritization of response. Mortality data should also play a critical role in early detection of outbreaks and guiding timely responses to public health emergencies. To ensure consistency and accuracy, standard operating procedures (SOPs) will be followed for producing and validating district-level mortality bulletins, supporting datadriven decision-making across all levels of the health system. A dashboard should be developed to ease visualization of the reports which can be presented as maps, tables, and graphs, among others.

#### 5.5.1 Use of Mortality Surveillance Data

Mortality surveillance data should be used to inform public health policy and planning. It should help governments identify key health priorities such as high maternal or child mortality, allocate resources effectively, and design targeted interventions to address major causes of death like cardiovascular or infectious diseases.

In the realm of disease surveillance and outbreak detection **,** mortality data should be used to detect emerging health threats through unusual death patterns, monitor the burden of endemic diseases such as malaria and tuberculosis, and measure the total impact of epidemics, including indirect mortality effects.

The data should also support program monitoring and evaluation by assessing the effectiveness of interventions, such as vaccination campaigns or road safety initiatives, identifying service delivery gaps, and tracking progress toward national and international health goals, including the Sustainable Development Goals (SDGs).

From an equity and social justice perspective, mortality surveillance should help uncover disparities in death rates across different populations, such as rural vs. urban communities or by socioeconomic status. This should support the development of equitable health policies and serves as a tool for accountability among policymakers and stakeholders.

In health research and burden of disease estimation **,** mortality data should be used for analyzing risk factors, supporting global burden of disease studies, and calibrating forecasting models to enhance their accuracy in predicting future health trends.

Finally, mortality data should contribute to strengthening health systems by guiding decisions on human resource needs, healthcare infrastructure development, and policy reforms, ensuring that system improvements are grounded in evidence about population-level health outcomes.

<!-- Source PDF page 60 -->

#### 5.5.2 Who uses Mortality surveillance data

All Mortality Surveillance data should be used at the source (points of data collection) to improve the quality of healthcare delivery to the community and should be submitted to higher levels to facilitate immediate response. Timely identification of underlying causes of deaths should be a priority for all stakeholders. Every person involved in the healthcare system (Health workers, decision makers, opinion leaders, champions, funders, etc.) can use the mortality surveillance data.

Examples of categories of people who should use Mortality Surveillance data include but not limited to Surveillance stakeholders, Community leaders, District leaders, National leaders, Development partners, Public sector, Civil society, Researchers/academicians, one health teams, Inter religious councils and cultural leaders and Other MDAs.

#### 5.5.3 Mortality data use for Epidemic Intelligence

Epidemic intelligence involves the early detection of health threats **,** assessment, and response to public health issues including infectious disease outbreaks and other health emergencies. Mortality data should play a critical role in this process, especially in low-resource or surveillance-limited settings.

Surveillance/Epidemiology departments in the national and subnational levels should use mortality surveillance data for epidemic intelligence including detecting emerging threats through timely data use, tracking epidemic diseases and measuring the impacts of epidemics on the population, inform response plans, among others.

National and regional public health emergency operational centers (PHEOCs) should constantly monitor mortality surveillance data for epidemic intelligence purposes. They shall periodically analyze mortality surveillance data to produce reports, bulletins and develop dashboards to visualize mortality surveillance data.

Unusual patterns in mortality (e.g., clusters of deaths) can signal disease outbreaks. Therefore, it is important to continuously monitor mortality surveillance at all levels both in the health facilities and communities to facilitate this purpose. Developing and or leveraging on existing electronic systems and dashboards that quickly signal users about such unusual patterns will help in this course.

### 5.6 Mortality Surveillance Indicators

<!-- Source PDF page 61 -->

**Table 4: Key Mortality Surveillance Analytics, Rationale, and Indicators**

||**Recommended mortality surveillance analytics by program and geograph**|**ical area**|
|---|---|---|
|**Program Area**|**Sample Indica**|**tors**|
|Epidemic surveillance|Death counts, cause specific, case fatality rates, Excess mortality||
|ReproductiveHealth|MMR, SBR,PMR, NMR,IMR, U5MR||
|Infectious disease|HIV /AIDS, Malaria,TB, VHFs, Vector borne diseases, etc||
|Non-Communicable Disease|Cancers, IHD, Chronic Kidney disease, Mental Health, etc||
|External Causes|Road traffic injuries, suicide deaths, homicide, unintentional poisoning, etc||
|Environmental & climate Impact on Health|Mortality from household & ambient air pollution, WASH related infections, disast|ers|
|General Mortality Surveillance|Crude death rate,Age specificrates, U5MR,AdolescentMR,Riskofadultmortalit|y (15-60),Life expectancy at birth,Life expectancy at age 60 years,|
|Population Health assessment|Leading causes of death, Age specific, Years of life lost,||
||**Routine analysis at implementation level**||
|**Analytic**|**Purpose (Why the Analytic is Needed)**|**Indicator**|
||Serves as a benchmark for assessing completeness of death notification and|Proportion of facility deaths notified- Proportion of facility deaths|
|Expected deaths in health facilities|medical certification of cause of death (MCCD)|medically certified|
|Expected deaths in the community|Serves as a benchmark for assessing completeness of death notification at the community level|Proportion of community deaths notified|
|Expected sample of deaths for verbal autopsy (VA)|To determine the expected number of community deaths requiring VA for cause- of-death identification|Proportion of VAs conducted out of total community deaths notified|
|Total deaths identified (facility+community)|To monitor overall mortality trends and calculate mortality rates|Proportion of deaths notified at both facility and community levels|
|Number of deaths notified|To track coverage and completeness of death notification in both health facilities and communities|Proportion of deaths notified by location|
|Proportion of medically certified deaths at health facilities|To assess the extent of cause-of-death documentation using MCCD and VA where appropriate|Proportionof medically certified deaths athealth facilities|
|Trends and patterns of mortality and causes of death over time|To identify seasonal or unexpected spikes in deaths, indicating possible public health events or outbreaks|Mortality trends by time and cause|
|Top medical causes of death|Enables classification of deaths by ICD-11 codes and helps identify leading causes by locality|Proportion of deaths by specific causes (ICD-11)|
|Proportion of ill-defined causes of death (ICD-11)|To assess data quality and improve specificity in cause-of-death reporting|Proportion of medically certified deaths classified as ill-defined ProportionofVAdeaths classified asill-defined|
|Analysis of non-medical contributing factors (e.g. quality of care, health system issues)|To identify systemic gaps and inform clinical or administrative interventions (e.g. training, protocols, resource allocation)|Proportion of deaths reviewed with documented non-medical contributing factors|
||To inform health system strengthening actions such as health worker training,||
|Assessment ofquality ofcarefordeceasedindividuals|provisionofprotocols, and equipment|Proportionofdeath reviews conducted athealth facilities|
|Determinationofavoidable deaths|To identify preventable deaths and recommend actionable interventions to reduce futuremortality|Proportion of deaths identified as avoidable through reviews at facility and communitylevel(VA)|

![Original table layout — PDF page 61](images/table-source-page-061.png)

<!-- Source PDF page 62 -->

### 5.7 Some of the Data Sources

#### 5.7.1 At Health Facility

|**Data Sources at th**|**e Health Facility level**|
|---|---|
|HMIS 105-MA11 - Newborn deaths 0-8 days|HMIS 108-ND07 - Other neonatal conditions|
|HMIS 105-MA12 - Neonatal death 8-28 days|HMIS 108-C103 - No of deaths|
|HMIS 105-MA13 - Maternal death|HMIS 108a-C103 - No of deaths|
|HMIS 105-MA04c1 - Delivers in unit-fresh stillbirths total|HMIS 106a-HC28 – No. of ART patients with no clinical contact since last expected contact confirmed dead after tracing by cause of death|
|HMIS 105-MA04d 1- Delivers in unit-macerated stillbirths total|HMIS 106a-BS07 - Ergonometric and medical accidents- Death within the lab|
|HMIS 105-DT01- Deaths in OPD|Health Facility Mortality Register-New|
|HMIS 108-ND01 - Neonatal sepsis 0-7days|Dead body movement clearance note - New|
|HMIS 108-ND02 - Neonatal sepsis 8-28 days|HMIS 100 – Medical Certificate of Cause of Death|
|HMIS 108-ND04 - Neonatal Meningitis|HMIS 108-ND03 - Neonatal pneumonia|
|HMIS 108-ND05 - Neonatal Jaundice|HMIS 108-ND06 - Premature baby (as a condition that requires management)|

#### 5.7.2 Data Sources for the Community

At the community level, data sources include:

- 1) HMIS 097b

- 2) NIRA form 12- Notification of death

- 3) HMIS 007- VHT Monthly summary report

- 4) Community Mortality register

![Original table layout — PDF page 62](images/table-source-page-062.png)

<!-- Source PDF page 63 -->

## Chapter Six: Monitoring And Evaluation For Mortality Surveillance Guidelines Implementation

### 6.1 Introduction

Monitoring and evaluation (M&E) of Mortality Surveillance implementation is a critical function that ensures planned activities are being implemented as intended, while continuously assessing the functionality, coverage, timeliness, and reliability of the system across all levels—national, regional, district, facility, and community.

The overall goal of the M&E guideline is to assess implementation progress, identify data quality gaps, and guide system improvement efforts. These functions are central to a robust data quality management process, which must include sequential components of assessment and analysis to support continuous improvement.

### 6.2 General Objective of M&E for Mortality Surveillance Guidelines

The primary objective of the monitoring and evaluation section of the mortality surveillance guidelines is to track implementation progress, identify gaps, and inform targeted improvement efforts.

#### 6.2.1 Specific Objectives

- 1) To monitor the implementation of mortality surveillance activities across all levels of the health system to ensure compliance with national guidelines.

- 2) To assess the quality of mortality data, including its completeness, timeliness, and accuracy, from all reporting sources.

- 3) To evaluate the performance and effectiveness of the mortality surveillance system in achieving its intended outcomes and guiding public health interventions.

- 4) To identify gaps and generate recommendations for continuous improvement of data collection, reporting, and use in decision-making

### 6.3 Monitoring and Evaluations at Different Levels

This section outlines the implementation of monitoring and evaluation (M&E) for mortality surveillance guidelines across all levels of the health system. It provides a structured approach on how M&E activities should be carried out at the national, regional, district, health facility, and community levels.

Each level plays a distinct role in ensuring the functionality and responsiveness of the mortality surveillance system, and hence implementation of the guideline.

By clearly defining responsibilities and actions at every level, the section aims to strengthen coordination, enhance data use, and support continuous improvement of mortality surveillance in Uganda.

#### 6.3.1 Community level

<!-- Source PDF page 64 -->

Mortality surveillance implementation at community level is done by a range of gatekeepers (VHTs/CHEWs, Police, Cultural leaders, religious leaders, Subcounty/Parish Chiefs, among others), who support identification and notification of deaths within 24 hours of death occurrence. The Health Assistant will ensure that mortality data is accurately collected and submitted through the standard platforms outlined in Chapter 5 of this MS guidelines document.

Regular (Quarterly) community-level feedback and review meetings will be conducted to build the capacity of community stakeholders, strengthen engagement, and reinforce the value of their input. From the outset, the MS system will be conducted to capture and act upon feedback from CHEWs and VHTs, enhancing their skills while improving data quality and system responsiveness.

Evaluation at this level will help identify specific areas for improvement and inform actionable recommendations, ensuring that the community remains an integral and empowered part of the mortality surveillance process.

#### 6.3.2 Health Facility Level

The aim of health facility-based mortality surveillance is to systematically identify, notify, medically certify, review all deaths and respond to recommendations from the review. Death notification to the DHO and MoH should be within 24 hours of event occurrence, and death review within 7 days.

Facilities are expected to collect mortality surveillance data using standardized tools and electronic systems as outlined in Chapter 5 of these guidelines, ensuring adherence to national reporting timelines. They should also utilize their own data to inform and implement appropriate mortality response interventions.

The responsibility for monitoring and evaluation lies with Health personnel as assigned by the facility in-charge to perform such duties. These individuals will oversee the tracking of performance of key indicators against set targets

#### 6.3.3 District level

The District or City Health Office will oversee the implementation of mortality surveillance (MS) monitoring and evaluation activities within their jurisdiction. This includes building the capacity of health workers and community gatekeepers in mortality surveillance practices. A designated Biostatistician or an assigned staff will be responsible for tracking the performance of indicators as outlined.

In addition, the district or city will conduct regular data quality audits, analyze MS data, and hold routine performance review meetings to monitor progress, identify and address challenges, and provide timely feedback to reporting units.

#### 6.3.4 Regional level

<!-- Source PDF page 65 -->

At the regional level, the primary role is to provide oversight, coordination, and technical support to strengthen mortality surveillance across all districts within the region.

Regional Referral Hospitals (RRHs) are tasked with mentoring, monitoring, and supervising lower-level health facilities to enhance the capacity and skills of health workers in implementing MS activities.

A regional all-cause death review committee housed within the RRH, will serve as the technical lead for mortality surveillance in the region, guiding implementation and ensuring alignment with national standards. The committee will be meeting weekly to review deaths. These committees will be guided by the Terms of reference. This committee is to ensure death notification to MoH within 24 hours and death review within 7 days.

Quarterly regional MS review meetings should be held to follow up on district reports, discuss emerging issues, and coordinate a unified regional response. In addition to routine monitoring, RRHs will conduct periodic confidential inquiries to support in-depth evaluation of specific mortality cases, contributing to a continuous learning and quality improvement process. The community health department and the regional Emergency Operation Centres (EOCs) will lead these efforts at regional level.

#### 6.3.5 National level

The Ministry of Health through the department of Integrated Epidemiology, Surveillance and Public Health Emergencies & Response will lead in the overall coordination of the implementation of MS guidelines in collaboration with all key stakeholders including MDAs, districts/cities, and partners. The Ministry will ensure that all key stakeholders have the necessary capacity to implement MS activities and carry out M and E activities at all levels.

At the national level, the MS coordination committee will spearhead coordination of efforts for monitoring and evaluation of mortality surveillance. It will focus on ensuring that all deaths are identified, notified and medically certified in accordance with national guidelines. Furthermore, the national level will ensure that all-cause death review Committees are established and functional at regional, district and facility levels. The national level will also ensure the timely generation and dissemination of mortality surveillance reports.

### 6.4 Tools for M&E

- Mortality surveillance performance Scorecard

- MS Performance Dashboard (linked to DHIS2)

- Audit Summary Reports (District and Facility Level)

- Verbal Autopsy Follow-Up Reports

### 6.5 Data Sources

- DHIS2/MS dashboard

<!-- Source PDF page 66 -->

- eCHIS & EMR extracts

- Meeting minutes (e.g., MS committee, MPDSR)

- NIRA cause of death data

- VHT quarterly reports

- Annual Health Sector Performance Report (AHSPR)

### 6.6 Feedback & Learning Loops

- Monthly feedback from DHOs to facilities

- Quarterly regional performance meetings

- Annual national MS review & learning summit

- Integration with existing QA/QI structures

### 6.7 Data quality assessment in the mortality surveillance program

Ensuring high-quality mortality data is essential for generating accurate insights into population health and informing public health policy and response. The mortality surveillance program in Uganda will implement a comprehensive Data Quality Assessment (DQA) framework consisting of four interlinked components: quality assurance, quality monitoring, quality control, and quality evaluation. DQAs should be done on a quarterly basis.

<!-- Source PDF page 67 -->

![Source illustration — PDF page 67](images/illustration-067-021.png)

**_Figure 5: Framework for quality assessment of mortality surveillance programs (Adopted from Continental Framework on Strengthening Mortality Surveillance Systems in Africa - CDC_**

#### 6.7.1 Quality Assurance

Quality assurance will focus on establishing strong foundations for data quality through the following areas:

- i. **System Design:** Mortality surveillance will be integrated into national digital platform (DHIS2), ensuring structured data flow, automated aggregation, and user-friendly interfaces to minimize manual errors.

- ii. **Infrastructure:** Adequate ICT infrastructure including mobile devices for community health workers (CHWs), server hosting, internet connectivity, and power sources will be prioritized to support consistent data capture and reporting across all regions.

- iii. **Institutional Capacity:** Strengthening institutional capacity at all levels; from community to national will involve orientation on mortality surveillance protocols, data management standards, and data use for decision-making.

- iv. **Data Collection Tools and Processes:** Standardized digital and paper-based tools, such as death review forms and mobile applications, will be adopted and periodically reviewed for clarity, relevance, and usability. These tools will capture essential mortality variables.

- v. **Human Resources:** Capacity-building initiatives will target VHTs, CHEWs, health assistants, DSFPs and biostatisticians to ensure proper data collection, verification, and

<!-- Source PDF page 68 -->

management. Regular training and mentorship will reinforce adherence to guidelines and reporting standards.

#### 6.7.2 Quality Monitoring

Ongoing quality monitoring will ensure that mortality data meets defined standards through the following approaches:

- i. **Monitoring Tools:** The program will deploy digital dashboards and summary reports that allow health managers to track indicators such as timeliness, completeness, and discrepancies in reported deaths.

- ii. **Data Timeliness:** Timeliness of reporting will be monitored by tracking the interval between the occurrence of death and its entry into the surveillance system, with clear targets established at each reporting level.

- iii. **Data Validation Activities:** Built-in validation rules within digital platforms will flag incomplete or inconsistent data. Manual validation will also be conducted through quarterly data reviews at subnational levels.

- iv. **Field Supervisory Visits:** District and regional health teams will conduct periodic field visits to verify source data, observe data entry practices, and provide on-the-spot corrective support to CHWs and health facility staff.

#### 6.7.3 Quality Control

Quality control mechanisms will focus on identifying and rectifying errors, and ensuring ongoing improvement:

- i. **Data Correction:** Errors identified through system checks, validation reports, or supervisory visits will be corrected promptly at the source. Feedback will be given to the data collectors to prevent repeat errors.

- ii. **Data Adjustment:** In cases of systemic underreporting or known biases, statistical adjustments may be applied based on historical trends or capture-recapture techniques, with clear documentation.

- iii. **Feedback Mechanisms:** Structured feedback loops will be established, allowing CHWs and district teams to receive monthly feedback on reporting performance, data quality issues, and corrective actions. Feedback will also be used to update training content and tools.

#### 6.7.4 Quality Evaluation

Periodic quality evaluation will assess the overall performance of the mortality surveillance system using key metrics:

- i. **Reporting Completeness:** The proportion of health facilities and CHWs submitting death data reports on time will be tracked monthly and evaluated quarterly.

- ii. **Record Completeness:** Completeness of each death record will be assessed by evaluating the proportion of records with all key variables filled.

<!-- Source PDF page 69 -->

- iii. **Variable Accuracy:** Routine audits and sample verifications will assess the accuracy of recorded variables by comparing reported data to source documents or community level investigations.

- iv. **Comparative Analyses:** Evaluation will also involve triangulating mortality data from multiple systems (e.g., NIRA, UBOS, eCHIS) to assess consistency and identify gaps.

<!-- Source PDF page 70 -->

### 6.8 Indicators for Monitoring Performance of a Mortality Surveillance System

![Complete mortality surveillance matrix — PDF page 70](images/table-source-page-070.png)

<!-- Source PDF page 71 -->

![Complete mortality surveillance matrix — PDF page 71](images/table-source-page-071.png)

<!-- Source PDF page 72 -->

![Complete mortality surveillance matrix — PDF page 72](images/table-source-page-072.png)

<!-- Source PDF page 73 -->

![Complete mortality surveillance matrix — PDF page 73](images/table-source-page-073.png)

<!-- Source PDF page 74 -->

### 6.9 Dissemination of Mortality Surveillance Information

#### 6.9.1 Introduction

This section outlines the strategy for disseminating and promoting the utilization of Mortality Surveillance (MS) guidelines and findings. Recognizing its mandate to enhance health service delivery, the Ministry of Health will prioritize the effective communication of MS objectives and activities, the dissemination of MS results, and the active promotion of their application. To ensure the guidelines remain relevant and impactful, regular updates on MS progress, identification of best practices, and practical guidance on implementing MS strategies will be shared periodically, with feedback mechanisms in place to inform future revisions. The MoH will spearhead the dissemination and utilization efforts for all MS-related outputs.

#### 6.9.2 Structure of the Dissemination and Utilization Plan for MS Tools, Guidelines, and Information

The dissemination and utilization plan for MS tools, guidelines, and information is structured around the following key components:

- i) Objectives and Scope of the Dissemination and Utilization Plan: This section defines the goals and reach of our strategy for sharing and applying MS outputs.

- ii) Appropriate Communication Channels for Target Audiences: This section details the tailored communication methods that will be employed to effectively reach specific stakeholder groups.

- iii) Roles and Responsibilities of Key Stakeholders: This section clearly outlines the duties of various partners in the dissemination and utilization process.

#### 6.9.3 Objectives and Scope of the Dissemination and Utilization Plan

The primary objectives of this plan are to:

- Establish a coordinated framework for the dissemination and utilization of MS guidelines and results.

- Effectively communicate MS progress and findings to clearly defined target groups through appropriate communication channels and tools.

- Ensure the fulfillment of national and international mortality surveillance reporting obligations.

#### 6.9.4 Appropriate Communication Channels for Target Audiences

To ensure maximum impact, information will be disseminated through carefully selected channels tailored to the specific interests and needs of each target audience. These audiences include: policy makers at the ministry of health, technical staff, health workers, academia and the scientific community, implementing partners and the public:

<!-- Source PDF page 75 -->

**Table 5: Showing communication channels of dissemination to target audience**

|**Audience**|**Key messages**|**Channels to target au**|**dience**|
|---|---|---|---|
|**Policy makers**at MoH leadership, district health officers, Communicable and Non-Communicable Diseases Technical Working Group, Parliament, Cabinet.|MS results and guidelines|TWG Meetings Workshops Written reports Policy briefs Bulletins Dashboards Annual performance review|meetings|
|**Technical Staff**– Epidemiologists, HMIS teams, surveillance focal persons|● MS results and guidelines ● Key indicators for measuring MS outcomes ● Tools and SOPs|Regional Quarterly perform meetings Support supervision visits Workshops, Bulletins, Reports, Website|ance review Dashboards,|
|**Health Facility Managers and health** **workers**– medical superintendents, health facility in-charges and hospital administrators|● MS results and guidelines ● Key indicators for measuring MS outcomes ● Tools and SOPs|District quarterly performa meetings Support supervision visits Workshops, Bulletins, Reports, emails, notice boa|nce review Dashboards, rds|
|**Stakeholders**– Local governments, community leaders, CSOs.|● MS results|Performance review meetin Support supervision visits Workshops, Bulletins, reports|gs Dashboards,|
|**Development** **and** **implementing** **partners Academic and Research** **Institutions** – WHO, CDC, donor agencies, universities, research organizations, Academia.|● MS results and guidelines ● Key indicators for measuring MS outcomes ● Tools and SOPs|Website National and internation conferences Performance review meetin Support supervision visits Workshops, Bulletins, reports, scientific journals|al scientific gs Dashboards,|
|Public|● MS results|Website Social media updates Open days/barazas Public events Radio Print media (newspapers) Scientific publications||

![Original table layout — PDF page 75](images/table-source-page-075.png)

<!-- Source PDF page 76 -->

**Table 6: Showing the different committees, their composition, and Terms of Reference**

|**Mortality** **Review**|**National**|**Region**|**District**|**Facility level**|**Community**|
|---|---|---|---|---|---|
|Death Review Committee|Mortality Surveillance Coordination Committee|Regional Death Review Committee|District Death Review Committee|Heath Facility Death Review Committee|VHT|
|**Composition**|Director General Health Services, Commissioner IES&PHE; IES &PHE Department, DHI, NCD, NDC, Clinical Services Department, MCH, PHEOC & Community Health Departments; Representatives of MDAs including UBOS, NPA, Ministry of Internal Affairs (NIRA), One Health focal person, Health Professionals Councils (UMDPC, AHPC, UNMC); Academic & Research Institutions; Uniformed forces (UPDF, UPF & UPS); Civil Society Organizations (CSO) representatives; Development and Implementing partners,|Senior Executive Consultant RRH, Community Health Department, Public Health Department, Regional Surveillance Focal Persons, REOC, Chairperson District DRC, Medical Specialists, Biostatisticians, Senior Medical Records Officer, DVO|Executive consultant of the general hospital, DHO,DVO,ADHOs, DSFP, DLFP, DHE, DHI, Biostatistician,CDO, Town Clerks, Subcounty Chiefs; Parish chiefs/Town Agents – MOs, SNOs, Health Inspectors, Health Assistants; Law Enforcement teams (RDCs, Police); Political heads (CAO, LCV, Secretaries for Health); district level Partners|Health facility in charge, Medical Officer, Clinical Officer, Nurse, Midwife, Laboratory Focal Person, Health Assistants, Health Information Assistant/Medical Records Officer|CHEWs, VHT, Local Council 1, Parish chiefs|
|**Terms of** **Reference**|Approve and update frameworks, policies, tools and guidelines for mortality surveillance Manages resource mobilization and allocation Develop and review mortality surveillance guidelines Make recommendations to prevent further deaths.|Coordinate implementation of MS activities in the respective regions and districts, in collaboration with the national level DRC Support aggregation and analysis of mortality data, trends and projections from districts/cities in the respective catchment areas Support the review of findings and recommendations from the DRCs and support their implementation including closing in on the identified gaps.|Conduct or support confidential enquiries Aggregate and conduct mortality data analysis Formulate, implement and evaluate responses from death reviews Share notification and audit data to the regional/national level Develop district annual reports on death reviews done|Update Health facility mortality register Advocacy and capacity building at community level Train Health workers and VHTs on MS tools and Guidelines Support the implementation of community verbal autopsies Assess quality of medical care provided Review and establish medical and non-medical causes of death Support and oversee utilization of approved MS tools andguidelines|Update community mortality register Participate in conducting Community Verbal Autopsies|

![Original table layout — PDF page 76](images/table-source-page-076.png)

<!-- Source PDF page 77 -->

## Tools Currently Being Used for Capturing Death Data in the Community and Health Facility Levels

![Complete mortality surveillance matrix — PDF page 77](images/table-source-page-077.png)

<!-- Source PDF page 78 -->

![Complete mortality surveillance matrix — PDF page 78](images/table-source-page-078.png)

<!-- Source PDF page 79 -->

![Complete mortality surveillance matrix — PDF page 79](images/table-source-page-079.png)

<!-- Source PDF page 80 -->

![Complete mortality surveillance matrix — PDF page 80](images/table-source-page-080.png)

<!-- Source PDF page 81 -->

![Complete mortality surveillance matrix — PDF page 81](images/table-source-page-081.png)

<!-- Source PDF page 82 -->

![Complete mortality surveillance matrix — PDF page 82](images/table-source-page-082.png)

<!-- Source PDF page 83 -->

![Complete mortality surveillance matrix — PDF page 83](images/table-source-page-083.png)

<!-- Source PDF page 84 -->

![Complete mortality surveillance matrix — PDF page 84](images/table-source-page-084.png)

<!-- Source PDF page 85 -->

![Complete mortality surveillance matrix — PDF page 85](images/table-source-page-085.png)

<!-- Source PDF page 86 -->

![Complete mortality surveillance matrix — PDF page 86](images/table-source-page-086.png)

<!-- Source PDF page 87 -->

![Complete mortality surveillance matrix — PDF page 87](images/table-source-page-087.png)

<!-- Source PDF page 88 -->

![Complete mortality surveillance matrix — PDF page 88](images/table-source-page-088.png)

<!-- Source PDF page 89 -->

![Complete mortality surveillance matrix — PDF page 89](images/table-source-page-089.png)

<!-- Source PDF page 90 -->

![Complete mortality surveillance matrix — PDF page 90](images/table-source-page-090.png)

<!-- Source PDF page 91 -->

### Systems Generating Mortality Statistics as Identified During MS Guidelines Development

![Complete mortality surveillance matrix — PDF page 91](images/table-source-page-091.png)

<!-- Source PDF page 92 -->

## References

1. Rao, C., et al., _The role of mortality surveillance in pandemic preparedness and response._ Bulletin of the World Health Organization, 2025. **103** (3): p. 213.

2. Africa CDC. _Operational Guide for Establishing and Implementing Mortality Surveillance in Africa, July 2024_ . 2024 [cited 2025 09/07/2025]; Available from: https://africacdc.org/download/operational-guide-for-establishing-and-implementingmortality-surveillance-in-africa-july-2024/.

3. Kasasa, S., et al., _Birth, stillbirth and death registration data completeness, quality and utility in population-based surveys: EN-INDEPTH study._ Population health metrics, 2021. **19** : p. 1-15.

4. Atuhaire, L.K., et al., _Prevalence and determinants of death registration and certification uptake in Uganda._ PLOS ONE, 2022. **17** (3): p. e0264742.

5. Nabukalu, D., et al., _Community health workers trained to conduct verbal autopsies provide better mortality measures than existing surveillance: Results from a cross-sectional study in rural western Uganda._ PLOS ONE, 2019. **14** (2): p. e0211482.

6. MOH. _National Mortality Surveillance Roadmap 2024_25_ . 2024  08/07/2025]; Available from: https://library.health.go.ug/sites/default/files/resources/National%20Mortality%20Surveilla nce%20Roadmap%202024-2028.pdf.

<!-- Source PDF page 93 -->

## ANNEX

### Annex 1: List of frameworks, guidelines to guide mortality surveillance implementation

#### Global Frameworks relating to Mortality Surveillance

These provide guidance, benchmarks, and accountability standards that shape how Uganda should design and implement its Mortality Surveillance (MS) system. They include:

##### United Nations Sustainable Development Goals

Specifically, SDG 17.19.2 guides UN member states on achieving 100% birth and 80% death registration by 2030. Therefore, these MS guidelines should provide standard tools based on the legal provisions to enable the government to strengthen death registration and set performance indicators.

##### WHO International Health Regulations (IHR) 2005

Member states, including Uganda, are guided to strengthen national surveillance systems through capacity building and integration of data sources, promote international collaboration, provide regulatory support, as well as encourage the adoption of technological advancements. Uganda has integrated these into its various strategies for epidermic response and health security. These MS guidelines will strengthen the multisectoral coordination as well as data integration.

##### UNHCR guidelines for mortality surveillance

These have provided practical guidance on the need to establish, collect, report, and use mortality surveillance data in displaced populations, including refugee settings, to improve the comprehensiveness and quality of reporting of mortality data unique situation as stipulated in Chapter Eight.

##### Africa CDC Continental Framework on Strengthening Mortality Surveillance Systems in Africa, July 2023

It has encouraged member states to strengthen mortality surveillance implementation by addressing challenges related to data quality, completeness, timeliness, standardization, capacity, and integration. It offers Uganda a collaborative, end-to-end guide to examine its current CRVS processes, identify gaps, and determine areas needing improvement. Therefore, these guidelines will outline a holistic approach to strengthening routine mortality surveillance systems, considering the unique contextual factors and challenges faced in Uganda. It emphasizes the importance of establishing efficient data collection mechanisms, enhancing data quality and completeness, and promoting data sharing and collaboration among stakeholders.

#### Regional Frameworks Enabling Mortality Surveillance

These serve as a bridge between global frameworks, standards, and country-specific implementation. For Uganda, these frameworks are critical in harmonizing Mortality

<!-- Source PDF page 94 -->

Surveillance (MS) across African countries, especially within the East African region, as shown below;

##### Africa Agenda 2063

The Agenda 2063 specifically calls for improving Civil Registration and Vital Statistics Systems to: Provide universal birth and death registration, support the production of timely and accurate statistics for development, enable tracking of social development goals, which Uganda has integrated in these MS guidelines.

##### The African Programme for the Accelerated Improvement of Civil Registration and Vital Statistics (APAI-CRVS)

It aims to strengthen CRVS systems in Africa so that every person, for example, in Uganda, is counted, and every vital event is registered, including death.

##### Africa CDC Operational Guide for Mortality Surveillance 2024

These outline key steps upon which Uganda has established a mortality surveillance system, from assessment and design to implementation and evaluation, emphasizing adaptation to country-specific contexts for maximum effectiveness.

##### East African Regional Framework for Mortality Surveillance

It aims at improving mortality surveillance implementation by promoting standardization, capacity building, integration with health systems, data quality improvement, policy support, and cross-border collaboration in alignment with the Africa Agenda 2063.

#### The key National Legal Frameworks Enabling Mortality Surveillance

This focuses on the laws that support civil registration, death registration, cause-of-death certification, health data, vital statistics, and reporting, as well as MS data use.

##### The Constitution of the Republic of Uganda 1995 as amended

Chapter Three of the Constitution gives the state authority to register every birth, marriage, and death occurring in Uganda. Article 18 of the Constitution states that: The State shall take appropriate steps to register every birth, marriage and death occurring in Uganda.” This Article establishes the constitutional foundation for Civil Registration and Vital Statistics (CRVS) in Uganda, which includes mortality surveillance (MS). It places a duty on the state to ensure that all deaths are officially recorded, thereby supporting legal identity, public health planning, and accountability. Therefore, stakeholders should identify and notify all deaths, designated health personnel should conduct medical certification of the cause of death (MCCD) in health facilities, oversee verbal autopsies in communities, and report on time using established systems.

##### The Registration of Persons Act (Amendment) Act 2024 (ROPA):

It established the National Identification and Registration Authority (NIRA) and provides the primary legal framework for death registration in Uganda. Section 41 of the Act mandates the compulsory registration of all deaths within the country. This requirement is reinforced in

<!-- Source PDF page 95 -->

Section 42, “A registration officer in charge of a registration area shall register deaths and shall enter in the register, or cause to be entered, the prescribed particulars of every death notified.” Therefore, health workers, NIRA other stakeholders should ensure that every death is notified and processed as per the steps in Chapters Three and Four of this guideline.

##### The Births-and-Deaths-Regulations-2015

Under Section 15, all deaths occurring in Uganda shall be registered. Section 17 states that the administrator of the medical facility has to record a death. (1) Every death occurring in a medical facility shall be recorded by the administrator of the facility. (2)   The administrator referred to under sub-regulation (1) shall—(a) obtain particulars in regulation 20(2); and (b) file returns every week with the registration officer of the relevant area. (3) For the avoidance of doubt, an administrator who records a death under this regulation shall do so under the guidance of the registration officer of the area.

##### The Citizenship and Immigration Control Act of Uganda (1999, as amended)

The Act provides mechanisms for tracking the presence and movements of non-citizens, which is important when analyzing mortality trends among different population groups or geographic areas. This is particularly relevant in border districts or refugee-hosting communities, where unrecorded migrant deaths influence mortality data. The health teams at border points should closely work with authorities to streamline and handle mortality surveillance processes conclusively.

##### Data Protection and Privacy Act 2019

The Act ensures that mortality surveillance activities in Uganda uphold ethical standards of privacy, security, accuracy, and transparency, while enabling effective public health interventions.

##### The Public Health Act 2022

It also plays a critical supporting role in mortality surveillance, particularly in the notification and reporting of deaths, especially those related to communicable diseases and other public health concerns. For example, sections 10 give the Minister power to declare notifiable diseases, while section 11 gives rules on how to handle notification of infectious diseases. Therefore, MS teams should observe the law and ethical considerations in their activities; otherwise, in case of negligence or offences committed, the act provides for related penalties.

##### Commissions of Inquiry Act (Cap. 166)

It provides the legal framework for the President or relevant authority to appoint a commission to investigate matters of public interest, including unusual patterns or causes of death, public health emergencies, or mortality-related crises. Therefore, health workers in collaboration with other authorities should be in a position to investigate clusters of unexplained or excessive deaths, such as during disease outbreaks, disasters, or suspected negligence.

<!-- Source PDF page 96 -->

##### Partner Logos
