# Prevention, Control and Elimination of Cholera

*Operational Guidelines for National and District Health Workers and Planners*

**Ministry of Health, Uganda — 2025**

Department of Integrated Epidemiology, Surveillance and Public Health Emergencies

<!-- Source PDF page 1 -->

![Source illustration — PDF page 1](images/illustration-001-001.png)

<!-- Source PDF page 2 -->

## TABLE OF CONTENTS

- LIST OF TABLES — page xi
- LIST OF FIGURES — page xii
- LIST OF ACRONYMS AND ABBREVIATIONS — page xiii
- DEFINITION OF KEY TERMS — page xv
- FOREWORD — page xvi
- PREFACE — page xvii
- ACKOWLEDGMENTS — page xviii
- CHAPTER ONE: GOAL OF THE GUIDELINE — page 1
- 1.1 Overall Goal of the Guideline — page 1
- 1.2 The specific objectives are: — page 1
- 1.3 Strategies for Cholera Elimination are; — page 1
- 1.4 Critical Elements to ensure cholera elimination — page 2
- 1.5 Intended users of the guideline are: — page 2
- 1.6 When can the Guideline be used? — page 3
- 1.7 Structure of the Guideline — page 3
- CHAPTER TWO: GENERAL INFORMATION ON CHOLERA — page 4
- 2.0 Background — page 4
- 2.1 History of Cholera Outbreaks in Uganda — page 6
- 2.2 What Is New in this Guideline — page 8
- CHAPTER THREE: SURVEILLANCE, DETECTION AND CONFIRMATION OF CHOLERA 9
-  — page 3.0 Useful Information — page 9
- 3.1 Cholera Surveillance Objectives — page 10
- 3.2 Cholera Surveillance Before a Cholera Outbreak — page 10
- 3.3 How to detect a cholera outbreak — page 10

<!-- Source PDF page 3 -->

- 3.4 Rapid Verification and Investigation — page 11
- 3.5 Case Definition — page 12
- 3.5.1 Cholera alert and outbreak thresholds — page 13
- 3.5.1.1 Cholera alert/suspected cholera outbreak — page 13
- 3.5.1.2 Cholera outbreak — page 13
- 3.5.1.3 Institutional Cholera Outbreak — page 14
- 3.6 Declaration of Cholera Outbreak — page 14
- 3.7 Epidemiological Description and Mapping of Cases — page 14
- 3.7.1 Analyze and Interpret Data — page 14
- 3.8 Actions for the Surveillance Thresholds — page 16
- 3.8.1 Action following suspected cholera outbreak (cholera alert) — page 16
- 3.8.2 Action following Cholera outbreak — page 16
- 3.8.2.1 Community participation — page 16
- 3.8.2.2 Contact Tracing — page 16
- 3.8.2.3 Situation Reports (SITREP) — page 17
- CHAPTER FOUR: CONFIRMATION OF CHOLERA OUTBREAK — page 19
- Laboratory Testing and Confirmation — page 19
- 4.0 Useful Information — page 19
- 4.1 Laboratory functions in cholera outbreak investigation — page 20
- 4.2 Type of Laboratory Sample — page 20
- 4.2.1 Clinical samples — page 20
- 4.2.2 Environmental samples — page 21
- 4.3 Procedure for Clinical Sample Collection — page 21
- 4.3.1 Fresh stool samples — page 21
- 4.3.2 Rectal swabs — page 21
- 4.3.3 Viability of transport media — page 22
- 4.3.4 Testing specimens for specific DNA detection by PCR — page 22

<!-- Source PDF page 4 -->

- 4.3.5 Referral and transportation of samples using the hub system — page 23
- 4.3.6 Reporting of laboratory results — page 23
- 4.4 Factors that may affect the quality of laboratory tests — page 24
- 4.5 Collection and Storage of Cholera Isolates — page 24
- 4.6 Testing for Vibrio Cholera with RDTs (Screening test) — page 25
- 4.6.1 Summary of testing with RDTs — page 26
- 4.7 Laboratory Confirmation by culture — page 26
- CHAPTER FIVE: COORDINATION OF OUTBREAK RESPONSE — page 29
- 5.0 Useful Information — page 29
- 5.1 Multi-sectoral coordination of preparedness and response to cholera
- outbreaks — page 30
- 5.2 Structure of the emergency preparedness and response coordination in
- Uganda — page 31
- 5.3 Composition of Cholera Task Forces — page 33
- 5.3.1 Composition of the National Cholera Task Force (NCTF) — page 33
- 5.3.2 Composition of the District /City Cholera Task Force — page 36
- 5.4 Functions of the Cholera Task Forces — page 37
- 5.4.1 Functions of the National Cholera Task Force — page 37
- 5.4.2 Functions of the District/City Cholera Task Force — page 38
- 5.5 Cholera Preparedness and Response Plan — page 40
- 5.6 Coordination of supplies required for Cholera control — page 41
- 5.7 Public Health Emergency Operations Centers — page 42
- 5.8 Cross border coordination for cholera prevention and control — page 43
- 5.9 Monitoring and Evaluation of Cholera Response — page 44
- 5.9.1 Early Action Review — page 44
- 5.9.2 Intra-Action Review — page 44

<!-- Source PDF page 5 -->

- 5.9.3 After Action Review — page 45
- 5.10 Post-outbreak continuity of Cholera Prevention and Preparedness — page 45
- 5.10.1 Training of Health Workers — page 46
- 5.11 Documentation of the End of Cholera Outbreak — page 47
- CHAPTER SIX: CASE MANAGEMENT, SELECTIVE CHEMOPROPHYLAXIS, CHOLERA
- TREATMENT UNITS AND INFECTION PREVENTION AND CONTROL — page 49
- 6.0.1 Useful Information — page 49
- 6.0.2 Priority Interventions — page 50
- 6.1 Case management and Selected Chemoprophylaxis — page 51
- 6.1.0 Useful Information — page 51
- 6.1.1 Priority Interventions — page 51
- 6.1.1.1 Assessment and Classification of patients — page 52
- 6.1.1.2 Rehydration — page 54
- 6.1.1.2.1 No Dehydration: Treatment A — page 54
- 6.1.1.2.2 Some Dehydration - Treatment Plan B — page 56
- 6.1.1.2.3 Severe Dehydration: Plan C (Intravenous Therapy for severe cases) 56
- 6.1.1.2.4 Other considerations during rehydration and thereafter — page 57
- 6.1.1.2.5 Treatment of cholera in children with Severe Acute Malnutrition (SAM) — page 58
- 6.1.1.2.6 Treatment of cholera in Pregnancy — page 59
- 6.1.1.3 Treatment with Antibiotics — page 60
- 6.1.1.4 Anti-diarrheal, metronidazole and anti-emetics — page 60
- 6.1.1.5 Monitoring of Patients with Severe Cholera — page 61
- 6.1.1.6 Common Treatment Complications — page 62
- 6.1.1.7 Selective chemoprophylaxis — page 63
- 6.1.1.8 Mass chemoprophylaxis — page 64
- 6.1.1.9 Feeding cholera patients — page 65
- 6.1.1.10 Discharge and Health education for patients — page 65
- 6.1.1.10.1 Discharge Package — page 65
- 6.1.1.10.2 Health education for patients — page 65
- 6.1.1.11 The role of CHEWs and VHTs in promotion of early detection and treatment — page 66

<!-- Source PDF page 6 -->

- 6.1.1.12 Handling of the Dead, Burial and Funerals - Safe and Dignified Burial
- (SDBs) — page 67
- 6.1.1.13 Assessment of Quality of care in the CTU — page 68
- 6.2 Cholera Treatment Centers/ Units and Infection Prevention and Control
-  — page 70
- 6.2.0 Useful Information — page 70
- 6.2.1 Establishment of the CTU — page 71
- 6.2.2 Identifying a site for CTU — page 72
- 6.2.3 Setting up a CTU — page 72
- Components of a good CTU — page 74
- 6.2.4 Key tasks that should done in a CTU — page 74
- 6.2.5 Restriction of movement within the CTU — page 76
- 6.2.6 Evaluation of Services in the CTU/CTC — page 77
- 6.3INFECTION PREVENTION AND CONTROL IN THE CTU/CTC — page 79
- Isolation of Patients, Disinfection and cleaning, Waste disposal, Hand
- hygiene, Restriction — page 79
- 6.3.0 Useful Information — page 79
- 6.3.1 Priority Interventions — page 80
- 6.3.1.2 Hand Hygiene — page 80
- 6.3.1.2 Personal Protective Equipment — page 81
- 6.3.1.3 Laundry — page 82
- 6.3.1.4 Waste management — page 83
- 6.3.1.5 Disinfection inside the CTC — page 84
- 6.3.1.6 Protection of Chlorine Solutions from direct sunlight — page 85
- 6.3.1.7 Disposal of Faeces and Vomitus — page 85
- 6.3.1.8 Disposal of Solid Waste — page 86
- 6.3.1.9 Wastewater Control — page 86
- 6.3.1.10 IPC considerations during closure of CTU — page 87
- CHAPTER SEVEN: RISK COMMUNICATION AND COMMUNITY ENGAGEMENT — page 90 7.0 Useful Information — page 90

<!-- Source PDF page 7 -->

- 7.1 Clarifying Rumours and Community Concerns — page 91
- 7.2 Media Involvement in the Outbreak Response — page 92
- 7.3 Community Engagement — page 92
- 7.4 Social Mobilization for cholera prevention and control — page 94
- 7.4.1 Social Mobilization before an Outbreak — page 94
- 7.4.2 Social Mobilization during an Outbreak — page 95
- 7.5 Key Messages for dissemination — page 95
- CHAPTER EIGHT: ENVIROMENTAL HEALTH — page 101
- 8.0 Useful Information — page 101
- 8.1 Safe Water — page 102
- 8.1.0 Useful Information — page 102
- 8.1.2 Priority Interventions — page 102
- 8.1.2.1 Safe Water Supply — page 102
- 8.1.2.1.1 Types of Water Access Points — page 102
- 8.1.2.1.2 Contamination of Water Sources — page 103
- 8.1.2.1.3 Provision of Safe Drinking-Water — page 103
- 8.1.2.2 Ensuring Water Quality — page 105
- 8.1.2.2.1 Water Treatment for household and institutional use — page 105
- 8.1.2.2.2 Boiling — page 105
- 8.1.2.2.3 Making Water Safe by Chlorination — page 105
- 8.2 Safe Food and Beverages — page 108
- 8.2.0 Useful Information — page 108
- 8.2.1 Priority Interventions — page 108
- 8.2.1.1 Safe Food — page 108
- 8.2.1.1.1 Common Source of Food Contamination — page 108
- 8.2.1.1.2 Food handling and hygiene practices — page 109
- 8.2.1.1.3 Infant Feeding — page 109
- 8.3 Personal and Household Hygiene — page 110
- 8.3.1 Useful Information — page 110

<!-- Source PDF page 8 -->

- 8.3.2 Priority Interventions — page 110
- 8.3.2.1 Personal and Household Hygiene — page 110
- 8.3.2.1.1 Communal hand washing — page 111
- 8.4 Sanitation — page 111
- 8.4.1 Useful Information — page 111
- 8.4.2 Priority Interventions — page 112
- 8.4.2.1 Improvement of Sanitation — page 112
- 8.4.2.1.1 Solid Waste Management — page 114
- 8.4.2.1.2 Climate Health — page 115
- 8.4.2.1.3 Community participation in preventive efforts — page 116
- CHAPTER NINE: OUTBREAKS IN INSTITUTIONS AND CONGESTED SETTINGS — page 117
- 9.1.0 Useful Information — page 118
- 9.1.1 Priority Interventions — page 118
- 9.1.1.1 Measures to prevent cholera outbreaks in special settings — page 118
- 9.1.1.1.1 Prevention of cholera spread during and after outbreaks — page 119
- 9.1.1.1.2 General interventions to control cholera in congested settings — page 120
- 9.1.1.2 Mental Health Units — page 121
- 9.1.1.3 Internally Displaced Persons and Refugees Camps — page 121
- 9.1.1.4 Slum Areas — page 122
- 9.1.1.5 Landing Sites — page 123
- 9.1.1.6 Public Health Measures for Refugees from Cholera-Affected Countries — page 123
- CHAPTER TEN: ROLE OF ORAL CHOLERA VACCINE (OCV) — page 129
- USE OF ORAL CHOLERA VACCINES (OCV) FOR CHOLERA PREVENTION — page 129
- 10.0 Useful Information — page 129
- 10.1 Priority Interventions — page 130
- 10.1.1 Types of OCVs prequalified for use by WHO — page 130
- 10.1.1.1 Target population for vaccination — page 131
- 10.1.2 Resource mobilization and allocation during planning of OCV Campaign — page 132

<!-- Source PDF page 9 -->

- 10.1.3 Importance of integrated approach for cholera control using OCV133
- 10.1.4 Campaign timing and scheduling — page 134
- 10.1.5 OCV delivery strategies and sites — page 134
- 10.1.6 Organizing OCV vaccination site — page 134
- 10.1.7 Storing and transporting the vaccines — page 136
- 10.1.8 Recording and completing the tally sheets — page 136
- 10.1.9 Monitoring and reporting of adverse events — page 136
- ANNEX 1: CHOLERA CASE INVESTIGATION FORM — page 1
- ANNEX 2: CHOLERA CASE SURVEILLANCE FORM (LINE LIST) — page 7
- ANNEX 3: CHOLERA CONTACT TRACING FORM — page 8
- ANNEX 4: A FILLED SITUATION REPORT TEMPLATE — page 9
- ANNEX 5: CHOLERA STANDARD LABORATORY INVESTIGATION FORM — page 11
- ANNEX 6: SUB-COMMITTEES OF THE DISTRICT TASK FORCE AND THEIR TEAM
- HEADS/CHAIRPERSONS — page 14
- ANNEX: 7: A CHECKLIST OF THE REQUIRED ACTIONS FOR CHOLERA PREVENTION
- AND CONTROL — page 15
- ANNEX 8: NATIONAL CHOLERA KIT FOR 100 PATIENTS AND CONTACTS — page 17
- ANNEX   9: END OF CHOLERA OUTBREAK REPORT TEMPLATE — page 18
- ANNEX 10: CHOLERA PATIENT MONITORING (OBSERVATION)      FORM — page 19
- ANNEX 11: CHOLERA TREATMENT UNIT (CTU) — page 20
- ANNEX 12: CTU PATIENT EVALUATION FORM — page 22
- ANNEX 13: PREPARATION AND USE OF CHLORINE DISINFECTANTS — page 23
- ANNEX 14: ORAL CHOLERA VACCINE CARD SAMPLE — page 24
- ANNEX 15: ORAL CHOLERA VACCINE TALLY SHEET — page 25
- ANNEX 16: ROLES AND RESPONSIBILITY OF MEMBERS OF THE VACCINATION TEAM — page 26

<!-- Source PDF page 10 -->

RESOLUTIONS ........................................................................................................................... 27

<!-- Source PDF page 11 -->

## LIST OF TABLES

- Table 1: Roles and responsibilities of stakeholders — page 33
- Table 2: Assessment and Classification of Cholera Patients — page 52
- Table 3: Rehydration protocol for Plan B — page 56
- Table 5: Recommended Antibiotics — page 60
- Table 6: Recommendations about Zinc — page 61
- Table 7: Common treatment complications and how to prevent them from occurring — page 62
- Table 8: Recommended antibiotics and doses for selective chemoprophylaxis — page 63
- Table 9: Amount of stock solution required for water treatment — page 106

<!-- Source PDF page 12 -->

## LIST OF FIGURES

- Figure 1. Joint operational framework for cholera preparedness and response. — page 5
- Figure 2: Cholera cases in Uganda, 1971-2023 — page 7
- Figure 3. A map of Uganda showing the districts that reported cholera cases between 2019-2023 — page 7
- Figure 4 Summary of the epidemiological analysis to be performed — page 15
- Figure 5. Interpretation of RDT test — page 25
- Figure 6. Cholera RDT testing procedure for stool swabs — page 26
- Figure 7.  Steps in laboratory confirmation of cholera Outbreak — page 27
- Figure 8: Multi-sectoral operational framework — page 31
- Figure 9:  Coordination structure for Emergency Preparedness and response — page 32
- Figure 10: Decision making tree for OCV use — page 132
- Figure 11: An integrated approach leads to synergistic cholera prevention and control — page 133

<!-- Source PDF page 13 -->

## LIST OF ACRONYMS AND ABBREVIATIONS

|**ACHS**|**Assistant Commissioner Health Services**|
|---|---|
|**AWD**|**Acute Watery Diarrhea**|
|**BFU**|**Baylor Foundation Uganda**|
|**CBOs**|**Community Based Organizations**|
|**CHEWS**|**Community Health Extension Workers**|
|**CHO**|**City Health Officer**|
|**CHS**|**Commissioner Health Services**|
|**CFR**|**Case Fatality Rate**|
|**CPHL**|**Central Public Health Laboratories**|
|**CTC**|**Cholera Treatment Centre**|
|**CLTS**|**Community-Led Total Sanitation**|
|**DHIS-2**|**District Health Information System -2**|
|**DHT**|**District Health Team**|
|**DRRT**|**District Rapid Response Team**|
|**DTF**|**District Task Force**|
|**EHO**|**Environmental Health Officer**|
|**PHEOC**|**Public Health Emergency Operation Centre**|
|**DPD**|**Diethyl Phenylene diamine**|
|**HMIS**|**Health Management Information System**|
|**HP&E**|**Health Promotion and Education**|
|**JMS**|**Joint Medical Stores**|
|**IDI**|**Infectious Diseases Institute**|
|**IDPs**|**Internally Displaced Persons**|
|**IEC**|**Information, Education and Communication**|
|**IPC**|**Infection Prevention and Control**|
|**IV**|**Intravenous**|
|**JMS**|**Joint Medical Stores**|
|**LC**|**Local Council**|
|**MDLG**|**Mbale District Local Government**|
|**MoH**|**Ministry of Heath**|
|**MOES**|**Ministry of Education and Sports**|
|**MPHO**|**Masters of Public Health Officer**|
|**MRRH**|**Mbale Regional Referral Hospital**|

<!-- Source PDF page 14 -->

|**MSF**|**Mediciens San Frontiers**|
|---|---|
|**MUSPH**|**Makerere University School of Public Health**|
|**MWE**|**Ministry of Water and Environment**|
|**NMS**|**National Medical Stores**|
|**NO**|**Nursing Officer**|
|**NRRT**|**National Rapid Response Team**|
|**NTF**|**National Task Force**|
|**NGOs**|**Non-Governmental Organizations**|
|**NDP**|**National Development Plan**|
|**NICEP**|**National Integrated Cholera Elimination Plan**|
|**ODF**|**Open Defecation Free**|
|**OPM**|**Office of the Prime Minister**|
|**ORS**|**Oral Rehydration Salt**|
|**ORT**|**Oral Rehydration Therapy**|
|**OCV**|**Oral Cholera Vaccine**|
|**PCR**|**Polymerase Chain Reaction**|
|**PE**|**Principal Epidemiologist**|
|**PEHI**|**Principal Environmental Health Officer**|
|**PEHO**|**Principal Environmental Health Inspector**|
|**PHE**|**Public Health Emergency**|
|**RDT(s)**|**Rapid Diagnostic Test(s)**|
|**RO**|**Research Officer**|
|**RRH**|**Regional Referral Hospital**|
|**SE**|**Senior Epidemiologist**|
|**SFP**|**Surveillance Focal Person**|
|**SMO**|**Senior Medical Officer**|
|**SPH**|**Senior Health Planner**|
|**TA**|**Technical Assistant**|
|**UNICEF**|**United Nations International Children Education Fund**|
|**URCS**|**Uganda Red Cross Society**|
|**UNHLS**|**Uganda National Health Laboratory Services**|
|**VHT**|**Village Health Team**|
|**VPH**|**Veterinary Public Health**|
|**WASH**|**Water Sanitation and Hygiene**|
|**WHO**|**World Health Organization**|

<!-- Source PDF page 15 -->

## DEFINITION OF KEY TERMS

**Acute Watery Diarrhoea (AWD):** An illness characterized by three or more loose or watery (non-bloody) stools within 24 hours.

**Household:** A person or group of people who usually live and eat together.

**Thresholds:** Markers that indicate an unusual situation and require something to happen or change.

**Signal:** Information that may indicate a public health event.

**Cholera hotspot:** A geographically limited area (e.g. city, district, sub-county) where environmental, cultural, and/or socioeconomic conditions facilitate the transmission of the disease and where cholera persists or re-appears regularly.

**Cholera-endemic area:** An area (district/city/sub-county) where confirmed cholera cases, resulting from local transmission, have been detected in the last 3 years.

**Cholera elimination:** Any geographical area that reports no confirmed cases with evidence of local transmission for at least 3 consecutive years and has a well-functioning epidemiologic and laboratory surveillance system able to detect and confirm cases.

<!-- Source PDF page 16 -->

## FOREWORD

Cholera remains a significant public health challenge in Uganda, impacting communities and highlighting the persistent disparities in access to safe water, sanitation, and hygiene. This National Guideline for Cholera Prevention, Control, and Elimination represents a crucial step forward in our collective efforts to eradicate this preventable disease. It provides a comprehensive and evidence-based framework for coordinated action at all levels from national policy to community engagement.

Uganda has demonstrated a strong commitment to improving public health, and this guideline reflects the dedication of numerous stakeholders, including healthcare professionals, researchers, policymakers, and community leaders. Their combined expertise has shaped a document that addresses the multifaceted nature of cholera, encompassing prevention, surveillance, case management, and community mobilization.

This guideline is not merely a technical document; it is a call to action. It empowers individuals, communities, and organizations to take ownership of cholera prevention and control. By implementing the strategies outlined within these pages, we can create a healthier and more resilient Uganda, free from the devastating impacts of cholera. I urge all stakeholders to embrace this guideline and work together to achieve our shared vision of a cholera-free nation.

![Source illustration — PDF page 16](images/illustration-016-002.png)

Dr. Diana Atwine **Permanent Secretary**

<!-- Source PDF page 17 -->

## PREFACE

Cholera continues to pose a significant public health threat in Uganda, disproportionately affecting vulnerable populations and hindering national development goals. Despite ongoing efforts, the recurring nature of outbreaks underscores the need for a comprehensive and coordinated approach to cholera prevention, control, and ultimately, elimination. This National Guideline represents a critical step towards achieving this objective.

This document provides a consolidated framework for evidencebased strategies, drawing upon best global practices and adapting them to the specific context of Uganda. It serves as a vital resource for healthcare professionals, policymakers, community leaders, and all stakeholders involved in cholera prevention and control. The guideline emphasizes a multi-sectoral approach, recognizing the interconnectedness of water, sanitation, hygiene, health, and community engagement in effectively addressing cholera.

The development of this guideline has been a collaborative effort, involving extensive consultations with experts, practitioners, and community representatives. This collective knowledge and experience have enriched this document and ensured its relevance and practicality. We are confident that this guideline will provide a roadmap for effective action and further contribute to reducing the burden of cholera in Uganda as we work towards the elimination of Cholera in Uganda by 2030.

We urge all stakeholders to embrace and implement these guidelines, working together towards a cholera-free Uganda.

![Source illustration — PDF page 17](images/illustration-017-003.png)

Dr. Olaro Charles

**Ag. Director General of Health Services**

<!-- Source PDF page 18 -->

## ACKOWLEDGMENTS

The development of this National Guideline would not have been possible without the tireless efforts and dedication of numerous individuals and organizations. We extend our sincere gratitude to all who contributed their expertise, time, and resources to this critical endeavor. The Ministry of Health is grateful to the following for their immeasurable contribution to the development of this guideline;

- World Health Organization for the technical support

- UNICEF for the technical support provided

- US CDC for the technical and financial support

- Baylor Uganda for the financial and technical support

The writing team that comprised of Dr. Bwire Godfrey- ACHS PHEPR, Dr. Allan Muruta- CHS IES&PHE, Dr. Moses Ebong- PMO, Dr. Anne Nakinsige- P.E, Maureen Nyonyintono- PHO-WHO, Juliet Kasule US CDC, Dr. Freda Loy Aceng, S.E- MOH, Ibrahim Mugerwa, Lab-CPHL, Petranilla Nakamya MOH, Dr. Bonny Kintu, SMO- MOH, Sandra Nabatanzi US CDC, Tabley Bakyaita Basajjatebadiba MOH, Phillip Katabarwa, C.O- MOH, Dr. Michael Mutegeki, SMO- MOH, Ritah Namusose, CPHL, Dr. Stella Maris Lunkuse, S.E- MOH, Milton Makoba Wetaka, MOH, Charles Wagoli MOH, Kevin Adongo, MPHOSPH, Lydia Lutalo MPHO-MUSPH, Bernard Lubwama, S.E- MOH, Flavia Wanyoto, R.O MOH, Lydia Nakire, T.A- I.D.I, Dr. Sunday Haggai Kithula, SMO- MOH, Job Kyakakasibwa Epi- MOH, Vallence Uragiwenimana, PEHO- MOH, Okia Bosco PEHI- MOH, Dr. Mugonyi Moses, CHO- MCLG, Kalule Charles, PHO- URCS, Dr. Jonathan Wangisi DHO- MDLG, Wandera Charles, ACHO-EH MCLG, Nyongesa Edward Juma, CSFP MCLG, Dr. Okiror William Mbale EOC Manager, Buyi Benjamin DSFP MDLG, Kudhongania Beatrice ADHO-EH MDLG, Kigongo Frederick DLFP MDLG, Osikol Emmanuel, L.OMREOC, Wanyibe Dansan, SLT- MRRH, Mwolobi Esther, Duty Officer-MREOC, Ndagire Margaret, Epi- MREOC, Ferara Yaweri, HSDSFP- MCLG, Monje Loy, Biostat-MCLG, Kisaakye Margaret Kabiredi, Biostat- MDLG, Shimiyu Francis, Intern EHO-MUSPH,

<!-- Source PDF page 19 -->

Okwadi Denis, Intern EHO- MSPH, Aleet Peter, Intern EHO-MSPH, Morunyang Simon Peter, Intern EHO SPH, Mwajuma Nagudi, SNOMDLG, Tebaluk Julius, C.O-MRRH, Dr. Lubega Simon Peter, FPCCO-BFU, Mutyembu Florence, ANO-MRRH,

![Source illustration — PDF page 19](images/illustration-019-004.png)

Dr. Allan Muruta Niyonzima **Commissioner of Health Services**

**(Department of Integrated Epidemiology, Surveillance and Public Health Emergencies)**

<!-- Source PDF page 20 -->

## CHAPTER ONE: GOAL OF THE GUIDELINE

### 1.1 Overall Goal of the Guideline

The overall goal of this guideline is to contribute to the zero incidence and mortality due to cholera and other diarrheal diseases.

### 1.2 The specific objectives are:

   1. To prevent new cases of cholera by promoting intensive public health education on the use of safe water, sanitation, hygiene, and food safety complemented by Oral Cholera Vaccination (OCV) for vulnerable groups.

   2. To prevent deaths from cholera through early detection, reporting, appropriate case management, and increased access to healthcare.

### 1.3 Strategies for Cholera Elimination are;

   - i. To effectively prevent, control, and ultimately eliminate cholera, a multifaceted approach is required, involving strong coordination by the key sectors including Planners, Water, Health, Environmental Health, and Communication experts. These will need to play complementary roles and responsibilities acting together with leaders at all levels.

   - ii. Strengthening cross-border mechanisms to prevent the transboundary spread of cholera will be very important in averting the current trend of cholera outbreaks within the country.

This guideline offers a framework for the development of a comprehensive multi-sectoral preventive, preparedness, and response strategy aimed at the elimination of cholera in Uganda by 2030.

<!-- Source PDF page 21 -->

### 1.4 Critical Elements to ensure cholera elimination

The critical elements aimed at elimination are grossly covered under the areas of cholera Prevention, Preparedness and Response. For a maximum impact, these elements are implemented in an integrated manner. A summary of the intervention per element is as below;

**Prevention** : Priorities will include improving access to safe water, promoting sanitation, hygiene, health education on food safety, developing and reinforcement of by laws and regulations and the targeted use of oral cholera vaccine.

**Preparedness** :  Priorities will include training of health personnel in detecting, identifying, reporting and treating cases; development of district and national plans of action before, during and after the outbreak, pre-positioning of medical and laboratory supplies including oral cholera vaccines at national, regional, district or health facility levels and pre-positioning of water treatment supplies including chlorine tablets at all levels.

**Response** : This will include timely detection, reporting, confirmation and appropriate management of cases in order to prevent spread, avert morbidity and mortality of cholera cases.

### 1.5 Intended users of the guideline are:

   - i. Health Sub-District In-charges and their teams

   - ii. Heads of Hospitals and Health Facilities

   - iii. District Health Officers and District Health Teams

   - iv. District Sector Heads

   - v. Technical Staff of Ministry of Health

   - vi. Planners and Accounting Officers at National, Regional, District levels including Urban Authorities

   - vii. Heads of Institutions e.g. Prisons, Training Institutions, Army, Police, Farms

<!-- Source PDF page 22 -->

xiii. IDP camps, Refugee settlements, etc.

ix. Development and implementing Partners

x. Consultants and Researchers.

### 1.6 When can the Guideline be used?

This guideline can be used before, during, and after an outbreak. In the event of an outbreak, it can be used to assess whether any of the aspects of cholera prevention and control have been overlooked.

### 1.7 Structure of the Guideline

This guideline is structured into chapters and sections. The first chapter contains general information on cholera while the remaining chapters provide the required technical information for effective cholera prevention, preparedness, and response. At the start of each chapter are keywords, useful information, and priority interventions. Each ends with assessment questions.

<!-- Source PDF page 23 -->

## CHAPTER TWO: GENERAL INFORMATION ON CHOLERA

### 2.0 Background

Cholera is an acute diarrheal disease caused by infection of the intestine with the bacterium Vibrio cholera, sero-group O1 or O139. Both children and adults can be infected. The incubation period of cholera is short (2 hours to 5 days).

About 20% of those who are infected with V. cholera develop acute watery diarrhea and approximately 20% of these individuals develop severe watery diarrhea. Additionally, a number of these may also develop vomiting. If these patients are not promptly and adequately treated, the loss of fluid and salts can lead to severe dehydration and death within hours. The case fatality rate in untreated cases may be as high as 30–50%. However, treatment with rehydration and antibiotics is effective, and if provided rapidly and appropriately, reduces the case fatality rate to below 1.0 %.

Cholera is usually transmitted through the consumption of water or food contaminated by feces bearing the cholera organism and remains an ever-present risk in many countries. New outbreaks can occur in any part of the world where water supply, sanitation, food safety, and hygiene are suboptimal. Cholera outbreaks are common following heavy rains which result in flooding and destruction of sanitation facilities consequently increasing the risk of water contamination.

The risk of cholera is considerably increased in humanitarian emergencies. This is due to significant population movements and overcrowding in sites where displaced persons gather and frequent, disruption of/ inadequate access to healthcare services, clean water, sanitation, and hygiene. The risk is also high in areas with poor sewage systems. The Spread of the disease within an area can be reduced through early detection and confirmation of cases, followed by an appropriate, well-coordinated multi-sectoral response.  In the event of

<!-- Source PDF page 24 -->

an outbreak, swift development and thorough implementation of an integrated multi-sectoral cholera response plan contribute to a more effective and efficient outbreak response.

Oral cholera vaccine may be used as a complementary measure for controlling cholera in outbreak areas and for preventing outbreaks in areas that are at high risk of cholera.  There is need to implement key tasks in the critical areas of leadership, coordination, and integrated response to improve the coordination, integrated preparedness, and response to cholera.

In the long term, improvements in water supply, sanitation, food safety, and community awareness of preventive measures are the best means of preventing cholera and other diarrheal diseases.  The joint operational framework is key for improving coordinated and integrated multi-sector cholera preparedness and response.

![Source illustration — PDF page 24](images/illustration-024-005.png)

**Figure 1. Joint Operational Framework for Cholera Preparedness and Response.**

<!-- Source PDF page 25 -->

Effective cholera control and elimination requires three critical elements of prevention, preparedness and response that must all be active. For each of those three elements, there are several tasks that must be implemented within two tiers.

The first tier sets out tasks that provide an enabling environment that is leadership and multi-sector coordination. The second tier is operational and involves components such as integrated planning, integrated early warning early action, integrated analysis, integrated response, and integrated learning for effective function. Critical implementation of all the above results in robust systems able to prevent, prepare for, quickly and effectively respond to cholera outbreaks.

### 2.1 History of Cholera Outbreaks in Uganda

During the period of 2017 to 2022, 23/146 (16.0%) local governments reported at least 01 (one) cholera outbreak. The average number of cases reported per year was 815 cases. The most-at-risk districts were border districts and districts near water bodies. Outbreaks were mostly recorded among fishing communities, slum dwellers, refugee settings, and communities living along the borders. Trans-boundary movement of people especially in districts bordering South Sudan, Kenya, Tanzania, and Democratic Republic of Congo has been noted as a major contributing factor to cross border infection spread.

There has been a marked decline in the frequency and severity of cholera outbreaks within the country over the past decades. This is attributed to the gradual improvement in WASH and the recent introduction of oral cholera vaccination as a complementary measure since 2018. In 2023, the country re-conducted a mapping exercise to identify high-risk cholera areas. Resultantly,13 districts/cities were earmarked as high-risk namely, Kayunga, Namayingo, Isingiro, Nebbi, Moroto, Nabilatuk, Busia, Kikuube, Napak, Mbale city, Hoima, Kotido and Kampala. In order to reduce the risk of cholera in these areas,

<!-- Source PDF page 26 -->

they shall all be targeted for strengthening of water, sanitation and hygiene. Additionally, some of these areas shall be prioritized for preventive oral cholera vaccination.

Below is the trend of cholera outbreaks in Uganda since 1971 -2023

![Source illustration — PDF page 26](images/illustration-026-006.png)

<!-- Start of picture text -->
50000 45000 CASES DEATHS 40000 35000 30000 25000 20000 15000 10000 5000 0 1971 1973 1975 1977 1979 1981 1983 1985 1987 1989 1991 1993 1995 1997 1999 2001 2003 2005 2007 2009 2011 2013 2015 2017 2019 2021 2023 <!-- End of picture text -->

**Figure 2: Cholera cases in Uganda, 1971-2023**

![Source illustration — PDF page 26](images/illustration-026-007.png)

**Figure 3. A Map of Uganda Showing the Districts that Reported Cholera cases between 2019-2023**

<!-- Source PDF page 27 -->

### 2.2 What Is New in this Guideline

   1. Overall change in national cholera strategy from control to elimination.

   2. Requirement of laboratory confirmation for all cholera suspect cases through the support of regional referral hospital laboratories.

   3. Routine use of Cholera Polymerase Chain Reaction (PCR) for confirmation of cholera.

   4. Revised guidance on cholera surveillance thresholds i.e., cholera alert and cholera outbreak thresholds.

   5. Revised case management and infection prevention and control protocols.

   6. Role of Regional Public Health Emergency Operations Centers (EOCs) in coordination of cholera outbreaks.

   7. Public health measures to control cholera among incoming refugees/asylum seekers from countries with active cholera outbreaks.

   8. Improved therapeutics of the oral cholera vaccines.

<!-- Source PDF page 28 -->

## CHAPTER THREE: SURVEILLANCE, DETECTION AND CONFIRMATION OF CHOLERA

<!-- Start of picture text -->
Risk factor identification <!-- End of picture text -->

![Source illustration — PDF page 28](images/illustration-028-008.png)

**_Picture 1. Rapid response team: Officers conducting inspection of water point_** **_and collection of water sample for microbiological analysis_**

### KEY WORDS

Surveillance, Early Detection, Rapid Verification, Outbreak Investigation, Cholera Alert, Cholera Outbreak

### 3.0 Useful Information

Prevention and control of cholera relies on effective surveillance systems. Surveillance is the ongoing systematic collection, analysis, interpretation and timely dissemination of health data for informed decision-making and action.

Strengthening cholera surveillance expedites detecting the index case and initiating the outbreak control measures through an integrated approach. Surveillance should result in early detection and rapid verification to guide response.

<!-- Source PDF page 29 -->

### 3.1 Cholera Surveillance Objectives

- To detect and respond promptly to cholera signals.

- To conduct immediate reporting of cases and deaths before, during and after an outbreak.

- To collect and transport stool specimens for timely confirmation of cholera outbreaks.

- To monitor the trend of cases during an outbreak.

- To inform prevention and control interventions.

### 3.2 Cholera Surveillance Before a Cholera Outbreak

In areas where a cholera outbreak is not yet declared, passive surveillance is done. Districts, with support from the REOCs, should carry out routine risk assessments for cholera and develop, update and implement the district cholera contingency plans before any outbreak. The plans should be comprehensive and integrated, involving prevention, preparedness, and response activities.

Early detection and reporting of suspected cholera cases is achieved by continuous sensitization of the population and local leaders. During the preparedness phase, integrated training of community and facility level health workers on cholera is also important to keep the index of suspicion high.

### 3.3 How to detect a cholera outbreak

Information about a possible cholera outbreak can be obtained by any of the following ways;

- Clinical suspicion by the health workers at the health facilities.

- Signals from the community including Village Health Team members (VHTs), CHEWs, local authorities, and religious leaders.

- Reports of diarrheal cases from health facilities, private clinics, drug shops, pharmacies, points of entry, and traditional healers.

- Media reports of clustered diarrhea-related illness or deaths.

<!-- Source PDF page 30 -->

- Information from the District Health Information System (DHIS) system.

- Information from a hotline or M-trac (6767).

It is important to quickly verify and confirm the outbreak regardless of how information of a suspected cholera outbreak is obtained.

### 3.4 Rapid Verification and Investigation

When a cholera outbreak is suspected, the District Health Officer (DHO) must be notified immediately. In turn, the DHO should also notify Ministry of Health within 24 hours through a spot report. A multidisciplinary District Rapid Response Team (DRRT) should be sent within 24 hours to the affected area in order to confirm the outbreak and take the first measures to control further spread of the disease.

The District Rapid Response Team should consist of the following;

- Clinician (medical doctor, clinical officer or nurse) who will verify patients’ clinical symptoms and train health care workers in case management.

- Laboratory staff who will take stool samples from all suspects for laboratory confirmation of cholera and train health care workers in correct sample collection procedures. Environmental samples should also be taken to ascertain the source of the outbreak.

- Health inspector/ environmental health officer who will promote WASH and investigate the possible sources of contamination.

- Health Educator who will disseminate key cholera preventive messages, assess community perceptions about cholera, and allay any fears within the community.

Where it is not possible to get all the specialties, a small team should adopt an integrated and comprehensive approach to address all aspects of the investigation. This team should work with local authorities and health facility staff to identify which control interventions to implement.

<!-- Source PDF page 31 -->

#### Investigation of the Outbreak

While in the field, the DRRT members should collect information about establishing the source of infection and risk/exposure factors. The teams should use standard case definitions to identify and classify cases. The team should work and report findings, including risks and assessed needs, to decision-makers as quickly as possible in to provide a rapid and focused response.

The teams should carry enough supplies to collect and transport stool samples, supplies to treat any patients present on site, ensure basic infection prevention and control (IPC) measures in the treatment centre, and conduct community water, sanitation and hygiene (WASH) investigations.

Guidelines, protocols and information, education and communication (IEC) materials should also be taken and distributed in the field.

### 3.5 Case Definition

Community case definition: Any person aged 2 years and above with lots of watery diarrhea.

Suspected case: where an outbreak is not declared;

- Any person aged 2 years and above presenting with acute watery diarrhea and dehydration OR a death from acute watery diarrhea.

- Where an outbreak is declared;

- Any person aged 2 years and above presenting with acute watery diarrhea and dehydration OR a death from acute watery diarrhea.

#### Note:

1. Acute watery diarrhea is an illness characterized by three or more loose or watery (non-bloody) stools within 24 hours.

2. For children below 2 years, cholera should only be suspected if there is another household member confirmed with cholera.

<!-- Source PDF page 32 -->

- Probable case: Any suspected cholera case who tests positive on RDT.

- Confirmed cholera case(s): A suspected or probable case with V. cholera O1 or

❖ O139 confirmed by culture or PCR.

Once the cholera outbreak has been confirmed, the source of transmission (water or food) must be established to institute appropriate control measures.

#### 3.5.1 Cholera alert and outbreak thresholds

##### 3.5.1.1 Cholera alert/suspected cholera outbreak

A suspected cholera outbreak (cholera alert) is defined by the detection of at least one of the following:

a) two or more people aged two (2) years or older with acute watery diarrhea and severe dehydration, or dying from acute watery diarrhea, from the same area, within 1 week.

b) one case of acute watery diarrhea testing positive for cholera by rapid diagnostic test (RDT) in an area that has not yet detected a confirmed case of cholera (including areas at risk for extension from a current outbreak).

c) one or more confirmed cholera cases with NO evidence of local transmission.

Health facilities and community health workers should immediately report any cholera alert to the next level. The district health authorities shall then initiate a field investigation to confirm the cholera outbreak and implement control measures.

##### 3.5.1.2 Cholera outbreak

A cholera outbreak is defined by the occurrence of at least one confirmed case of cholera and evidence of local transmission. **Note** : Local transmission is defined as two (2) or more households being affected.

<!-- Source PDF page 33 -->

##### 3.5.1.3 Institutional Cholera Outbreak

Is defined as two (2) or more confirmed cholera cases in closed institutions e.g., schools, markets, prisons, police cells, barracks, IDPs camps, and refugee settlements.

**Note:** **_All cholera suspects should have samples collected for confirmation._** This is in line with the current National Cholera Elimination strategy. Ultimately, only confirmed cholera cases should be reported as cholera cases.

### 3.6 Declaration of Cholera Outbreak

Upon justification of the existence of a cholera outbreak, the Director General Health Services in consultation with the relevant stakeholders will assess the risk and possibly declare the outbreak.

### 3.7 Epidemiological Description and Mapping of Cases

At the health facility, the health workers should assess every case and fill in a cholera case investigation form ( **Annex 1** :). This information helps to identify the most affected population, source of infection, and the potential route of transmission.

In addition, to filling out a case investigation form the health workers should compile a line list of cholera cases ( **Annex 2** :) which is updated and submitted daily to the district.

#### 3.7.1 Analyze and Interpret Data

The surveillance team supported by the district biostatistician or HMIS focal person should analyze and interpret cholera data regularly to guide response and control interventions. Report case-based information immediately and summarize the information monthly for routine surveillance.

Assess risk factors to improve control of sporadic cases and outbreaks by performing the following analysis:

- Time: Plot daily /weekly cases and deaths and construct an epidemic curve during outbreaks.

<!-- Source PDF page 34 -->

- Place: Plot the geographical location of the households with cholera cases to generate a sketch map. The map should have important landmarks e.g. rivers, water sources, health facilities, factories etc.

   - Person: Count daily / weekly total cases and deaths for sporadic cases and during outbreaks. Analyze distribution of cases by age, sex, and according to sources of drinking water.

- The REOC should as well provide technical support to the district team in analysis and interpretation of data including generation of information products.

![Source illustration — PDF page 34](images/illustration-034-009.png)

**Figure 4 Summary of the epidemiological analysis to be performed**

<!-- Source PDF page 35 -->

### 3.8 Actions for the Surveillance Thresholds

#### 3.8.1 Action following suspected cholera outbreak (cholera alert)

The following should be done immediately:

- Report to higher level

- Conduct a rapid risk assessment to guide the next steps

- Collect stool samples from all suspect cases and then manage and treat the case(s) according to these guidelines

- Promote infection, prevention, and control at all levels

- Promote WASH activities at all levels

- Provide selective chemoprophylaxis to all contacts

- Conduct case-based investigation and active search to identify similar cases.

- Activation of REOC into alert mode.

#### 3.8.2 Action following Cholera outbreak

##### 3.8.2.1 Community participation

- Engage the community members, leaders, and VHTs/CHEWs to identify and refer suspected cholera cases promptly for confirmation and care.

- Visit household members to a suspect or confirmed case and give them a comprehensive cholera preventive package including; selective chemoprophylaxis of contacts, health education, and water treatment reagents.

- Disseminate community case definitions widely to promote early case detection, and timely reporting and treatment.

- Health workers should investigate any suspected cholera community death before including them on the line list.

##### 3.8.2.2 Contact Tracing

Contact tracing aims to identify and follow up people who interacted closely with cholera cases within seven days of exposure or visited / stayed in the household of cholera cases or those involved in the transportation of the case.

Contact tracing is conducted by health workers and involves listing persons followed by physically visiting them to carry out the following;

<!-- Source PDF page 36 -->

- Identify any contact exhibiting symptoms for referral to the health facility.

- Take samples from ALL cases that meet the case definition.

- Give selective chemoprophylaxis to the contacts who have not yet developed signs and symptoms and have not exceeded seven days post-contact.

- Promote household treatment of drinking water (with chlorine tablets) or water dispensers at accessible points or by boiling.

- Evaluate and promote WASH

- Promote food safety

- Health education on prevention and control of cholera

- In areas where vaccination has been conducted, assess vaccination status

- Document the status of each exposed person in a contact list: Template ( **Annex 3** :)

##### 3.8.2.3 Situation Reports (SITREP)

All districts with cholera outbreaks should submit daily situational reports to MOH. This report gives the daily number of new cholera cases and deaths and the summary of the public health interventions (especially access to safe water, proper excreta waste management and sufficient hygiene practices, selective chemoprophylaxis) being conducted by the district.

The REOC should support the district team in developing daily situational reports.

The situational reports should be submitted to district leadership, Regional Emergency Operational Center, the Department of Integrated Epidemiology, Surveillance and Public Health Emergencies and Ministry of Health leadership.

The reports should be submitted daily until the outbreak is contained. District template for a situational report **(Annex 4).**

<!-- Source PDF page 37 -->

###### ASSESSMENT OF THE OUTBREAK DETECTION

- 1) How were the first cases notified to health authorities (surveillance system, media release, radio announcements, informal sources, others)?

- 2) At the beginning, what alerted people to the possibility of an outbreak:

   - a. A sudden occurrence of the disease?

   - b. A sudden increase in the number of cases?

c. An abnormal number of deaths?

- 3) What was the time period between the development of symptoms and detection of the index case?

- 4) On what basis was it decided that this was an outbreak: Local transmission or no local transmission?

- 5) How long did the information take to reach decision-making level (HF, DHT, MoH etc) from the area where the outbreak occurred? (recommended to be done within 24 hrs)

- 6) Following the report to the district, what measures were instituted?

- 7) Did the district compile and submit the daily situational report?

- 8) What were the first actions taken at the health facility or district level:

   - a. Telephone call to the affected areas to verify signals?

   - b. Dispatch of a rapid-response team?

   - c. Other measures taken?

<!-- Source PDF page 38 -->

## CHAPTER FOUR: CONFIRMATION OF CHOLERA OUTBREAK

### Preparation of cholera sample for transport to testing laboratory

![Source illustration — PDF page 38](images/illustration-038-010.png)

![Source illustration — PDF page 38](images/illustration-038-011.png)

**_Picture 2. Transport media, Cary Blair is the recommended transport media_**

### Laboratory Testing and Confirmation

### KEYWORDS

Culture, Polymerase chain reaction, Serotype, Antimicrobial Susceptibility testing patterns, Rapid Diagnostic Test, transport media

### 4.0 Useful Information

- i. The gold standard test for laboratory confirmation of Vibrio Cholera is by stool culture.

- ii. Stool Polymerase Chain Reaction (PCR) is also a diagnostic and confirmatory test.

- iii. Culture allows isolation of the V. cholera organisms from stool samples, determination of the serotype and ascertaining antimicrobial sensitivity patterns.

- iv. Cholera Rapid Diagnostic Test (RDT) is a screening test and is recommended for initial detection of V. cholera, before culture method.

- v. The advance distribution of sample collection materials, Cholera RDTs, transport media, and rectal swabs in areas that

<!-- Source PDF page 39 -->

are prone to cholera outbreaks is paramount during preparedness.

   - vi. Declaration of cholera outbreaks is done on the basis of laboratory confirmation and not following positive screening tests by RDTs.

   - vii. The end of a cholera outbreak is declared fourteen (14) days after the last positive stool sample by culture or PCR.

### 4.1 Laboratory functions in cholera outbreak investigation

Below are the laboratory functions during cholera outbreak investigations;

- Preparation and preposition of transport media and other supplies during the outbreak

- Specimen collection

- Completing standard laboratory investigation form ( **Annex 5)**

- Shipment of specimens to relevant laboratories

- Specimen screening using RDTs and other preliminary tests.

- Culture and drug sensitivity

- Serology and genotyping

- Timely communication of results to clinicians

### 4.2 Type of Laboratory Sample

There are two major types of samples collected during the cholera outbreak investigation.

#### 4.2.1 Clinical samples

These are samples collected from suspected cholera cases

- a) Watery Stools from patients

- b) Rectal swabs from very ill patients / children / community deaths.

**Note:** Stool specimens must be taken from ALL cases that meet the suspect case definition.

<!-- Source PDF page 40 -->

#### 4.2.2 Environmental samples

These are samples collected to assess possible sources of infection from the environment.

   - a) Water

   - b) Food and beverages

   - c) Waste water

### 4.3 Procedure for Clinical Sample Collection

#### 4.3.1 Fresh stool samples

   1. Collecting fresh stool is very important

   2. Directly collect the watery stool into a clean sterile dry stool container.

   3. Then inoculate in Cary Blair or 1% Alkaline Peptone Water (APW); incubate for 6 hours and transport at room temperature to the testing laboratory.

   4. In the absence of APW, place the stool in a sterile plastic bag with absorbent materials and transport the stool sample to the testing laboratory in a cool box.

   5. Label the samples with the patient’s name or number, date, and time of collection. The collected stool sample should be transported to the testing laboratory immediately (within 2 hours) under cold chain. If any delay is anticipated, the sample should be kept in the Carry-Blair transport media.

#### 4.3.2 Rectal swabs

Rectal swabs should be collected from all suspected cholera cases where fresh stool is impossible. All suspected cholera deaths should have a rectal swab taken for cholera confirmation.  Follow the procedure below:

1. Moisten a sterile swab in sterile physiological saline.

<!-- Source PDF page 41 -->

2. Insert the swab 2-3 cm through the rectal sphincter and rotate once.

   3. Withdraw the swab and examine to make sure it carries visible faecal material.

   4. Immediately insert the swab into Cary-Blair transport media, pushing it right to the bottom of the tube.

   5. Break off and discard the top of the swab stick touching the fingers.

   6. Label the container with the patient's name, collection date, and time.

   7. Dispatch the sample immediately to the testing laboratory.

#### 4.3.3 Viability of transport media

   - Cary-Blair transport medium or Alkaline Peptone Water (APW) allows better conservation of samples. It is not necessary to refrigerate the sample

   - Tubes of Cary-Blair transport medium can be stored at ambient temperature for 1–2 years.

#### 4.3.4 Testing specimens for specific DNA detection by PCR

   1. Place a drop of liquid stool on a dry filter paper and allow it to air dry.

   2. Once dry, place the filter paper in a screw-cap micro tube and store it at room temperature.

   3. Do not add normal saline to the micro tube.

   4. All specimens should be sent to the laboratory accompanied by a request form. (Annex 5)

   5. Maintain specimens at ambient temperature at all times. Do not refrigerate specimens, as refrigeration can greatly decrease the population of V. cholera.

   6. Do not allow specimens to dry (unless sending on dry filter paper for PCR). Add additional drops of normal saline solution if necessary.

<!-- Source PDF page 42 -->

7. Transport in a well-marked, leak-proof container at ambient temperature.

   8. Ensure that each specimen and container is properly identified/labeled.

#### 4.3.5 Referral and transportation of samples using the hub system

Ensure the following are observed:

   1. All samples from cholera suspects should be triple packaged and immediately transported to laboratories using the existing operational national specimen referral and transport network system.

   2. Notify the reference laboratory in advance (Regional Laboratory, Central Public Health Laboratories (CPHL).

   3. Ensure that the laboratory Case Investigation Form (CIF) is properly filled.

   4. Ensure that the right ADDRESS “To and From” on the outer box is clearly written/labeled.

   5. Submit the sample to the nearest Regional Referral Hospital laboratory with capacity to perform culture and sensitivity or directly to the central public health laboratories (CPHL), located on Plot No: 106 1062 Butabika Luzira Road, opposite Butabika National Referral Hospital.

   6. Notify District surveillance focal person (DSFP), District laboratory focal person (DLFP), Regional laboratory manager and CPHL on: **0800221100 – toll free (or Tel +256-414230265) or PHEOC on 0800203033 –toll free**

   7. E-mail: unhlsmicrobiologylab@gmail.com

#### 4.3.6 Reporting of laboratory results

Testing laboratories should; -

1. Maintain an updated database with all samples received and tested and the test results.

<!-- Source PDF page 43 -->

2. Send results immediately after completion of testing through the Result Dispatch System (RDS) and the health facility where the patient was admitted, with identifying information.

3. Upon receipt of the test results, the health workers should update the epidemiological information (registers, line list, and the situation report).

**Note:** Cases that test Negative by culture or PCR should be deleted from the line list even if they had tested RDT positive.

### 4.4 Factors that may affect the quality of laboratory tests

It’s important that proper precautions are taken to ensure quality test results. However, the following factors can affect the quality of test results;

- Improper stool sample collection procedure such as sample collected from patient bed, floor, and bucket, among others.

- Sample swab inserted in dried out transport media.

- Chemicals like JIK

- Sample collection following initiation of antibiotics.

- Availability, selection, and use of transport media.

- Time delays between sample collection and submission.

- Incompetent staff

- Leaking stool samples. It is important to tighten the cap completely before shipping stool samples.

- Specimens submitted in fixative or other additives.

- Breakages in the cold chain system

### 4.5 Collection and Storage of Cholera Isolates

All cholera culture isolates and the dry-spots from RRH laboratory or any other facility with capacity for culture and sensitivity should be sent to CPHL national microbiology reference laboratory for confirmation and quality control, phenol-typing, genotyping, biobanking, biosafety and biosecurity management.

<!-- Source PDF page 44 -->

### 4.6 Testing for Vibrio Cholera with RDTs (Screening test)

To test for cholera using RDTs, follow the steps below:

1. Incubate fresh stool sample (2 drops) or rectal swab in 1% Alkaline Peptone Water (APW) for 6 hours.

2. Suck 4 drops of APW into a test-tube and keep the test-tube in vertical position.

3. Read the manufacturer's instructions on the RDT test strips.

4. Insert one RDT test strip into a test-tube with 1% APW in vertical position.

5. Read the results after 10-15 minutes but not beyond 15 minutes. 6. Interpret test results as negative, positive for O1, positive for O1 and O139, positive for O139 or invalid as indicated in Figure 5.

![Source illustration — PDF page 44](images/illustration-044-012.png)

#### Figure 5. Interpretation of RDT test

<!-- Source PDF page 45 -->

#### 4.6.1 Summary of testing with RDTs

![Source illustration — PDF page 45](images/illustration-045-013.png)

**Figure 6. Cholera RDT testing procedure for stool swabs**

### 4.7 Laboratory Confirmation by culture

This is the gold standard method for confirmation of V. Cholerae and is the basis for cholera outbreak declaration.

- Stool samples must be collected from all cases meeting the standard case definition for suspected cholera cases according to laboratory guidelines and the current national cholera elimination strategy.

- V. cholerae isolation is done by standard laboratory method for Vibrio Cholerae.

- During testing, it’s important to monitor antimicrobial sensitivity patterns.

<!-- Source PDF page 46 -->

- The chart below is a summary of the steps in laboratory confirmation of vibrio cholerae.

- Usually, the culture result is received within 24-48 hours of incubation.

![Source illustration — PDF page 46](images/illustration-046-014.png)

**Figure 7.  Steps in laboratory confirmation of cholera Outbreak**

<!-- Source PDF page 47 -->

#### ASSESSMENT OF THE OUTBREAK RESPONSE

- 1) How was the diagnosis confirmed?

- 2) Through culture or PCR?

- 3) How are the samples packaged, stored, and transported?

- 4) Was transport media readily available

- 5) Was an up-to-date Inventory for laboratory logistics available?

   - a. Stool containers

   - b. Rectal swabs

   - c. RDTs

- 6) In the case of laboratory confirmation, were the collection and transportation of samples adequate?

- 7) Did the laboratory use enrichment techniques for the culture of Vibrio cholerae?

- 8) How long did the laboratory take to provide confirmation?

- 9) How many samples were collected?

- 10) What proportion of samples was positive?

- 11) How were the results communicated?

- 12) What was the turnaround time (from collection of samples to receipt of results)?

<!-- Source PDF page 48 -->

## CHAPTER FIVE: COORDINATION OF OUTBREAK RESPONSE

<!-- Start of picture text -->
District cholera task force <!-- End of picture text -->

![Source illustration — PDF page 48](images/illustration-048-015.png)

**_Picture 3: Kayunga district cholera task force meeting, 2023_**

### KEYWORDS

Coordination, Cholera Task Force, Coordination Levels, Public Health Emergency Operations Centre

### 5.0 Useful Information

Prevention, Preparedness, control and elimination of cholera requires a multi-sectoral approach.

Active participation is critical for the key actors i.e. Local Governments, the Ministries of Water and Environment, Ministry of Health etc.

<!-- Source PDF page 49 -->

Development and implementing partners, CSOs, NGOs should actively support multi-sectoral interventions by the key sectors.

Good leadership for the different actors is pivotal in fostering effective multi-sectoral coordination in order to ensure successful implementation of prevention, preparedness, and response activities. **5.1 Multi-sectoral coordination of preparedness and response to cholera outbreaks**

Analysis of gaps and barriers to instituting effective integrated and coordinated response to cholera, has demonstrated a lack of clarity of leadership, accountability, unclear roles and responsibilities and the multiplicity of coordination mechanisms. This has led to confusion, duplication, gaps, delays and response decision-making made far from cholera outbreaks. There is need for strengthening of coordination of the inter-sectoral response so as to more efficiently and effectively respond to, contain and potentially prevent, cholera outbreaks.

WHO and UNICEF have developed strategies, in the form of a Joint Operational Framework (JOF), to improve the coordinated and integrated preparedness and response to cholera within countries.

The JOF promotes a set of key tasks in the critical areas of leadership, coordination, and integrated response to increase the efficiency and effectiveness of the cholera preparedness and response efforts. This is through building the national public health capacity to assess, plan, coordinate and implement preparedness and response measures.

<!-- Source PDF page 50 -->

![Source illustration — PDF page 50](images/illustration-050-016.png)

#### Figure 8: Multi-sectoral operational framework

**Note** : All steps need to be active.

### 5.2 Structure of the emergency preparedness and response coordination in Uganda

Overall coordination for disaster preparedness and response including epidemics in the country lies with the Office of the Prime Minister. However, the Ministry of Health is the Lead Ministry in epidemic disease response.

Coordination of cholera outbreaks is mainly at district level. Regional PHEOCs support the coordination of cholera preparedness and response.

Based on the magnitude of the outbreak, coordination of the outbreak may be escalated to the National level. At both levels, coordination is mainly done through the District and/ or National Task Forces.

<!-- Source PDF page 51 -->

![Source illustration — PDF page 51](images/illustration-051-017.png)

**Figure 9:  Coordination structure for Emergency Preparedness and response**

A Cholera Task Force should be in place at district level. Depending on the magnitude of the outbreak, the National Task Force (NTF) may also be activated to support in coordination of the response. The Task Force coordinates and oversees all activities during a cholera outbreak response, identifies challenges and mobilizes resources to address those challenges.

Following confirmation of cholera case(s), the DTF should meet frequently (at least once or twice a week, and even daily in the initial phases) until the outbreak is contained.

The DTF should ensure linkage with the national level through timely information sharing through publishing and distributing daily situation reports that cover indicators on surveillance and epidemiology, WASH, Risk Communication and Community Engagement, logistics and case management.

<!-- Source PDF page 52 -->

### 5.3 Composition of Cholera Task Forces

#### 5.3.1 Composition of the National Cholera Task Force (NCTF)

- The overall coordination of cholera response in Uganda is vested in the NTF chaired by the Director General Health Services (DGHS), Ministry of Health. Membership shall include:

- Pillar leads (Coordination, Case management & Infection Prevention & Control, Surveillance & Laboratory, Risk Communication & Community Engagement, WASH)

- Other line Ministries especially Office of the Prime Minister, Ministry of Water and Environment, Ministry of Finance, Planning & Economic Development, Ministry of Local Government, Ministry of Education & Sports, Ministry of Internal affairs, Ministry of Defense and veteran affairs and other related agencies and departments.

- Heads of relevant institutions

- Partners (Development and Implementing Partners)

- Civil society organizations

##### Table 1: Roles and responsibilities of stakeholders

|**Stakeholders**|**Roles/ Responsibilities**|
|---|---|
|Ministry of Health|The lead sector and secretariat for the cholera prevention and elimination. Set policy directions and standards during. Implementation of the elimination plan. Monitoring implementation of water, sanitation and hygiene activities through the department of Environmental Health. Resource mobilization and capacitybuilding.|
|Office of Prime Minister (OPM)|OPM is the leader of government business. OPM receives reports from the lead sector (MOH) and shares them with the cabinet. OPM is responsible for coordinating inter- ministerial meetings, coordination of provision of social services(safe water,sanitation,hygiene|

<!-- Source PDF page 53 -->

|**Stakeholders**|**Roles/ Responsibilities**|
|---|---|
||etc) for general and hot-spot populations, refugees and internally displaced persons to prevent cholera outbreaks in these communities.|
|Ministry of water and Environment|Provision of adequate affordable safe water and sanitation in public places. Monitoring of community water sources to ensure good quality. Design and promotion of appropriate sanitary facilities in high risk areas with environmental difficulties.|
|Ministry of Education and Sports|Promotion of cholera and other water borne diseases prevention and control in learning institutions to ensure adequate latrines, hand washing facilities and safe water supply. Health education of learners on how to prevent cholera so as to cause change in the community where they live. Reporting of suspected cholera outbreaks to nearby health facility, and ensure there is a focal person for health at all schools.|
|UN Agencies (WHO, UNICEF, UNHCR)|Provide technical, financial and logistical support for cholera prevention and elimination interventions.|
|Ministry of Local Government|Provide supervision of local governments to ensure leadership for implementation and monitoring of interventions. Providepolicy guidance for localgovernments.|
|Local governments (Districts, Urban Authorities, Kampala Capital City Authority (KCCA), Cities and Municipalities)|Service delivery /implementation of the interventions for Cholera elimination. Enact and enforce public health regulations, ordinances and bye-laws for prevention and control of Cholera. Provision and maintenance of sanitary facilities in public places e.g. markets, parks, landing sites and learning institutions. Provision and maintenance of safe water to the public/communities.|

<!-- Source PDF page 54 -->

|**Stakeholders**|**Roles/ Responsibilities**|
|---|---|
|Ministry of Agricultural, Animal industry and Fisheries/ Beach Management Units|In collaboration with local authorities ensure that landing sites have sanitary and hand washing facilities. Work with NEMA and Local governments to ensure that sanitary facilities at beaches are located away from the lake shores. Provide sanitary and hygiene facilities at all landing sites and agricultural institutes in collaboration with localgovernments.|
|International and local NGOs [AFENET, MSF, Uganda Water and Sanitation NGO network (UWASNET), World vision, Oxfam, MTI, IRC, PATH, and others]|Support government in planning, implementation and monitoring of priority interventions for cholera elimination. Resource mobilization for planned priority interventions.|
|Private sector, Medical bureaus/Associatio ns|Advocacy and support for implementation of prevention and control measures within their jurisdiction, capacity building, and resource mobilization.|
|Communities|Responsible for their health and ensure adequate sanitation and hygiene. Promote healthy lifestyles. Reporting of suspected cases to the relevant authorities.|
|Other Ministries (Internal Affairs, Security, Defense and Gender, Labour and Social Development)|Coordinate the implementation of the cholera prevention and elimination interventions in institutions under their jurisdictions e.g. prisons, police, Uganda Peoples Defense Force (UPDF) and remand homes.|

![Source illustration — PDF page 54](images/illustration-054-018.png)

<!-- Source PDF page 55 -->

|**Stakeholders**|**Roles/ Responsibilities**|
|---|---|
|Ministry of Finance, Planning and Economic Development|Resource mobilization and allocation towards cholera prevention and control.|
|East African Community (EAC)|Support joint planning and coordination of cross- border choleraprevention interventions|
|Teaching institutions and academia (Makerere University, Mbarara University, etc.)|Ensure promotion of health life styles in their areas of jurisdiction. Support and carry out research for evidence- based planning and implementation. Generate cost effective innovations aimed at cholera elimination.|
|Bilateral and Multilateral donor partnerships (CDC, GAVI)|Provide technical, funding and logistical support for the implementation of the planned cholera prevention and control interventions.|
|Heads of Special Institutions e.g. learning institutions, prisons, police, UPDF and Mental Facilities|Implementation of cholera prevention and elimination interventions in the respective institutions.|
|Ministry of ICT and Media institutions|Mobilization and dissemination of timely information on cholera prevention and elimination to raise awareness among communities.|

![Source illustration — PDF page 55](images/illustration-055-019.png)

#### 5.3.2 Composition of the District /City Cholera Task Force

The team members must include the following:

- Resident District/City Commissioner (Chairperson of the meetings)

- Assistant Resident District/City Commissioner (Co-Chairperson of the meetings)

- Chief Administrative Officer

<!-- Source PDF page 56 -->

- District Chairperson (LCV) / Town Clerk/ City Clerk

   - District Health Officer/ City Medical Officer (Secretary)

   - Assistant District Health Officer- Environmental health

   - Assistant District Health Officer- Maternal and Child health

   - Medical superintendents for all hospitals or Health Center Four for districts without hospitals

   - In charge of health facilities with the outbreak

   - District Health Educator

   - District Surveillance Focal Person

   - District Laboratory Focal Person

   - Head(s) of Health Sub-District (s)

   - Community Development Officer

   - District Water Officer

   - District Education Officer

   - District Engineer

   - Mayors and Town Clerks of Municipalities & Town Councils

   - Heads of Institutions such as Police, Prisons, Army etc

   - Religious leaders

   - Head(s) of Traditional and Complementary Medicine practitioners ❖ Partners (CBOs, NGOs, Implementing Partners, UN Agencies)

   - Business Community

### 5.4 Functions of the Cholera Task Forces

#### 5.4.1 Functions of the National Cholera Task Force

This is a multi-disciplinary and multi-sectoral Committee which should be present at national level. The committee provides strategic direction, monitoring of the outbreak response plan, and monitoring the implementation of activities. This committee has the following functions:

- Support the affected districts in outbreak investigation and risk assessments.

- Coordinate the development and approval of the cholera preparedness and response plans

<!-- Source PDF page 57 -->

- Ensure implementation of measures that prevent and control cholera outbreaks.

   - Provide health-care professionals with approved case management and IPC protocols.

   - Procure and distribute necessary supplies in a timely manner to avoid any shortages.

   - Mobilize resources for implementation of prevention and control measures (human resources, logistics, financial and security).

   - Map partners for cholera preparedness & response and develop a 4W matrix.

   - Hold regular coordination meetings with stakeholders and partners.

   - Ensure adherence to the set standards and best practices for cholera prevention and XZ.

   - Update, translate and disseminate Information, Education and Communication (IEC) materials adapted to the context of the outbreak.

   - Guide on the platforms for sharing cholera outbreak information with the public.

   - Guide on the procurement and deployment of Oral Cholera Vaccines (OCV).

   - Supervision, monitoring and evaluation for cholera preparedness and response.

#### 5.4.2 Functions of the District/City Cholera Task Force

   - All districts/cities that record confirmed cholera case(s) must have a multi-sectoral and multi-disciplinary District/City Cholera Task Force (CTF) or Committee that is responsible for the overall coordination of the cholera preparedness and outbreak response.

   - The District/City CTF should link with the NTF during the entire period of the outbreak response.

<!-- Source PDF page 58 -->

- The task force should have sub-committees focusing on priority interventions. The common sub-committees and their heads are in **Annex 6.**

- The DTF provides rapid and efficient development, execution and monitoring of the outbreak response plan. This committee has the following functions:

- Estimate the potential amplitude of the outbreak and the expected number of cases based on risk assessment and available epidemiological data. Identify priority areas for all interventions.

- Identify human resources and supplies available and those that are needed.

- Develop or update a multisectoral cholera response plan as rapidly as possible.

- Coordinate all partners involved in the response to avoid duplication and overlaps, and to maximize overall response, efficiency and effectiveness.

- Identify and functionalize the cholera treatment units at existing facilities close to the source of the outbreak.

- Develop daily situation reports and share with the National PHOEC until the outbreak is contained.

- Organize regular briefings and meetings and provide concise and updated information on progress of the outbreak.

- Organize relevant trainings in surveillance, case management, laboratory sampling, chlorine solution preparation, infection prevention and control (IPC) measures and other topics as needed. Ensure that these trainings are conducted in an integrated manner.

- Mobilize, train, and equip community focal points (for example, Village Health Teams, local leaders, village chiefs, heads of households for health promotion messaging, rapid case detection, dehydration management at home with ORS and treatment-seeking behavior.

<!-- Source PDF page 59 -->

- Liaise with key stakeholders to ensure provision and access to sufficient quantities of safe water and sanitation in all affected areas.

- In the event that OCV is indicated, conduct micro-planning, coordinate and implement OCV campaigns.

- Supervise, monitor and evaluate control activities and interventions implemented.

- Implement post-outbreak activities following the end of an outbreak in consultation with Ministry of Health.

- Compile end of outbreak report following declaration of the end of the outbreak.

![Source illustration — PDF page 59](images/illustration-059-020.png)

**_Picture 4: Butaleja District 2016, Hon. Minister of Health, Dr. Jane Ruth Aceng (standing) communicating the required cholera preventive and control measures to the local leaders in the district._**

### 5.5 Cholera Preparedness and Response Plan

During the preparedness phase, districts should develop/ update their cholera contingency plans and ensure implementation of key activities aimed at preventing cholera outbreaks or mitigating the effects in the event of an outbreak **(Annex 7).**

<!-- Source PDF page 60 -->

Upon confirmation of cholera cases within the district, the District Cholera Task Force should develop/update an integrated and multisectoral response plan based on risk and needs assessments within a week of confirmation of cholera cases. The 3-6 months long response plan should have interventions with clear activities and indicators for monitoring and evaluation. Each of the activities should be costed and the overall cost of implementing the plan indicated clearly.

The following interventions should be prioritized;

- **Surveillance and Laboratory:** Strengthen early warning system for timely detection of cases, ensure availability of laboratory supplies, follow up of cases and reporting, contact tracing for health education and selective chemoprophylaxis, among others.

- **WASH:** availability of water treatment reagents, inspection of homes, public and eating places, schools, protection of water sources, promotion of hand washing, enforcement of latrine construction and use, among others.

- **Case management and Infection Prevention and Control** : Availability of essential medical supplies, CTU requirements, transport and ambulance support, food for the patients among others.

- **Risk Communication and Community Engagement:** Health promotion, engagements with local leaders, community members, dissemination of IEC materials, radio messages among others.

- **Coordination:** Regular coordination meetings by the Cholera Task Force, supervision and monitoring of interventions, partner mapping, resource mobilization, among others.

- **Cholera vaccination:** Plan for micro-planning if vaccination is indicated.

### 5.6 Coordination of supplies required for Cholera control

Effective care depends on the availability of supplies and equipment in adequate quantities. The supply system must ensure that rehydration

<!-- Source PDF page 61 -->

fluids, antibiotics, and other supplies are ready when needed. Supplies for responding to cholera alerts and outbreaks are part of the essential medicines list which are routinely ordered or sent to the health facilities by the National Medical Stores.

In the event of a cholera outbreak, districts are advised to redistribute the available supplies within the district for response. If there is need for additional supplies, emergency orders are made to NMS through the Director General of Health Services.

To avoid overstocking or under stocking of supplies and misuse of resources, it is important to estimate the expected number of cholera cases and when they can be expected.

Upon declaration of the end of the outbreak, the remaining reusable supplies such as cholera beds, oral cholera vaccines, cholera RDTs among others should be kept as part of the district inventory for later use or redistribution.

The list of supplies needed for treating cases, contacts and setting up emergency treatment facilities is shown in **Annex 8** .

### 5.7 Public Health Emergency Operations Centers

The Public Health Emergency Operation Center (PHEOC) serves as the center for coordinating information and resources for public health threats at national and subnational level. The PHEOC also provides a communications hub between the key stakeholders for receiving, verifying, analyzing and disseminating information.

Currently thirteen (13) Regional PHEOCs (RPHEOCs) are present in different regions of the country and these are coordinated by the National PHEOC (NPHEOC) at the Ministry of Health.

<!-- Source PDF page 62 -->

The Regional PHEOCs are situated at Regional Referral Hospitals, under the Public Health Department. In the event of a cholera outbreak, the REOCs provide technical support and oversight to the affected district(s) under their jurisdiction to ensure timely containment of the outbreak.

Notably, the district leadership has the overall mandate of coordination of the response the outbreak and the RPHEOC only plays a supportive role.

### 5.8 Cross border coordination for cholera prevention and control

The country faces challenges in prevention, detection and response to cholera outbreaks in districts that are situated along the borders. This is due to the constant, and often uncontrolled movement of people in and out of the country, mostly through unofficial border points, and yet the risk of cholera is higher amongst countries sharing borders with Uganda.

Rapid detection and early response to cross-border cholera spread involves interventions aimed at strengthening routine capacities at the Points of Entry for prevention, detection and control of cholera outbreaks. These include screening of travelers to detect suspect cases, isolation, rapid diagnostic testing, reporting and prompt referral to care.

Ensuring strong collaboration through joint planning, implementation and information sharing is key to prevention of cross border cholera spread.

The officials in high-risk border districts should maintain close communication with those on the other side of the border by utilizing the existing cross border surveillance zones, through the different platforms including routine cross-border meetings, joint social media platforms among others.

<!-- Source PDF page 63 -->

### 5.9 Monitoring and Evaluation of Cholera Response

Routine monitoring and evaluation of the outbreak response is done during field activities and the task force meetings. However, specific action reviews should as well be carried out so as to identify immediate and longer-term corrective actions for future responses. These include Early Action Review, Intra- Action Review and After-Action Review.

#### 5.9.1 Early Action Review

An Early Action Review (EAR) is a rapid performance improvement approach for evaluation of the timeliness of detection, notification and responses for any public health event. EAR assesses country or district timeliness performance, identifies the factors responsible for systematic delays and use this information to support rapid performance improvement, communication, resource allocation during planning and targeted advocacy for further financing.

The WHO recommends that EAR, which is premised on 7-1-7 targets, is defined as 7 days to detect, 1 day to notify the next level of the health system, and 7 days to complete early response actions. The EAR provides a platform to learn from every public health event and utilizes information to improve workflows and actions.

EAR promotes collaboration and coordination among stakeholders in the first week of the response following PHE notification increasing likelihood of effective control.

#### 5.9.2 Intra-Action Review

Intra-Action Reviews (IARs) are a facilitated process that brings together key stakeholders with knowledge of the public health response pillars to discuss success and challenges to make recommendations for improvements in response. Cholera IARs are

<!-- Source PDF page 64 -->

crucial opportunities for countries to learn and improve their responses to protracted cholera outbreaks.

IARs enable the district to make immediate changes to improve the ongoing response or to institutionalize actions into the overall preparedness and response strategies to limit the morbidity and mortality.

#### 5.9.3 After Action Review

It is a participatory, qualitative review conducted within the first three (3) months after the declaration of the end of an outbreak to analyze how well the outbreak was responded to.  All pillars are assessed differently using structured questions to inform the review.

The review informs the coordination team of the best practices and gaps identified during the response and suggests solutions for improved preparedness and a better response in the event of another cholera outbreak.

### 5.10 Post-outbreak continuity of Cholera Prevention and Preparedness

Following the declaration of the end of the cholera outbreak, the district coordination structures shall ensure continuity in implementation of activities aimed at building resilience against another outbreak. These are routine preparedness interventions implemented to prevent re-occurrence of cholera or to mitigate its effects once it occurs.

These interventions are targeted towards addressing the risk factors for Cholera and early detection of cholera cases. These include;

- Continuous health promotion and education at the community level.

<!-- Source PDF page 65 -->

- Strengthening surveillance systems at all levels including community-based surveillance.

- Training of health workers and conducting simulation exercises on cholera preparedness and response.

- Cross border engagements for joint planning and implementation.

- Updating cholera operational guidelines to inform planning and policy.

#### 5.10.1 Training of Health Workers

The quality of care for the patients with cholera depends on the knowledge, skills and the right attitude of health personnel. The training of a health staff can be achieved in many ways that include:

- Continuous Medical Education (CME) which can be done at the health facility

- Job aids

- Regular supervisory visits that reinforce and upgrade what has been learned

- For clinical tasks, supervised hands–on management of patients (mentorship) is usually considered to be indispensable

- Simulation exercises and clinical courses

The training should emphasize the following:

- Detection of cholera cases using the standard case definitions.

- Sample collection, sample management and cholera rapid diagnostic testing.

- Case management of cholera and its complications including the use of Oral Rehydration Therapy.

- Infection Prevention and Control

- Management of cholera among vulnerable groups (pregnant mothers, chronic illnesses, among others).

- Management of cholera dead

- Water Sanitation and Hygiene

- Surveillance and Data utilization for decision making.

<!-- Source PDF page 66 -->

In addition to training, it is important to ensure that all health workers always have access to Ministry of Health standard treatment guidelines on cholera.

##### Training of Health workers on a cholera

![Source illustration — PDF page 66](images/illustration-066-021.png)

![Source illustration — PDF page 66](images/illustration-066-022.png)

**_Picture 5: Orientation of health workers of Kayunga District and Kayunga_** **_RRH on cholera_**

### 5.11 Documentation of the End of Cholera Outbreak

A summary report on outbreak interventions should be compiled and disseminated after the outbreak to the local stakeholders to provide feedback. This is important for training and planning appropriate future responses. An end of outbreak report format is **Annex 9** .

- The report should also be sent to MOH PHEOC.

- Evaluation of the response is important so as to ensure better future outbreak management.

<!-- Source PDF page 67 -->

#### ASSESSMENT OF THE OUTBREAK RESPONSE

- 1) Was there a Cholera Task Force to follow up the outbreak and take decisions? Was this committee multi-sectoral?

- 2) What was the timeliness of sending daily situational reports to MoH?

- 3) Was assistance provided to affected areas (supplies including laboratory supplies, technical and staff support)?

- 4) Were measures in ensuring Community participation in outbreak response?

- 5) Was there timely and adequate mobilisation of emergency supplies from national or donor sources?

- 6) How was the response monitored? Follow-up of the outbreak through regular epidemiological reports?

- 7) Who was the person designated to monitor and document control activities?

- 8) Was a cholera preparedness and response plan of action available?

- 9) Was there an easy information flow from the affected areas to the control level and vice versa?

- 10) What was the case fatality rate, attack rate (Facility based and community based) and duration of the outbreak?

- 11) What were the challenges experienced in the Control of the cholera epidemic?

- 12) Which measures will be taken to prevent outbreaks?

<!-- Source PDF page 68 -->

## CHAPTER SIX: CASE MANAGEMENT, SELECTIVE CHEMOPROPHYLAXIS, CHOLERA TREATMENT UNITS AND INFECTION PREVENTION AND CONTROL

### 6.0.1 Useful Information

Rapid access to rehydration therapy is the primary treatment for the full clinical spectrum of patients with cholera.

Patients with no signs of dehydration are treated with oral rehydration solution (ORS) at household level, in the community or in health care facilities. Oral rehydration points (ORPs) or VHTs are used to deliver ORS for initial management.

Patients with signs of some dehydration are treated with ORS and monitored closely at a cholera treatment facility.

Patients with severe dehydration require intravenous rehydration, antibiotics, and close monitoring at a cholera treatment facility.

All health care facilities that might manage cholera cases should have sufficient supplies that are able to cover the first few days before the arrival of more supplies.

These “pre-positioned” supplies should include both IV fluids and ORS, antibiotics, chlorine, giving sets, cannulas, adhesive plaster, Cary-Blair media, spray pump, gumboots, blankets, basins, buckets, gloves, aprons, body bags (polythene), biosafety boxes, hand-washing tanks, chlorine storage tanks, syringes and needles and disposal pits, refer to **Annex 8** for supplies requisitions.

Emergency supply needs should be evaluated in the light of the particular situation. The attack rates below are useful in estimating the new cholera cases during an epidemic.

❖ In open settings, an attack rate of 0.2% might be used

<!-- Source PDF page 69 -->

- In rural communities of 5,000 people or less, the attack rate might reach 2%

- Likely attack rate in IDP or refugee camps, with high-risk populations (because of malnutrition), is 5.0–8.0%.

A needs assessment and inventory of supplies should be completed before any anticipated cholera outbreak.  In addition, the health professionals need specific training for effective and efficient management of cholera cases and deaths. The district and MOH should develop a training micro-plan to achieve a target of 90% of all the health care workers trained.

#### 6.0.2 Priority Interventions

- Set up decentralized cholera treatment facilities (CTUs/CTCs) and oral rehydration points (ORPs) for rapid access to treatment.

- Distribute ORS in the community and to households. Explain how to prepare and administer the ORS.

- Employ early detection, triage and transfer of severe cases for IV fluid treatment.

- Train health professionals using standard case management protocols and IPC measures.

- Distribute validated treatment protocols to health facilities and CTUs/ CTCs.

- Estimate supplies; procure and distribute needed supplies to avoid any shortage.

- Inform the public about what people should do if someone is ill with diarrhea; include instructions about rehydration with ORS at home or on the way to a treatment facility and how and where to seek immediate treatment.

<!-- Source PDF page 70 -->

### 6.1 Case management and Selected Chemoprophylaxis

#### KEYWORDS

Assessment of the Patient, Rehydration, Treatment, Selective Chemoprophylaxis, Mass chemoprophylaxis and Health Education

#### 6.1.0 Useful Information

Without treatment, cholera can kill up to 50% of patients with severe disease. Timely and appropriate treatment significantly reduces the risk of death.

Although the benchmark for cholera treatment is a Case Fatality Rate (CFR) of less than 1.0 %, deaths from dehydration from cholera should not occur.

Timely prevention and treatment of dehydration is the basis of good cholera case management.

Approximately 80% of people infected with cholera do not develop symptoms of the disease; these individuals can still transmit the disease by shedding V. cholerae bacteria in the environment. Bacteria are present in their faeces for up to 14 days after infection.

Selective chemoprophylaxis, with recommended antibiotics, has a role in limiting transmission of the infection to other community members in immediate contact with the patient(s).

#### 6.1.1 Priority Interventions

_Management of Cholera Patients_

The steps in management of a cholera patient are:

STEP 1: Assess for dehydration

STEP 2: Rehydrate and monitor frequently

STEP 3: Maintain hydration: replace ongoing fluid losses until diarrhea stops

STEP 4: Give oral antibiotics to all cholera patients

<!-- Source PDF page 71 -->

STEP 5: Give Zinc Tablets to All Under-Five Year Old with Cholera Step 6: Feed The Patient STEP 7: Health educate and counsel the patients, attendants and

the family **6.1.1.1 Assessment and Classification of patients**

Cholera patients can be assessed for dehydration and grouped as in **table 2**

**Table 2: Assessment and Classification of Cholera Patients**

|**Degree of** **Dehydration**|**No** **dehydration**|**Some** **Dehydration**|**Severe dehydration**|
|---|---|---|---|
|1.  Observe: a. General condition|Well, alert|Restless, Irritable Fluid loss less than 10% of body weight|Lethargic or Unconscious / floppy Fluid loss more than 10% of body weight. Pulse: barely detectable.|
|b. Eyes|Normal|Sunken|Very sunken and dry|
|c. Tears|Present|Absent|Absent|
|d. Mouth and tongue|Moist|Dry|Very dry|
|e. Thirst|Not thirsty, drinks normally|Thirsty, drinks Eagerly|Drinks poorly or not able to drink|
|2. Skin pinch|Skin pinch Goes back quickly|Goes back slowly (within 2 seconds) Care must be taken for the elderly persons|Goes back very slowly (more than 2 seconds) Care must be taken for the elderly persons|

<!-- Source PDF page 72 -->

|3. Decide|No sign of dehydration:  **Plan A** Treat as Outpatient/ No admission, give appropriate antibiotics|The patient has two or more signs including at least one bold sign: **Plan B** Admit to CTU|The patient has two or more signs including at least one bold sign: **Plan C** Admit to CTU|
|---|---|---|---|
|4. Treatment|Give ORS Give recommended antibiotics Give zinc to children under 5 years Health Education and counselling Observe for 4 hours then discharge on ORS and the antibiotics|Admit to CTU Give ORS Give recommended antibiotics Give zinc to children under 5 years Routinely monitor as per the chart Continue feeding|Admit to CTU Give IV therapy Give recommended antibiotics Give zinc to children under 5 years Give ORS as soon as able to drink Routinely monitor as per the chart Continue feeding|

**Note:** All patients with severe dehydration should be assessed for signs of shock which include; Thin and thready pulse, cold peripheries, prolonged capillary refill.

<!-- Source PDF page 73 -->

##### 6.1.1.2 Rehydration

- Rehydration with replacement of fluids/electrolytes lost is the basis of cholera treatment. Cholera Patients are managed according to the degree of dehydration using Plans of A, B, & C.

- Rehydration therapies include Oral rehydration solution (ORS) and intravenous fluids namely Ringers lactate or Hartmann solution.

- Resomal solution is used for the malnourished children.

- Monitoring or observation of patients is crucial in all treatment plans. It should be done frequently (every 30 minutes) and reclassification done. Findings should be recorded on the standard monitoring form for cholera patients Annex 10.

- Note: 0.9% Normal saline or 5% Dextrose are not recommended for correction of dehydration due to cholera. Dextrose 50% is used to correct hypoglycemia.

###### 6.1.1.2.1 No Dehydration: Treatment A

- The patient should be observed and health educated then discharged home on recommended antibiotics, zinc tablets for children below 5 years of age and Oral Rehydration Salt (ORS).

- The use of homemade safe fluid preparations such as fruit juices, porridge, yoghurt, milk and other fluids are encouraged.

<!-- Source PDF page 74 -->

###### Good patient care to promote quick recovery

![Source illustration — PDF page 74](images/illustration-074-023.png)

![Source illustration — PDF page 74](images/illustration-074-024.png)

**_Picture 6: Kayunga district, Namusaala CTU assessment (2023) and Namatala HC_IV_** **_CTU, Mbale district (2015)_**

- Explain to the patients and attendants the three rules in treatment of cholera at home for Plan A as below:

   1. Give ORS or other fluids after every motion until diarrhea stops.

   2. Feed the child or patient

   3. Teach the patient and attendant when to come back to the health worker or bring back the child for example: Increased number of motions, the patient eats or drinks poorly, or if the general state of the patient worsens.

- Give patients enough ORS packets to complete rehydration, and for two (2) more days.

- Teach them how to prepare ORS solution, its administration and safe keeping.

- To mix ORS follow the instructions on the packet as below;

      - i. Add one sachet of ORS to one liter of safe/ boiled drinking water.

      - ii. Mix thoroughly, and start giving to the patient.

<!-- Source PDF page 75 -->

- iii. ORS should be prepared daily and should not be stored for more than 12 hours at room temperature, or up to 24 hours if refrigerated.

###### 6.1.1.2.2 Some Dehydration - Treatment Plan B

❖ A patient with moderate dehydration is managed with ORS.

❖ Give 75ml per kg of ORS within the first 4 hours and re-asses.

The table below shows approximate quantity of ORS solution to be administered in the course of the first 4 hours:

**Table 3: Rehydration protocol for Plan B**

|Age|<5 months|6—11 months|12-23 months|2-4 years|5-14 years|15+ years|
|---|---|---|---|---|---|---|
|Weight|<5kg|5-7kg|8-10kg|11-15kg|16-29kg|30+|
|ORS ml|200-400|400-600|600-800|800- 1200|1200-2200|2200-4000|
|Zinc tablet 20 mg(tab)|1/2 tab for 10 days|1 tab for 10 days|1 tab for 10 days|1 tab for 10 days|Not recomm|ended|

Maintenance of hydration status of a patient after intensive rehydration is important.

After correction of dehydration, manage the patients using plan A; give ORS and encourage the patient to drink extra fluids orally all the time. Administer the recommended antibiotics immediately.

###### 6.1.1.2.3 Severe Dehydration: Plan C (Intravenous Therapy for severe cases)

- Ringers lactate or Hartmann solutions are the preferred IV fluids. In case of lack of Ringers lactate, I.V Normal saline (0.9%) is used together with ORS solution (through NG Tube) to replace the missing electrolytes.

<!-- Source PDF page 76 -->

- Give I.V fluids immediately to replace lost fluids. If the patient can drink, give ORS by mouth simultaneously while the drip is being set up.

- **Note:** Plain glucose (5% Dextrose) solution is not effective in rehydrating cholera patients and is not recommended.

- When I.V rehydration is not possible and the patient cannot drink, ORS solution can be given by nasogastric tube.

However, nasogastric tubes should not be used for patients who are unconscious to avoid aspiration. Intraosseous access or venous cut down should be opted for.

The recommended amount of IV fluid therapy for different age groups and the time of administration are shown in the table 4 below:

**Table 4: Quantities of the recommended IV fluids for severe dehydration**

|Time and resp  Age|ective IV fluid(Rin First 1hr|ger lactate) Next 5 hrs|Total in 6hrs|
|---|---|---|---|
|Less than 1 year|30 ml/kg|70 ml/kg|100 ml/kg in 6 hrs|
|Time and resp|ective IV fluid(Rin|ger lactate)||
|Age|First 30 min|Next 2.5 hrs|Total in 3hrs|
|1 year and older|30 ml/kg|70 ml/kg|100 ml/kg in 3 hrs|

###### 6.1.1.2.4 Other considerations during rehydration and thereafter

- Give ORS solution (about 5 ml/kg per hour) as soon as the patient can drink, in addition to IV fluids.

- Reassess the patient after 3 hours (infants after 6 hours) following rehydration, using table 4 above.

<!-- Source PDF page 77 -->

- If there are still signs of severe dehydration, repeat the IV therapy once more.

- If there are signs of some dehydration, continue as indicated on some dehydration (Plan-B).

- If there are no signs of dehydration, maintain hydration by replacing continuing fluid losses.

- Maintain fluids equivalent to amount lost through vomiting and diarrhea is given to prevent further dehydration of the patient after intensive rehydration.

- Manage the patients using plan B; calculate amount per kg body weight, observe and monitor patient for 24 hours. If patient can take orally give ORS.

- Monitor the patient very frequently. After the initial 30 ml/kg have been given, the radial pulse should be strong and blood pressure should be normal: If the pulse is not yet strong, continue to give IV fluid rapidly. Record the vital observation using Annex 10.

- If the patient gets into shock, manage as described in the section of complications.

###### 6.1.1.2.5 Treatment of cholera in children with Severe Acute Malnutrition (SAM)

Malnourished children with cholera are at risk of complications and death.

- Refer children with SAM and suspected cholera for immediate treatment at a cholera treatment facility (CTU/CTC).

- Assessment of the child’s malnutrition status and dehydration level will determine the treatment plan.

- For oral rehydration of children with SAM during an outbreak of cholera, give standard ORS. Do not give Resomal (Rehydration Solution for Malnutrition).

- For severe dehydration requiring I.V therapy, follow rehydration guidelines for malnourished children.

<!-- Source PDF page 78 -->

- Rehydration of children with SAM must be closely monitored using the monitoring chart; there is a serious risk of overhydration and death from heart failure.

- Breastfeeding and feeding with therapeutic milk should continue throughout rehydration.

- Those with signs of severe dehydration but not in shock should not be rehydrated with IV fluids, because severe dehydration is difficult to diagnose in severe malnutrition and is often misdiagnosed. Consultation with a specialist (Pediatrician, Physician and nutritionist) should be made.

###### 6.1.1.2.6 Treatment of cholera in Pregnancy

Pregnant women with cholera are at much higher risk of losing their fetuses, compared to the general population of pregnant women. The risk of fetal loss depends on the degree of dehydration and vomiting, with more severe dehydration and the occurrence of vomiting increasing the risk of fetal loss.

Antibiotic treatment should be given to all pregnant women with cholera, regardless of the degree of dehydration. **_See antibiotic treatment below in section 5A.3._**

Dehydration can be difficult to assess in the later stages of pregnancy, resulting in an underestimate of the severity of dehydration. The degree of dehydration and treatment of pregnant women should be closely monitored to maintain rehydration and adequate systolic blood pressure to ensure appropriate uterine blood flow.

The use of OCV as a preventive measure is considered to be safe and is recommended in pregnancy (see section for oral cholera vaccine).

In large outbreaks, organize the CTCs/CTUs to ensure privacy for pregnant women, especially during labor and delivery, and ensure access to reproductive health services.

<!-- Source PDF page 79 -->

##### 6.1.1.3 Treatment with Antibiotics

Give oral Antibiotics to all patients including their attendants to reduce the duration of symptoms and spread of the pathogen.

Recommended antibiotics are given based on culture and sensitivity results.

Based on the ongoing microbial monitoring; the following antibiotics indicated in table 5 are recommended.

**Table 5: Recommended Antibiotics**

||**First-line**|**Alternative**|
|---|---|---|
|Adults|Doxycycline 300 mg p.o. single dose  or Tetracycline  500 mg four times daily for 3 days|Azithromycin 1g p.o. single dose  or ciprofloxacin 1g once for 3 days|
|Pregnant women|Doxycycline 300 mg p.o. single dose|Azithromycin 1g p.o. single dose  or ciprofloxacin 1g once for 3 days|
|||Azithromycin 20 mg/kg|
|Children < 12 years old|Doxycycline 2-4 mg/ kg p.o. single dose|(max 1g) p.o. single dose, or ciprofloxacin 20 mg/kg (max 1g) p.o. once for 3 days|

**Note:** If the patient vomits within 30 minutes of swallowing the antibiotics, administer another dose. For cases with severe dehydration cases, intravenous antibiotics are useful.

##### 6.1.1.4 Anti-diarrheal, metronidazole and anti-emetics

The following medicines are not recommended in management of cholera patients and MUST **NOT be administered:**

<!-- Source PDF page 80 -->

- Commonly used antibiotics such as Metronidazole

- Anti-emetics such as Largactil

- Anti-diarrheal such as Imodium

These medicines do mask the signs and complicate the illness which may lead to toxemia and death.

**Table 6: Recommendations about Zinc**

|Drug/Dosage| Children below 5 months|Children 6 months -5 years|Adults|Remarks|
|---|---|---|---|---|
|Zinc (20mg tablets)|10mg (½ a tablet) once daily for 10 days|20mg (full tablet) once daily for 10 days|Not recommended| Malnourished children on RUTF should not be given zinc tablets as the foods contain Zinc.|

##### 6.1.1.5 Monitoring of Patients with Severe Cholera

Monitoring and regular reassessment of patients for the following is crucial. The monitoring form **(Annex 10)** should be filled daily for every patient.  The following parameters should be monitored daily;

- Blood pressure

- Pulse

- Temperature (cholera usually results in hypothermia, if the temperature is higher than expected there might be another associated with pathology, e.g. malaria)

- Respiration

- Dehydration status

- Frequency and appearance of stools

- Ability to pass urine or not in 2 hours, continually observe the volume of urine passed.

- State of consciousness

<!-- Source PDF page 81 -->

- General condition of the patient for complications and other medical conditions.

##### 6.1.1.6 Common Treatment Complications

The commonly encountered complications can be corrected and prevented. Below are the common treatment complications;

**Table 7: Common treatment complications and how to prevent them from occurring**

|Complication (signs)|Cause|Corrective measure|Prevention|
|---|---|---|---|
|1. Pulmonary Oedema (difficulty in breathing, cough, basal crepitations)|Excessive IV fluid administration|Stop IV fluids|Adhere to IV fluid administration regiment|
|2. Renal failure (Anuria or no urine) in 24 hours|Too little IV fluid given to correct dehydration and shock|Consult a Medical Officer for appropriate renal care| (schedule), monitor fluid input and output|
|3. Hypokalaemia (irritability, confusion, distended abdomen, no bowel sounds, tachycardia or arrhythmias)|Administration of non- recommended IV fluids (5% Dextrose, normal saline), keeping patients for a long time on IV fluids and delay in giving ORS|   Administer Ringers lactate|Use Ringer lactate. Give patients fruits such sweet bananas. Use ORS as soon as the patients are able to drink|
|4. Hypoglycaemia|Failure to offer food to|Administer 20 mls of 50%|Start cholera patient on|

<!-- Source PDF page 82 -->

|Complication (signs)|Cause|Corrective measure|Prevention|
|---|---|---|---|
|(Irritability, restlessness, confusion, yawning, aggressiveness, delirium, convulsion, coma)|patients who are able to feed orally.|dextrose as a bolus followed by 30mls in a drip of RL. Give ORS solution and feed the patient regularly.|ORS as soon as able to drink and feed the patient regularly.|

**Note:** Hypokalemia and hypoglycemia are common in children with malnutrition therefore rehydrate them using Ringer's lactate and NOT other fluids.

##### 6.1.1.7 Selective chemoprophylaxis

All contacts to a confirmed cholera case must be identified and followed up every day up to a maximum of 7 days.

A cholera contact is;

a person sharing the same household with a suspected or confirmed cholera case.

OR caretaker of a patient admitted in the CTU/CTC.

OR a person involved in the transportation of a cholera suspected case.

During the follow up period give chemoprophylaxis as below;

###### Table 8: Recommended antibiotics and doses for selective chemoprophylaxis

||First-line|Alternative|
|---|---|---|
|Adults|Doxycycline 300 mg p.o. single dose or Tetracycline 500 mg four times dailyfor 3 days|Azithromycin 1g p.o. single dose or ciprofloxacin 1g once for 3 days|

<!-- Source PDF page 83 -->

|Pregnant women|Doxycycline 300 mg p.o. single dose|Azithromycin 1g p.o. single dose or ciprofloxacin 1g once for 3 days|
|---|---|---|
|||Azithromycin 20 mg/kg|
|Children < 12 years old|Doxycycline 2-4 mg/ kg p.o. single dose|(max 1g) p.o. single dose, or ciprofloxacin 20 mg/kg (max 1g) p.o. once for 3 days|

Therapy should be started on the day of identification and given under observation.

- Chemoprophylaxis for contacts in a household with a cholera case or caretakers in the cholera treatment unit should be given up to three days after the last episode of diarrhea.

- However, do not administer chemotherapy if the contact is identified seven days or more since the date of their last contact with the case.

- Note: Selective chemoprophylaxis is NOT recommended for health workers who work in the CTU unless they are household contacts.

##### 6.1.1.8 Mass chemoprophylaxis

Mass chemoprophylaxis is useful when a cholera outbreak occurs in a closed population, such as prisons, mental health institutions, childcare homes, boarding schools, barracks (police and army), IDP/Refugee camps.

Mass administration of antibiotics to the community is **NOT** recommended in controlling a cholera outbreak as it may worsen the situation through false confidence and propagate antimicrobial resistance (AMR). **Refer to table 8 above for recommended chemoprophylaxis.**

<!-- Source PDF page 84 -->

##### 6.1.1.9 Feeding cholera patients

Cholera patients should be encouraged to eat highly nutritious foods to replace the lost body calories. Do not withhold food to patients with diarrhea.

##### 6.1.1.10 Discharge and Health education for patients

Consider discharge if the patient:

- has no signs of dehydration

- is able to take ORS without vomiting

- has no watery stools for 24 hours

- is able to walk without assistance

- is passing urine

###### 6.1.1.10.1 Discharge Package

Cholera patients should be discharged with the following items;

- i. Adequate ORS sachets (3 maximum)

- ii. Chlorine tablets for treatment of water

- iii. Disinfectant / Detergents e.g. Jik,

- iv. Health education to on prevention, care seeking and feeding practices

- v. Re-integration into the community by Health assistants and VHTs

###### 6.1.1.10.2 Health education for patients

Usually, the patients and their caretakers have inadequate information on prevention and treatment of cholera. It is very common to find a household with more than one family member suffering from cholera.

The most important messages to prevent the family members from being infected are:

- Washing hands with soap and water after:

<!-- Source PDF page 85 -->

- Taking care of patients i.e. touching them, their stools, their vomitus, or their clothes.

- Using toilets, before preparing and eating or handling foods.

- Washing fruits and vegetables using clean safe water before eating them.

- Cooking food thoroughly, keeping food covered and eating it while it is still hot.

- Drinking and using safe water.

- Boiling or adding chlorine to all drinking water and keep it covered in clean containers with narrow outlet.

- Using latrines to dispose all faecal materials

- Keeping the home clean. Discarding all foods, drinks, water in the household which could have been contaminated during the process of care of the patient at home.

- Do not contaminate the water sources by bathing in them or washing patients’ clothes in and near the water source.

- Seek care for any-one who develops cholera like symptoms and signs and use ORS in case of diarrhea while at home

- Remove and wash any bedding or clothing that may have had contact with diarrheal stool with 0.2% chlorine solution and Air or sun dry all patient’s linen.

- Dig and use latrines for disposal of faeces and keep them covered all the time.

- While caring for persons who are ill with cholera, do not serve food or drink to persons who are not household members.

##### 6.1.1.11 The role of CHEWs and VHTs in promotion of early detection and treatment

All patients with diarrhea should seek medical care early from their nearest health facility. The Health Assistants, Community Health Extension Workers (CHEWs) and VHTs can support early identification, first aid (ORS, zinc) and referral of suspected cholera cases to health facilities for assessment.

<!-- Source PDF page 86 -->

Following assessment, patients meeting the cholera case definition and have no dehydration, stool samples shall be collected for cholera confirmation. These cases shall be managed at home according to PLAN A and linked to the respective community health worker. **_Refer to Assessment and Classification of Patients; as in table 2._**

##### 6.1.1.12 Handling of the Dead, Burial and Funerals - Safe and Dignified Burial (SDBs)

Deaths are associated with serious spread of infection. Therefore, the following burial and funeral precautions must be observed:

- Burial should be supervised by trained health workers.

- Burial must be carried out as fast as possible.

- Disinfect body of the deceased with 2% chlorine or JIK solution.

- Block the mouth and anus with cotton soaked in chlorine solutions/JIK.

- Beddings (including mattresses) and clothing of the deceased if still desired by the family members should be disinfected with 2% chlorine.

- Particles like stool or blood clots are to be disinfected by soaking with 2% JIK before washing.

- All contaminated materials should be disinfected.

###### Supervised Burial

![Source illustration — PDF page 86](images/illustration-086-025.png)

![Source illustration — PDF page 86](images/illustration-086-026.png)

**_Picture 7: The health workers were supervising the burial following massive_** **_deaths. Local leaders were also present_**

<!-- Source PDF page 87 -->

- Big funeral gatherings and feasting in cholera affected areas should be discouraged.

- Transfer of the body to another village, sub-county etc for burial should be discouraged or the transfer must be supervised.

- All deaths suspected to have occurred as a result of cholera must be reported to health facilities, local leaders and higher authorities immediately.

- All social cultural/ religious dead body handling practices should be supervised by health workers.

##### 6.1.1.13 Assessment of Quality of care in the CTU

Case Fatality rate (CFR) and duration of stay in the CTU are key indicators for quality of care in CTU.

###### a) Case Fatality Rate

Case Fatality Rate (CFR) is number of cholera deaths occurring in the Cholera Treatment Units or centers divided by the total cases seen during the period and multiplied by 100 to get a percentage. This is a very important indicator for the quality of healthcare.

With appropriate quality of care, the CFR should not exceed 1.0 %. A CFR greater than 1.0 % is generally considered to be high. If the CFR exceeds 5.0 %, an investigation should be conducted and appropriate corrective action taken.

High CFR may be the result of inadequate case management or bias (e.g. underestimation of the number of cases or inclusion of deaths from other causes).

<!-- Source PDF page 88 -->

###### ii) Duration of stay in the CTU

On average, with good quality care, cholera cases should not exceed 3-5 days on admission in the CTU. Admissions in CTUs exceeding three (3) days are likely to be associated with inappropriate care or the patients might have other conditions that need further investigation.

###### 1) ASSESSMENT OF THE OUTBREAK RESPONSE

- 2) Do the flowcharts illustrate proper management of cholera cases to health care workers?

- 3) Do the flowcharts provide clear information on how to assess and categorize dehydration by providing clear

- information on the treatment protocol according to the status of the patient?

- 4) Did the patients receive treatments? (Recommended fluids for rehydration and antibiotics based on antimicrobial resistance patterns)?

- 5) Did infants and children below 5 years receive the recommended dose of zinc?

- 6) Were patients and their families informed of the preventive measures to take at the treatment site and household?

- 7) Were the cholera patients isolated from other patients (with special latrines)?

- 8) Were the attendants educated and given recommended antibiotics for contacts?

<!-- Source PDF page 89 -->

### 6.2 Cholera Treatment Centers/ Units and Infection Prevention and Control

#### KEYWORDS

Cholera Treatment Centers/ Units, Restriction, Supplies, Isolation of patients, disinfection, waste disposal, hand hygiene, nosocomial

#### 6.2.0 Useful Information

Cholera treatment centers (CTCs) and smaller cholera treatment units (CTUs) are inpatient health-care structures set up during outbreaks to isolate and treat patients with cholera.

Traditionally, CTUs have a smaller capacity and are attached to existing health facilities, and CTCs are independent structures with larger capacity. However, there is no strict definition of a CTU or CTC, and the names are sometimes used interchangeably. The principles for patient care and hygiene are the same for both.

CTUs/CTCs should be open 24 hours a day and provide oral and IV rehydration.

CTUs/CTCs should be established to provide access to treatment for as many patients as possible in the affected areas. When setting up a CTU/ CTC, involve the community to ensure that they will use the facilities.

Although there is no standard design for CTUs/CTCs, several principles should be followed, such as one-directional patient flow and the separation of patient care areas from staff-only areas.

CTUs/CTCs can be established in isolated wards in hospitals or health centers, in a tent on the grounds of a health center or in special units in community buildings such as sports facilities.

<!-- Source PDF page 90 -->

During large epidemics such as in refugee influx, tent-based structures, designed to accommodate large numbers of cholera patients are additional options.

CTUs/CTCs must follow strict IPC measures to minimize the risk of propagation.

#### 6.2.1 Establishment of the CTU

- A special area needs to be identified and set up to control the spread of the disease to ensure isolation and effective management of the cholera patients. The place is called a cholera treatment unit (CTU).

- A health facility nearest to the cholera affected area should be designated as a CTU.

- During an outbreak, district cholera task force should review the need for setting up a cholera treatment unit.

- Cholera treatment units should be ready before an outbreak occurs. This necessitates identification of suitable sites, preposition of supplies, stocks of drugs and other materials, and organization of patient flow.

- In refugee or IDP camps where there is no health care facility, a CTU can be set up using tents.

- If the space at the nearby health facility is inadequate, the CTU should be established inside a community facility such as a school, church, social center among others.

- The DHO should ensure that essential medical and non-medical supplies are available to efficiently respond to the outbreak. **Refer to Annex 8 for essential supplies**

- Individual job descriptions for personnel in CTU should be prepared and communicated to them in advance.

<!-- Source PDF page 91 -->

#### 6.2.2 Identifying a site for CTU

When a health facility is to be considered as a site for a CTU, the following should be considered;

- it should be the nearest to the affected area

- lower level of health service provision

- Where there will be minimal interruption of essential healthcare services

- Location of a CTU outside the health facility has long-term implications and should be considered carefully. The following aspects should be considered:

- The ground should have a gentle slope for easy drainage,

- The CTU should have provision for good lighting and aeration

- The CTC should be sited away from crowds such as food distribution areas, markets, play grounds, schools etc.

- The CTU should be accessible by a good road.

- The CTU should have access to safe water supply.

- The space should be adequate for future expansion of the CTU if required.

- The area should facilitate maintenance of high standards of sanitation with good drainage, hand wash facilities, sinking of pit latrines and provision of safe water.

#### 6.2.3 Setting up a CTU

- The organization of the CTU is meant to offer the best care to patients but also to control the spread of the infection.

- The use of already existing facilities should be considered to minimize cost and time needed for construction.

- Adapting existing health facilities into a CTU is usually the quickest option. In some instances, this can require suspension or relocation of other services to nearby health facilities or OPD.

- If the health facility space is inadequate construct a special CTU with tents and/or local materials to supplement the existing ones. The decision to open such a unit should be taken early (e.g.

<!-- Source PDF page 92 -->

when 5 new cases are being admitted daily). In case there is need to expand the CTU, engage the local authorities to vacate the existing building such as schools.

- In situations where there is heightened threat of cholera and the complete construction of a CTU would be delayed and the site is already chosen, it is advisable to lay down the “foundations” for a CTU. This is called a “Skeleton CTU”. Some of the essential parts of a CTC/ CTU take long time to build and should therefore be part of the skeleton CTU. The components include: fencing; latrine-pits- 1/ 25 patients’ latrine and bathroom; soak-away pits; raised platform (s) for water tank(s); concrete footbaths; cooking stoves garbage pits; and lighting

- A good fence around the CTU is necessary to reduce the number of visitors.

- Organization and functions of CTUs/CTCs

- The organization of CTUs/CTCs should facilitate caring for patients with cholera while minimizing the risk of becoming a source of infection.

- The different areas of the structure (such as patient treatment areas and areas for staff only) must be clearly delineated.

- Patient flow is uni-directional and follows strict rules.

- Only one caregiver should be present with each patient.

- There are clear entry and exit points.

- CTUs/CTCs must have separate latrines and baths/showers for patient use only. If possible, staff should have separate facilities.

- Patient care areas should be gender segregated whenever possible.

- Special considerations should be made for vulnerable groups, such as persons with disabilities, elderly people and pregnant women, when constructing latrines and showers/bathing units.

<!-- Source PDF page 93 -->

##### Components of a good CTU

Organize the CTUs/CTCs into the following areas:

- Reception area: Assessment/ Triage and Classification: register patients, assess for dehydration status and classify for treatment

- Treatment area: wards for admission, rehydration, treatment, observation, area for patients with no or some dehydration (plan A and B) and hospitalization area for patients with moderate and severe dehydration (plan C)

- Convalescent area: observation, health education and discharge

- Medicine and supplies store, dispensing area, ORS preparation area, Jik preparation area, decontamination and disinfection.

- recovery area for patients

- waste area (laundry, waste pits among others.)

- morgue

**Note:** A health worker should be in-charge of preparation of ORS and ensure that the patients drink it. A health worker/ support staff should be assigned the mixing of chorine and infection prevention in the CTU).  The components of a CTU are in **Annex 11.**

#### 6.2.4 Key tasks that should done in a CTU

Main functions to be ensured in CTUs/CTCs include:

- Assessment of patients’ dehydration status

- Registration of patients

- Provision of treatments, including IV fluids, ORS therapy, zinc, and antibiotic therapy.

- Provision of direct patient care, including rehydration, treatment, hygiene, feeding.

- Prevention and control of infection through appropriate measures related to water treatment, cleaning and disinfecting the treatment structure, food preparation, laundry, waste management, cleaning and disinfecting patient transport vehicles and the handling of corpses.

<!-- Source PDF page 94 -->

- Offering health and hygiene education for patients, relatives and caregivers.

- Health education activities inside the CTU

- Safe waste management (incinerator, dustbins);

- Cleaning and disinfection of the CTU, morgue/ mortuary

- Information and patient flow control by personnel with training in IPC

- Staffing, Trainings and supplies at CTUs/CTCs

- Security

Cholera Treatment Units (CTU) can be a specific ward in a health facility or special units set up to treat cholera patients in an emergency situation. During an outbreak, CTUs must be functional 24 hours a day. A plan for rotation of staff therefore needs to be established.

Three teams of 3 people each are required for every 20 beds (a team composed of 1 qualified health worker and 2 cleaners) to provide around-the-clock coverage. Roles and tasks of the deployed personnel should be clearly defined.

If there are too few personnel with appropriate training, health care workers who have previous experience of cholera outbreaks or who have received adequate training should be mobilized to provide on-site training and supervision of the less experienced personnel.

- Conduct training in clinical case management using this guideline so that health professionals are able to treat dehydration and common complications.

- Conduct training in IPC measures, including prevention of transmission at the facility level, use of protective equipment such as gloves and aprons, safe preparation and use of different chlorine solutions, disinfection procedures and waste management.

<!-- Source PDF page 95 -->

- Post job aids with treatment and IPC protocols in work areas for quick reference.

- Provide sufficient supplies at every healthcare facility including CHEWs and VHTs that will treat cases of cholera. Supplies should not be limited to IV fluids; most patients can be treated with ORS alone.

- Prepare sufficient quantities of ORS, using safe water, to cover daily needs.

- ORS should be discarded after 12 hours if kept outside a refrigerator or 24 hours if refrigerated.

- A 3-day supply of water should be stored on site at all times.

- Organize adequate provision of WASH supplies, including chlorine, residual chlorine testers, cleaning materials, buckets for chlorine solution preparation, protective gear, hand-washing stations, waste bins and trolleys/wheelbarrows, body bags, among others.

Stock management is a key part of running CTUs/CTCs. The rate of use of supplies can vary greatly during the course of an epidemic. A minimum supply to cover 3 days or longer should be kept on site, depending on reliability and regularity of supply delivery. There should be dedicated staff to manage supplies.

#### 6.2.5 Restriction of movement within the CTU

All movement into and inside the CTU should be limited. When movement is necessary between units of the CTU, make sure that people walk through footbaths (disinfection) and are sprayed. Put a guard next to each footbath to enforce people walking through. There should be one-way flow of patients inside the center from reception/assessment unit to the ORT-or IV unit.

Movement inside the CTC can be limited by having only one entrance and a strong fence around the CTU and between the different units. Guards should prevent people other than patients, attendants and

<!-- Source PDF page 96 -->

staff from entering. Movement is reduced when food is provided to patients, staff and attendants.

The rule of one attendant one patient should apply. This attendant will stay during the period the patient is sick. Upon entering the CTU, patients should be washed and attendants advised to bathe. When logistics are available the clothes should be tagged, washed and returned later to the patients otherwise patients’ relatives/attendants are advised to disinfect and wash the clothes.

##### Cholera Treatment Unit

![Source illustration — PDF page 96](images/illustration-096-027.png)

![Source illustration — PDF page 96](images/illustration-096-028.png)

**_Picture 8: Restriction and disinfection are important to prevent spread of infection_**

#### 6.2.6 Evaluation of Services in the CTU/CTC

Timely access to appropriate rehydration is key in preventing deaths due to cholera. If treatment is managed appropriately, no admitted patient should die due to cholera. Deaths can occur from delays in arriving to the CTU or from delays in receiving adequate emergency treatment, overwhelmed staff, lack of adequately trained staff or insufficient supplies, among others.

<!-- Source PDF page 97 -->

Depending on the magnitude of the outbreak, assessment should be done to determine the need for deployment of Emergency medical evacuation services so as to reduce deaths due to delayed evacuation. During an outbreak, many patients may require emergency care at the same time, therefore it is essential that CTUs and other health facilities be prepared in advance to respond.

Conduct an evaluation of the health facilities to identify gaps and actions that should be implemented to ensure appropriate access to treatment ( **Annex 12** – CTU patient evaluation form).

##### Main elements that should be assessed include:

- water supply, storage and quality

- IPC measures

- facility layout and organization

- screening, admission and observation areas

- hospitalization area

- kitchen and meal preparation areas

- water and sanitation, latrines, laundry and baths/showers, including drainage and potential to contaminate the water table

- waste management

- management of corpses

- procedures and protocols in place

- stocks and supplies

- data management

- staffing

- health and hygiene education.

<!-- Source PDF page 98 -->

### 6.3 INFECTION PREVENTION AND CONTROL IN THE CTU/CTC

#### KEYWORDS

Isolation of Patients, Disinfection and cleaning, Waste disposal, Hand hygiene, Restriction

#### 6.3.0Useful Information

Adequate infection control practices are essential to prevent the spread of cholera in the CTC/CTU, and should be applied in all situations by patients, caregivers and staff.

Prior to working in the CTC/CTU, all medical and non-medical staff (cleaners, guards, among others) must be trained in the IPC principles of hand hygiene, food and water hygiene, patient isolation, restriction, disinfection and cleaning, waste management, and patient flow. All IPC protocols/ SOPs must be made readily available on-site at all times, as reference for staff working in the CTC/CTU (usually on laminated cards, posted visibly throughout the unit).

Adequate water, sanitation and hygiene (WASH) services are critical for patient care and for infection prevention and control (IPC) in CTCs/CTUs to help prevent disease transmission within the unit and to the surrounding areas.

Organize the CTUs in clearly demarcated areas ensuring that patients flow in one direction.

It is important to isolate all suspected and confirmed cholera cases. There should be restriction of movement in and out of the CTU for the attendants and any other persons.

Patients should be properly cleaned, their belongings and CTU cleaned and disinfected. The CTU should have adequate water, hand washing and waste disposal facilities, hygiene and sanitation facilities for

<!-- Source PDF page 99 -->

health workers, patients and their caregivers. This should be done in each ward, as well as at entrance and exit.

Use appropriate Personal Protective Equipment (PPE) when in contact with patients and when handling infectious materials, buckets and dead bodies.

Designate a place for safe disposal of excreta and vomitus of the cholera patients. At all times, latrines/toilets for cholera patients should be separated from those used by unaffected persons and gender segregated.

Ensure there is enough water to cover the daily needs of patients, caregivers and staff, estimated to be 60 liters per patient per day and 15 liters per person per day for caregivers, although this might vary according to context, culture and climate. If there is not a water source on site or nearby that is protected from contamination that can provide sufficient water for the facility, then ensure provision with water trucks.

![Source illustration — PDF page 99](images/illustration-099-029.png)

#### 6.3.1 Priority Interventions

##### 6.3.1.2 Hand Hygiene

- Use 0.05% chlorine solution for hand-washing in the CTU/CTC.

- Use soap and running water in hand-washing stations for bare hands and skin outside the CTU/CTC.

- Healthcare workers should perform hand-washing according to WHO’s “Five moments of hand hygiene”:

   - i. before touching a patient

   - ii. before performing clean or aseptic procedures

   - iii. after body fluid exposure/risk (that is, after handling any potentially contaminated equipment or material such as laundry, waste, dishes, vomit and stool buckets)

   - iv. after touching a patient

<!-- Source PDF page 100 -->

###### v. after touching patients’ surroundings

Other important moments when health workers should wash their hands include upon entering and exiting patient areas, after using a latrine (or handling a child’s faeces), after handling corpses and before food preparation and handling.

Hand washing stations should be located in places easy to access, clearly labelled, with instructions for use.

Hand washing stations should be placed at the entry and exit to the CTC/CTU, at all latrines, in all patients’ areas, in the kitchen, the laundry area, the waste management area and the morgue. Ensure regular monitoring of the hand washing stations for adequate chlorine solution or soap and safe water levels.

##### 6.3.1.2 Personal Protective Equipment

- As in all health care structures, it is preferable that staff do not wear personal clothing while on duty

- Gloves must be worn whenever a direct contact with vomitus, stool or other body fluids, as well as mucous membranes or nonintact skin is anticipated

- Wear gowns to protect skin and prevent soiling of clothing during activities that are likely to generate splashes or sprays of vomit, stool or other body fluids.

- Gown selection depends on amount of fluid likely to be encountered. If the gown is not fluid resistant, then a waterproof apron should be worn over the gown if splashing of infectious materials is anticipated.

- Personal protective equipment (PPE) is particularly important for personnel involved in cleaning and disinfecting, including those managing cholera waste (i.e. stool and vomitus), as well as those handling high strength chlorine generating products and chlorine solutions.

<!-- Source PDF page 101 -->

- Staff involved in these activities should wear heavy duty gloves, gumboots, a mask and a gown that are fluid resistant. If gowns are not available, then an apron should be added.

   - It is the responsibility of the CTC/CTU management to ensure the availability of PPE and provide training to staff on the proper use and maintenance of these items.

   - Reusable protective clothing should be washed in water with detergent and then disinfected with a 0.2% chlorine solution for 10 minutes and then air dried in the sunlight, when possible.

   - Staff should not take any protective clothing out of the CTC/CTU.

   - At least a one-month supply of disposable PPE items should be available on site.

- **Note** : Additional PPE (e.g. mask, eye protection, among others) may be used in addition to contact precautions if there is a risk of a splash or spray of body fluids or when working with chemicals.

##### 6.3.1.3 Laundry

   - Train laundry staff on the IPC precautions on proper handling of linen and ensure they wear the correct PPE – fluid resistant gown, medical mask, face shield, heavy duty gloves and gumboots.

   - The caretakers should be educated and guided on proper handling of patients’ linen.

   - Transport the linen in a leak proof container with appropriate labelling.

   - Soiled materials including patients’ clothes, staff uniforms, blankets, gowns and protective clothing should be separated and washed in water with detergent, then immersed in a 0.2% chlorine solution for 10 minutes and air dried in the sunlight when possible. Drying lines should be constructed near the laundry area.

   - The laundry area should be located close to the area producing the most contaminated materials, such as bed linens and clothing (Plan XC area and mortuary).

<!-- Source PDF page 102 -->

**Note** : All patient linen should be washed within the designated laundry area and away from open water sources.

##### 6.3.1.4 Waste management

- All waste generated in a CTC/CTU, be it liquid or solid, is considered highly infectious.

- Thus, no waste that is generated inside the CTC/CTU should leave the premises.

- All waste should be treated and disposed off in a designated, restricted waste zone within the CTC/CTU except for liquid cholera waste which should be disposed off in latrines (or preferably into a dedicated pit for this purpose).

- The waste zone should be marked and fenced off to avoid access by unauthorized people.

- The area should be well ventilated, and all waste should be labeled by type.

- Generally, storage time should be as short as possible but should not exceed 24 hours, to reduce the risk of spread of infection.

- Ensure adequate management of waste, as well as drainage.

- Establish a functional drainage system in the CTU to avoid flooding of contaminated areas (latrines, laundry, waste area).

- Ensure CTC site drainage is managed and does not flow into neighboring areas or contaminate the water table.

- Ensure body fluids (including stool and vomitus) are emptied regularly in the latrines of cholera patients.

- Pouring chlorine directly into latrines is not recommended.

- Plastic buckets or other containers used to transport body fluids should be disinfected using 0.2% chlorine solution after cleaning with detergent/ soap and water.

- Cleaners, staff working with chlorine, and waste managers should be adequately trained in IPC and equipped with appropriate protective equipment. Protective equipment and clothing should be washed with a 0.2% chlorine solution and dried in the sun.

<!-- Source PDF page 103 -->

- Ensure essential rules are respected at the CTU to minimize the risk of propagation.

##### 6.3.1.5 Disinfection inside the CTC

- It is important to use the right chlorine solutions for the right use: preparation and use of the various chlorine solutions is shown in **Annex 13** .

- Use 2% chlorine solution for disinfecting corpses and body fluids (including vomit, faeces).

- Use 0.2% chlorine solution for disinfecting all parts of the cholera wards, floors, latrines, kitchen, toilets and shower/bathing units, beds or cots, patient’s bedding and linens, clothing, utensils, containers and dishes, waste containers and covers, vehicles used for transporting patients and personal protective equipment (gloves, aprons, goggles, etc.).

- Use 0.05% chlorine solution for hand hygiene while observing the 5 moments of hand hygiene.

- In addition, all containers with chlorine solution must be clearly labelled and controlled. These solutions should also be protected from direct sunlight since chlorine is denatured by sunlight.

<!-- Source PDF page 104 -->

##### 6.3.1.6 Protection of Chlorine Solutions from direct sunlight

###### Protection chlorine disinfectants from direct sunlight

![Source illustration — PDF page 104](images/illustration-104-030.png)

**_Picture 9:  Mulago CTU (2003), tanks containing tanks with labels of_** **_common chlorine solutions found in CTU 2%, 0.2 and 0.05%_**

- Disinfect feet in special footbaths whenever   entering or exiting the CTU/CTC with a 0.2% chlorine solution, placed at all entrances of the tents and buildings. Note: Limit movement of support staff in and out of the CTC/CTU.

- All staff should not move out of the CTC/CTU with the PPE used while in the CTU/CTC and these should be washed every day after duty.

##### 6.3.1.7 Disposal of Faeces and Vomitus

- Individual defecation for patients in the acute stage of the disease is essential and unavoidable. Provide two buckets (one for vomitus and one for stool) under the Cholera beds for each patient and disinfect them regularly with 0.2% chlorine solution.

- Within the CTU/CTC, staff and patients should have separate latrines and they should be sex specific. Patient latrines should be cleaned after each use.

- Plastic or other squatting plates are ideal to facilitate cleaning.

<!-- Source PDF page 105 -->

- Facilities should be made in such a way that cleaning is easy and thorough. When the floor is made of wood, plastic sheeting is a must.

###### Disposal of Corpses (Dead Bodies)

- Ensure that the corpse is disinfected with 2% chlorine solution and safely packaged in a body bag.

- Corpses should never be handed over to the family without proper disinfection.

- Ensure and educate families on the safe handling of the corpse.

- Ensure the burial is supervised by health workers.

**Note** : Further information on management of corpses is covered under case management.

##### 6.3.1.8 Disposal of Solid Waste

Collect waste in a garbage bin with a cover and incinerate collected waste routinely.

Sharp objects and needles should be collected in a biosafety box or bucket with a tight-fitting cover. This box or bucket should be situated at the entrance of each unit within the CTU. The contents should be incinerated or disposed into a medical pit constructed for that purpose or a pit latrine.

##### 6.3.1.9 Wastewater Control

- In the design of the CTU, disposal of waste water and rain water should be considered. The CTU should preferably be built on a gently sloping ground.

- Waste water is surface water collected from tap stands, footbaths, kitchen, bathrooms as well as water used in disinfecting floors, washing hands, clothes and corpses.

- Water used in cleaning should flow away easily inside each construction. This is facilitated by constructing a small channel in the middle of the tent or building.

<!-- Source PDF page 106 -->

- When tents are used as CTUs, plastic sheeting should be used on the floor for ease of cleaning and disinfection.

- Around each construction a simple drain should be dug that diverts waste water to a covered soak- pit. If the soil is not permeable, small soak pits will not function properly. It will be necessary to dig a big soak-pit, at a distance of 10 meters from the CTU.

- Make sure that no one has access to the water in the soak pits by making a fence and a cover.

- If resources are available, a cover over the ditches will improve the hygiene of the drainage system.

- On the outside of the CTU a large channel should be excavated around the facility in order to prevent run off entering the CTU. The water from this channel is less contaminated and can be diverted into a soak pit.

##### 6.3.1.10 IPC considerations during closure of CTU

The following points detail the steps needed to close a CTC/CTU;

###### Cleaning and Disinfection

- i. All doors, floors, walls, stairs, handles, beds, among others should be cleaned with soapy water and disinfected with a 0.2% chlorine solution for 10 minutes

- ii. All buckets that have been used for stool or vomitus should be thoroughly washed with detergent and a 2% chlorine solution and air dried in the sunlight, when possible (disinfection is always done after cleaning.

- iii. It is important to make sure that there is no organic matter or residues remaining (which could still contain V. cholerae). This can be done through environmental decontamination using 2% chlorine solution.

<!-- Source PDF page 107 -->

###### Decommissioning

- i. All latrines and soak-away pits (if established specifically for the outbreak) should be decommissioned (including those used for showers and bathing units)

- ii. Unless the CTC/CTU is located within the grounds of an existing health structure that will continue to use the waste zone, all pits should be filled - the pits for organic waste backfilled with soil, and the sharps pits filled with concrete (to enclose all sharps and protect future users of the land).

- iii. All the material leaving CTU should go to store or another CTU but not on ward with patients having other medical conditions.

<!-- Source PDF page 108 -->

###### ASSESSMENT OF THE OUTBREAK RESPONSE

- 1) Were the cholera treatment units located close to the most affected communities?

- 2) Were there hand-washing facilities in the cholera treatment centre? Were the patients’ relatives washing their hands every time they leave the centre?

- 3) Were the cholera treatment units organized in four areas of reception/screening and observation, hospitalization, convalescent room for ORS treatment, neutral area (for kitchen, stocks of material, among others)?

- 4) Were measures in place for the safe disposal of excreta and vomitus? Were there special latrines for cholera patients who can walk, separated from latrines used by the rest of the patients?

- 5) Was there  enough water to cover the daily needs of patients, staff and attendants as recommended?

- 6) Were buckets, latrines, clothes, and bedding properly disinfected?

- 7) Were cholera cots available?

- 8) Was there community involvement to limit the spread of disease?

- 9) Were the health care workers aware of the infection prevention and control measures necessary to avoid cross infection (handwashing, isolation ward, among others)?

<!-- Source PDF page 109 -->

## CHAPTER SEVEN: RISK COMMUNICATION AND COMMUNITY ENGAGEMENT

![Source illustration — PDF page 109](images/illustration-109-031.png)

![Source illustration — PDF page 109](images/illustration-109-032.png)

Picture 10: Community sensitization on cholera prevention in communities of Kayunga, 2023

### 7.0 Useful Information

Communication with the public during a cholera outbreak is critical not only for the rapid control of the outbreak, but also to keep the public informed and reduce the risk of social, political and economic turbulence.

Risk communication is therefore defined as the real-time exchange of information, advice and opinions between experts or officials and people who face a threat to their survival, health or economic - social well-being.

The purpose of risk communication is to ensure that everyone at risk for cholera is informed about how to reduce the risk of spreading the

<!-- Source PDF page 110 -->

disease, take personal protective and preventive measures, and be able to make informed decisions if someone gets sick.

Public health officials must report, fully and rapidly, what they know, what they suspect and what they are doing to control the outbreak.

- Best practices for effective risk communication include the following: 1. Create and maintain trust.

   2. Acknowledge and communicate even in uncertainty.

   3. Be transparent and fast with the first communication and all communications.

   4. Be proactive in public communication, using a mix of preferred channels of affected populations, such as TV, radio, SMS, internet, social media, mass awareness initiatives (meetings, megaphones, presentations, places of worship, schools, health centers, burials) and social mobilization.

   5. Understand local context (knowledge, behaviors, beliefs and barriers) towards cholera and refine messaging accordingly.

   6. Involve and engage the community in the outbreak response (planning and implementation) through community leaders and influencers.

### 7.1 Clarifying Rumours and Community Concerns

Trusted information should reach people and rumours should be addressed by maintaining a very open flow of information from the beginning of the outbreak. Rumours spread easily when information is incomplete, falsified or delayed.

Define a strategy to disseminate accurate information promptly, rather than responding to rumours.

Provide information that is easily understood, complete and free of misleading information.

<!-- Source PDF page 111 -->

Key messages to the public should help people to recognize symptoms of cholera, how it is transmitted and provide information about what to do for prevention and treatment, encouraging early treatmentseeking behavior.

Information should include what cholera is, how it spreads, and how it can be prevented, why, when and where to seek help, and how to care for family members with diarrhea.

### 7.2 Media Involvement in the Outbreak Response

   1. Establish partnerships with the media to contribute to controlling the outbreak by providing: i. information to people within and outside the affected area ii. information in the appropriate language

      - iii. information through the appropriate channels (radio, press, TV)

      - iv. the right type of information, with the right frequency at the right time.

   2. When an outbreak starts, designate a single spokesperson who will be the focal person to manage all media engagements.

   3. Prepare a set of frequently asked questions (FAQs) with responses and regularly prepare press releases for dissemination.

The type of information to be disseminated will depend on the levels of the media – local, national or international.

### 7.3 Community Engagement

Community engagement is a process of including at-risk and affected communities in the cholera control response throughout the process from planning, implementation and monitoring. It promotes and facilitates community ownership in the response.

<!-- Source PDF page 112 -->

Community engagement is a complementary strategy to risk communication.

Community engagement recognizes challenges and builds upon locally defined opportunities for people to be able to practice behaviors that stop cholera transmission.

Outcomes of effective community engagement are foremost about community ownership of the response and include increasing trust, confidence and cooperation with response teams, community feedback and uptake of preventive practices.

Best practices for community engagement include:

- i. identifying and using trusted community-appointed people as entry points for response teams to work with at-risk communities.

- ii. facilitating a local risk assessment and using locally generated data to develop an implementation plan for the community to remain cholera free or to rapidly interrupt transmission.

- iii. forming a small local task team comprising of trusted leaders, respected members of the community, religious representatives, youths and women’s group members who are responsible for engaging with the response teams and monitoring implementation of the local plan.

- iv. facilitating routine feedback and engagement between the community and the cholera response team to be able to change the strategy if needed.

- v. supporting and building on the mass mobilization efforts of local churches, networks, teachers and vendors to improve the community’s confidence.

- vi. using local communication channels (such as information boards, meetings, social media) to communicate which parts of the response are working/not working and how to improve the response.

<!-- Source PDF page 113 -->

### 7.4 Social Mobilization for cholera prevention and control

Cholera outbreak can quickly and easily be controlled when the public understands how the disease is spread, prevented and controlled.

Active engagement and involvement of key stakeholders through advocacy, social mobilization and community participation is crucial in empowering the population to interrupt and control an outbreak.

This is done through;

- i. Orientation of district and community leaders

- ii. Communication through radio, posters, social media, community audio towers (CATs), and Tv using the language the community understands.

- iii. Organize dialogues/barazas in places where people usually gather (healthcare facilities, salons, trading centers, churches, playgrounds, water collection points, among others.)

#### 7.4.1 Social Mobilization before an Outbreak

Social mobilization before an outbreak is important in equipping communities with messages on prevention and control. This is particularly important in empowering communities to identify local solutions to prevent a possible outbreak and adapt suitable control measures.

- The preparatory activities include;

   - i. Orientation of community leaders in prevention and response

   - ii. Training of village health teams/community health extension workers on key prevention messages

   - iii. Distribution of IEC materials

   - iv. Dissemination of Cholera prevention messages using appropriate media channels.

<!-- Source PDF page 114 -->

#### 7.4.2 Social Mobilization during an Outbreak

Social mobilization at the community level, helps in disseminating Community case definition that enables the community to identify cases and report cholera alerts.

### 7.5 Key Messages for dissemination

#### 1) Cholera is a serious disease but can be prevented

- Everyone is at risk of acquiring cholera

- Wash hands with clean water and soap before cooking, eating and after using the latrine. Proper hand washing kills the germs and prevents the spread of cholera

- Boil or chlorinate drinking water to kill cholera germs and prevent its spread.

- Use and keep the latrines clean. Dispose off all fecal matter in the latrine/ toilet

- Cook food thoroughly well and eat it while still hot

- Do not defecate or urinate in or near a source of drinking water

- Do not bath or wash your clothes or pots and utensils in the water source

- Keep the areas surrounding water sources clean.

#### 2) What is cholera?

- Cholera is a bacterial disease caused by Vibrio cholerae.

- Cholera causes severe watery diarrhoea and may cause vomiting.

- Cholera can cause death from dehydration (the loss of water and salts from the body) within hours if not treated.

#### 3) How is cholera spread?

- Cholera is spread when faeces from an infected person gets into drinking water or food.

- What are the signs and symptoms of Cholera? `o` Acute watery diarrhea with severe dehydration. It takes between 2 hours to 5 days for a person to show symptoms

<!-- Source PDF page 115 -->

after consuming contaminated food or water. If left untreated, cholera can lead to death.

- Most people infected with cholera do not develop any symptoms. The bacteria are present in their faeces for 1–10 days after infection and are shed back into the environment, potentially infecting other people.

#### 4) How to protect yourself from cholera

- **a) Personal hygiene and sanitation**

- 1) Wash your hands with soap, and clean running water for at least 20 seconds.

- 2) Before cooking, eating and feeding your children

- 3) After using the latrine and cleaning your children after they have used the latrine.

- 4) Before and after taking care of and touching a sick person.

- 5) Wash all parts of your hands – front, back, between the fingers and under the nails.

- 6) Use the latrine/ toilet for disposal of all excreta.

- 7) Keep the latrine/toilet clean.

- 8) Ensure hand washing station with soap is situated next to the facility .

#### b) Messages on Food and drinks

- 1) Wash hands before preparing food.

- 2) Wash food with clean water before cooking.

- 3) Thoroughly cook the food.

- 4) Use clean utensils for serving food.

- 5) Eat cooked foods while still hot.

- 6) Wash raw fruits and vegetables with safe water before eating them.

- 7) Safely cooked food in a safe environment.

- 8) Raw food should not be kept together with cooked food in the same store.

- 9) When using a refrigerator, store raw food in the lower compartment, and cooked food in the upper compartment.

<!-- Source PDF page 116 -->

- 10) Reheat food before eating.

- 11) Keep all kitchenware and environment clean.

- 12) Dry utensils on drying rack after washing.

- 13) Messages on safe drinking water

- 14) Collect water from a known safe source.

- 15) Use clean containers for collecting and storing water even if it looks clear, water can contain the bacteria causing cholera.

- 16) Drinking water must be boiled thoroughly. If boiling of water is not possible, use chlorine tablets in recommended dosages.

- 17) When using chlorine tablets the water should not be kept for more than 24hrs.

- 18) Keep drinking water in a clean and covered narrow mouthed container/ vessel.

- 19) Pour the water from the container into a clean cup to drink.

#### c) Messages on protecting water sources

- 1) Activate the water user committee

- 2) Regularly monitor water quality as per protocol. (**refer to the link** )

- 3) Conduct a water safety assessment with the community to eliminate potential or suspected sources of contamination.

- 4) Do not defecate, urinate, or bath in or near a source of water.

- 5) Do not wash your clothes or your utensils in the source of water.

- 6) Cover open wells and seal them off properly when not in use to avoid contamination.

- 7) Hang the buckets used to collect water when not in use; they must not be left on a dirty surface.

- 8) Keep areas surrounding the water source as clean as possible.

- 9) Get rid of stagnant water around a water source

#### Messages for Community Leaders

- In addition to guiding community members to live healthy, community leaders should guide on the following:

- The biggest danger of cholera is loss of water from the body. Do not panic but act quickly. Drinking a solution of oral rehydration

<!-- Source PDF page 117 -->

salts mixed in with safe water (boiled or chlorinated) can help in rehydrating a case.

- Take the suspected case immediately to the nearest health center. Continue giving the drinking solution oral rehydration salt to the patients while on the way to the health facility.

- Wash your hands with clean water and soap after taking care of patients e.g., touching their stools, vomit, or clothes or their bodies.

- Avoid contaminating a water source through washing clothes, urinating, defecating or allowing animals to drink from it; separate points should be created for watering animals.

- Indiscriminate discharge of untreated effluent from the factories to the environment should be discouraged. Factories must treat all the effluent before discharge to the environment.

#### Important message to note.

![Source illustration — PDF page 117](images/illustration-117-033.png)

<!-- Start of picture text -->
Social Mobilization and Health Education should continue throughout the year with intensification before the cholera <!-- End of picture text -->

#### Messages for Health workers

1. Strictly Observe IPC protocols at all times in the health facility and while at the CTU.

2. Observe the five moments of hand hygiene

3. Appropriate use of PPE

4. Ensure proper health care waste management

5. Ensure safe and dignified burial of the dead.

<!-- Source PDF page 118 -->

6. Manage suspected and confirmed cholera cases as per this technical cholera guideline

7. Ensure proper excreta disposal in the health facility and the surrounding/catchment community

![Source illustration — PDF page 118](images/illustration-118-034.png)

#### _Sample cholera messages illustrated by a poster_

<!-- Source PDF page 119 -->

#### ASSESSMENT OF THE OUTBREAK RESPONSE

1. Was health education an important part of the outbreak response?

2. Were the messages targeting the community, community leaders, and the health workers clearly articulated?

3. Were the messages disseminated through community or religious leaders through any channel that reaches the maximum of people with greatest impact on their behaviours?

4. Were the messages adapted to local cultural beliefs about the disease and to the capacity for implementing control measures in the community (e.g. if they have a functional hand washing facility within 5 meters radius of the toilets/ latrines at households and all public places)?

5. Have efforts been made to encourage the use of latrines?

6. Was there active case-finding in the community?

7. Were education messages given to the patients and their relatives in health care facilities and the community?

8. Are IPC protocols being adhered to by the health care workers at all times in the health facilities and CTU?

<!-- Source PDF page 120 -->

## CHAPTER EIGHT: ENVIROMENTAL HEALTH

### Protection of water sources is necessary to ensure safe water access is attained.

![Source illustration — PDF page 120](images/illustration-120-035.png)

![Source illustration — PDF page 120](images/illustration-120-036.png)

**_Picture 11: Use of contaminated water; water collected from open water_** **_sources is contaminated and should be boiled or chlorine treated_**

**KEYWORDS Safe Water, Safe Food, personal and Family Hygiene, human excreta and wastewater management.**

### 8.0 Useful Information

Cholera is mainly transmitted by ingestion of water or food contaminated with vibrio cholerae through the fecal-oral route. Simple measures to prevent cholera include; improving water quality, sanitary facilities, food preparation and distribution as well as basic hygiene practices.

The following areas should be considered: Safe drinking water, food safety, sanitation, personal, family and hand hygiene; municipal water supplies; other water supplies; solid waste management; disposal of excreta and treatment of waste water; institutional sanitation; and long–term plans for improving water and sanitation.

<!-- Source PDF page 121 -->

### 8.1 Safe Water

#### KEYWORDS

Water Quality, Testing, Boiling Water, Chlorination,

#### 8.1.0 Useful Information

Water plays a very big role in the transmission of cholera especially if contaminated by feacal matter containing _Vibrio cholerae_ . Unprotected water sources e.g. wells, springs, ponds, dams, lakes, rivers, streams and swamps can be the source of transmission.

A good inventory of all water sources, obtained through sanitary surveys (water quality surveillance) and safe water chain is useful for identifying potential risks of contamination.

Attention should be paid to the operation and maintenance of all water sources in the community to avoid communities resorting to unprotected water supplies. They should be encouraged to treat their drinking water by boiling, use of chlorination, solar disinfection, among others.

#### 8.1.2 Priority Interventions.

##### 8.1.2.1 Safe Water Supply

Availability of safe water is key in prevention and control of cholera. Efforts should be made to ensure that communities have access to adequate amounts of safe water.

###### _8.1.2.1.1 Types of Water Access Points_

There are various types of access to drinking water. They include; household connection, public standpipe, borehole, protected dug well, protected spring, rain water collection, unprotected well, surface waters, motorized borehole, and tanker truck.

<!-- Source PDF page 122 -->

###### _8.1.2.1.2 Contamination of Water Sources_

Drinking water might be contaminated by;

- Contact with hands and bodies of people who have cholera although show no symptoms

- Contaminated articles such as buckets, cups, clothes

- Faecal material (e.g. by infiltration into ground water sources, when the latrines are situated less than 30 metres away from the ground water sources

- Deliberate open defecation and faecal dumping into water sources. For example, communities around water bodies who defecate into the water source, urban dwellers who open their latrines into the drainage channels, factories with poor human excreta management and disposal, among others.

The risk of water contamination varies according to the type of water source.

Unprotected water sources are often contaminated. Authorities at all levels should ensure that these water sources are protected to reduce the risk of contamination.

Treatment of water at the source may be the best way to prevent the spread of cholera in the community. When the water source is too turbid it should be filtered before disinfecting. Alternatively, filtration and chlorination could be done at household level.

Installation of chlorine dispensers at the source is encouraged during outbreaks.

_8.1.2.1.3 Provision of Safe Drinking-Water_

The conditions and practices of water collection, transportation and storage contribute to the safety of household water.  It is important for community members to ensure that each household has a basic latrine facility. Community leaders should ensure that public places

<!-- Source PDF page 123 -->

such as markets, places of worship, schools, places of entertainment, banking halls, commercial buildings, among others, have adequate toilet and sanitation facilities. This greatly contributes to availability of safe drinking water in the community and household level.

There is evidence that storage of water in a narrow-mouthed vessel with a protected dispenser (jerrycan, spigot, and spout) is much safer than storage in a wide-mouthed vessel (pot, tank).

To avoid contamination and ensure safe water;

- Drinking water should be kept in a clean covered pot or bucket. It is better to pour the water from the container than to use a potentially contaminated article (e.g. cup without handle) to retrieve the water.

- Alternatively, and better still, the bucket, pots and the jerry can should be fitted with the tap to facilitate dispensation.

Chlorine dispensers should be installed at points of water collection and maintained at all times with the help of village water maintenance committee members or CHEWs.

Communities should be encouraged to use chlorine tablets in areas where chlorine dispensers are not functional or when water is collected from untreated water sources.

Re-activation and training of water user committees at community levels should be thoroughly done.

During cholera outbreaks, efforts should be made to subsidize the cost of water from the National water and sewerage corporation so as to discourage the communities from using unprotected water sources.

<!-- Source PDF page 124 -->

##### 8.1.2.2 Ensuring Water Quality

The Assistant District/City Health Officer Environmental Health should ensure that the quality of untreated water should be assessed using field-testing kits on a regular basis. Drinking water should contain less than 5 colony forming units (CFU)/100ml of water. Throughout the safe water chain, quality checks should be made regularly, at source, during transportation and at storage (households).

###### 8.1.2.2.1 Water Treatment for household and institutional use

Various methods for household and institutional water treatment are available. They include boiling, chlorinating, solar disinfection with ultra-violet light plus heat, chemical coagulation– filtration plus chlorine disinfection.

###### 8.1.2.2.2 Boiling

It is an effective method of water treatment at household level. It involves heating water to high temperature to kill bacteria and other microorganisms that can cause illnesses. This is preferred especially when disinfection by chlorination is not possible. However, it may not be practical when fuel is scarce.

###### 8.1.2.2.3 Making Water Safe by Chlorination

Water is treated using chlorine-releasing agents such as chlorine tablets or Powders. It is a very effective method and can provide safe water to big populations such as schools, internally displaced people’s camps, prisons, among others.

It requires careful consideration in dosage, by-products, taste, odour, equipment, safety, cost and monitoring. After mixing, ensure that the stock solution is covered and kept in a cool place away from sunlight. Add stock solution to water to make it safe.  Chlorine dispensers

<!-- Source PDF page 125 -->

employ this method. The amounts of water which can be made safe and required volume of stock solution are shown in the table 9 below; **Table 9: Amount of stock solution required for water treatment**

|Amount of water made safe|Volume of stock solution required|
|---|---|
|1litre|3drops|
|10 litres|6mls|
|100 litres|60mls|

After mixing, allow the resultant water to stand for 30 minutes before using it. The residual chlorine in this water should be between 0.20.5mg/liter.

**Note:** If water is turbid, filter it before chlorination or boil it instead of chlorination.

<!-- Source PDF page 126 -->

###### ASSESSMENT DURING THE OUTBREAK RESPONSE

1. Have the different suspected contaminated water sources been identified?

2. Have these sources been disinfected during the outbreak?

3. If Water at the source were chlorinated, was there regular monitoring of residual chlorine?

4. What measures were recommended to avoid contamination of water?

5. Was the community informed about preventing water contamination?

6. Where chlorination of water at the source was not possible, was there any programme to ensure safe drinking-water at household level?

7. Were chemicals for water disinfection (chlorine compounds) available in the local market at affordable prices?

8. Was there any system for providing safe water to high-risk communities during the outbreak?

9. Did the population receive a supply of at least 20 litres of safe water per day per person?

- 10.Were health workers properly trained to teach local people about hygiene and disinfection techniques?

<!-- Source PDF page 127 -->

### 8.2 Safe Food and Beverages

#### KEYWORDS

Food Preparation, Hygiene In public places, Cooked Food, medical examination of food handlers.

#### 8.2.0 Useful Information

Proper food handling should be observed at all times. Local government political and technical leaders should develop and implement food hygiene and safety standards within their areas of jurisdiction.

Food has been implicated in several cholera outbreaks as a vehicle for cholera transmission. Special attention must be paid to food safety at social gatherings–marketplaces, parties, funerals, meetings among others.

During cholera outbreaks, bans on food vending along the roads and streets should be imposed. Sale of locally prepared and packaged drinks, cold foods should be discouraged.

#### 8.2.1 Priority Interventions

##### 8.2.1.1 Safe Food

Eating contaminated food is one way in which persons get cholera. It is important to prevent food from being contaminated.

###### 8.2.1.1.1 Common Source of Food Contamination

- b) Drinking-water that has been contaminated at its source (e.g surface water contaminated by faeces entering an incompletely sealed well), during transport and/or supply, or during storage (e.g. by contact with hands soiled by faeces).

- c) Ice and juices made from contaminated water and locally packaged in polyethylene bags.

<!-- Source PDF page 128 -->

- d) Cooking and serving utensils washed with contaminated water.

- e) Moist foods (e.g. milk, cooked rice, potatoes, beans, eggs, and chicken) contaminated during or after cooking/preparation and allowed to remain at room temperature for several hours, provide an excellent environment for the growth of Vibrio cholerae.

- f) Seafood, particularly crustaceans, and other shellfish, taken from contaminated water and eaten raw or insufficiently cooked or contaminated during preparation.

- g) Fruits and vegetables grown in wetlands or preserved/stored in drainage channels (common in urban areas flooded with sewage).

###### 8.2.1.1.2 Food handling and hygiene practices

- a) Wash hands before during and after handling of food.

- b) Not mixing raw food with ready to eat food.

- c) Conduct regular medical and physical examination of food handlers.

- d) Food handlers should always be in clean uniform.

- e) Regulation of food handlers (abolish food hawking).

- f) All food eating places that do not meet the minimum public health standards should be closed.

- g) All food establishments should have cold and hot water which is safe to use.

- h) Regular inspection of food eating premises and food markets. i) Avoid communal eating during outbreaks.

###### 8.2.1.1.3 Infant Feeding

- Breast feeding should be continued even when an infant has cholera.

- Feeding utensils for infants should be kept clean and sterile at all times.

- Breastfeeding mothers should keep proper hygiene.

- Ensure proper hand washing in all the recommended stages of preparing infant food.

<!-- Source PDF page 129 -->

###### ❖ Proper cooking of infant food.

### 8.3 Personal and Household Hygiene

#### KEYWORDS

Hand Washing, safe disposal of Faecal matter, Keeping Homes Clean, sanitation and hygiene in public places

#### 8.3.1 Useful Information

Personal and household hygiene is an important aspect for prevention and control of cholera. Communities need to keep their bodies and surroundings clean. They should also construct and use hand washing facilities like tippy taps.

Gathering available information on current personal and family hygiene, knowledge and practices by the local and district leaders is very useful for successful intervention.

#### 8.3.2 Priority Interventions

##### 8.3.2.1 Personal and Household Hygiene

Promotion of personal and household hygiene is important in cholera prevention.

Emphasis should be put on households, public places (markets, food vendors, restaurants, hotels, Car parks, and recreation centers) institutions (schools, health facilities, and barracks).

It is important for communities to construct and use hand washing facilities with soap/detergents for hand washing at critical times such as:

- i. After visiting the latrine

- ii. After cleaning baby’s bottom

<!-- Source PDF page 130 -->

- iii. After cleaning infected surface(s)/article(s)

- iv. Before and after eating

- v. Before preparing food.

Simple observations of hygiene practices in the home may be obtained by a few site visits to selected areas. Emphasis should be on:

- i. Availability of functional hand washing facilities.

- ii. Presence of water and soap/detergent.

- iii. Evidence of use of hand washing facilities.

###### 8.3.2.1.1 Communal hand washing

Community members washing hands in a common container should be discouraged. This practice promotes spread of infection by progressively making the water contaminated. The first person is safe but the subsequent users are not.

Options for example to communal hand washings such as tippy tap, stand tap, jerry can with a tap, etc., that promote hand-washing with running water should be encouraged for usage.

### 8.4 Sanitation

#### KEYWORDS

Improved Sanitation, Education on Hygiene, behavioural change, and Latrine Use, open defecation, Open Defecation Free communities, Community Led Total Sanitation

#### 8.4.1 Useful Information

Vibrio cholerae organisms are found in faeces of an infected person or a carrier. The proper disposal of faecal matter will reduce the transmission of the organism. Construction and proper use of latrine is key in preventing the spread of the infection.

<!-- Source PDF page 131 -->

Authorities at all levels must have an updated inventory of existing sanitary facilities for planning and evaluation of the disease transmission risks.

Approaches which ignite change in sanitation behavior rather than constructing latrines for individual households should be promoted, for example Community-Led Total Sanitation (CLTS), Participatory Hygiene and Sanitation Transformation (PHAST), among others.

#### 8.4.2 Priority Interventions

##### 8.4.2.1 Improvement of Sanitation

The population should have access to an improved sanitation facility such as flush and pour flush toilets, ventilated improved latrine, traditional improved pit latrine, ecosan latrine. Where sewerage systems exist, efforts should be made to connect households to a public sewer. Households may also be encouraged to have septic tanks that will be periodically drained and taken to the sewage treatment plants.

Environmental health officers are charged with the responsibility of guiding the communities on construction of appropriate sanitation technologies that suit the specific areas **_(refer to annex for a demo of the appropriate technologies)._**

Kampala Declaration on Sanitation (KDS) https://www.ircwash.org/sites/default/files/824-UG-14784.pdf should be implemented by all districts and leaders. The need for exemplary leadership at all levels is emphasized.

Unimproved sanitation facilities such as bucket latrines, traditional pit latrines, hanging latrines and trench latrines should be replaced as soon as possible with improved sanitation facilities.

<!-- Source PDF page 132 -->

Interventions to improve sanitation and hygiene should bring on board the following ministries/sectors:

- i. Ministry of Education and Sports,

- ii. Ministry of Water and Environment,

- iii. Ministry of Local Government,

- iv. Office of the Prime Minister,

- v. Ministry of Gender, Labour and Social development,

- vi. Ministry of Internal Affairs,

- vii. Ministry of Foreign Affairs,

- viii. Ministry of Defense and Veteran Affairs,

- ix. Ministry of Works and Transport,

- x. Ministry of Urban Planning and Development,

- xi. Ministry of Agriculture, Animal Industries and Fisheries

- xii. Private sectors.

Sanitation in urban areas should address aspects of safe water supply and safe excreta disposal, solid waste management and proper management of drainage channels.

Special focus should be given to slums, markets, parks, schools, day care centers, commercial buildings and other crowded places.

Environmental health teams should always provide regular reports for both latrine and hand washing facility coverage in their jurisdictions.

Public places such as places of worship, markets, institutions of learning, among others should have convenient and accessible recommended sanitary and functional hand washing facilities.

VHTs and CHEWs should work hand in hand with Environmental health staff to provide updated reports on sanitation and hygiene status in their communities.

<!-- Source PDF page 133 -->

Enforcement of Public Health Act (Cap. 281) 2023 as amended, should be applied to abate nuisances for example sanitary defaulters in the community, proprietors with unsanitary effluents, accumulated wastes, among others. Both politicians and technical persons should supportive of the enforcement.

![Source illustration — PDF page 133](images/illustration-133-037.png)

![Source illustration — PDF page 133](images/illustration-133-038.png)

**_Picture 12: DHO Lamwo inspecting water sources and sanitation facilities in Agoro S/C_**

###### 8.4.2.1.1 Solid Waste Management

- There should be appropriate segregation of organic and inorganic wastes at all levels (from generation, transportation, storage, treatment and final disposal).

- Proper solid waste disposal should be practiced at all levels.

- Compositing or safe disposal of organic wastes should be practiced at all levels.

- Healthcare wastes should be appropriately segregated, stored, transported, treated and disposed off in a sanitary manner (**_refer_** **_to healthcare waste management and WASH in healthcare facilities guidelines)._**

- Periodic capacity building of healthcare workers on waste management (healthcare and municipal waste) should be conducted.

<!-- Source PDF page 134 -->

- Regular support supervisions to all waste handlers should be conducted.

- Provision of appropriate waste management facilities must be ensured at all levels for example garbage skips, color coded bins and liners.

- Appropriate personal protective equipment should be provided to all waste management handlers.

- Information Education and Communication (IEC) materials to guide the waste handlers, should be provided and utilized at all levels.

- Cholera infected items/articles for example clothes and beddings should be separately stored, disinfected and rapidly disposed off.

- Facilities, surfaces and equipment that got in contact with cholera infected waste should be decontaminated before reuse.

- Waste handling facilities such as color-coded bins and liners, wheelbarrows, and safety boxes should be sufficiently supplied for waste management.

- Coordination and collaboration with relevant authorities and partners should be observed to ensure effective waste management.

###### 8.4.2.1.2 Climate Health

- Climate-resilient sanitation and water supply facilities should be built to withstand extreme weather patterns.

- Weather patterns and water quality should be monitored to predict and prepare for potential cholera outbreaks.

- Creating awareness of community members on climate related cholera risks and promoting adaptive behaviour should be conducted.

- Implement flood control measures like drainage systems, levees, and floodwalls to prevent waterlogging and contamination.

- Implement efficient water management systems to prevent overflow and contamination of water sources during heavy rainfall.

<!-- Source PDF page 135 -->

- Watersheds and water sources must be protected from agricultural runoff, industrial and human waste effluents.

- Foster collaboration among healthcare providers, water and sanitation authorities and climate experts to ensure a unified response to climate related cholera risks.

###### 8.4.2.1.3 Community participation in preventive efforts

The community should be involved in all phases of implementation of on and off-site sanitation projects to avoid misuse or non-use of the sanitation facilities. This can be done through:

- Approaches that promote community participation and mindset change towards improvement of sanitation and hygiene should be encouraged. These include Community-Led Total Sanitation (CLTS) and Participatory Hygiene and Sanitation Transformation (PHAST).  These approaches do this through a process of social awakening.

- Local government and community leaders should support and encourage their communities to be Open defecation Free (ODF).

###### ASSESSMENT OF THE OUTBREAK RESPONSE

1. What percentage of the population was served with improved sanitation facilities?

2. Was there a good system in place for excreta management and disposal during the outbreak (latrine use, emptying and sludge removal from septic tanks)?

3. Were the sanitation facilities vulnerable to flooding or other natural disasters?

4. Do you think the available sanitation facilities could potentially contaminate the drinking- water sources?

5. Was consideration given to providing sanitation services for high- risk communities during the outbreak?

6. Were health workers properly trained to teach local people about good hygiene behaviors?

<!-- Source PDF page 136 -->

## CHAPTER NINE: OUTBREAKS IN INSTITUTIONS AND CONGESTED SETTINGS

![Source illustration — PDF page 136](images/illustration-136-039.png)

**_Picture 13: Landing sites, site such as the one in this picture require proper sanitation and hygiene measures to prevent disease outbreaks_**

![Source illustration — PDF page 136](images/illustration-136-040.png)

### 9.1 CHOLERA IN INSTITUTIONS, INTERNALLY DISPLACED PERSONS AND REFUGEE CAMPS, PRISONS, HOSPITALS, LANDING SITES ETC.

#### KEYWORDS

Overcrowding, increased interactions, slum areas, mental health units, landing sites, refugee camps, internally displaced persons, adequate WASH facilities refugee camps, internally displaced persons, adequate WASH facilities

<!-- Source PDF page 137 -->

#### 9.1.0 Useful Information

These are communities that are at high risk of rapid spread of cholera. People living in special settings mentioned below are more likely to be affected in big numbers because of the living conditions that predispose them to the infection. These places include;

- i. Camps for the Internally displaced persons and refugees

- ii. Special institutions such as schools, mental health facilities, day care facilities, babies’ homes, hostels, destitute homes, farms, prisons, army barracks and detaches and police barracks

- iii. Slums

- iv. Landing sites

- v. Border communities, among others

The underlying factors for high risk of spread in these populations are due to the;

- High degree of interactions amongst community members.

- High population density, overcrowding,

- Lack of adequate water sources,

- Poor sanitation,

- Sharing of facilities like water, latrines, eating food prepared and served from a common point

- and ill health practices like open defecation.

#### 9.1.1 Priority Interventions

##### 9.1.1.1 Measures to prevent cholera outbreaks in special settings

Once there is an outbreak of cholera, the attack rate can be as high as 5% or more in congested areas and if the community and health care system are not prepared to manage cases, case fatality rate could be as high as 50%. It is therefore important that institutions should endeavor to prevent cholera and other waterborne diseases in such communities.

<!-- Source PDF page 138 -->

Preventive interventions that should be instituted include

- Effective surveillance system.

- Health education on prevention of infection (personal, food, water safety, institutional hygiene).

- Provision of appropriate WASH infrastructure by the responsible management, e.g. appropriate toilets/latrines, hand-washing facilities, safe water, and waste management facilities.

- Routine inspection of the institutions by the environmental health officers.

###### 9.1.1.1.1 Prevention of cholera spread during and after outbreaks

The following measures should be carried out:

- Health education on prevention of infection (personal, food and institutional hygiene) and management of cases should be provided.

- The institution heads should be oriented on cholera prevention and control.

- During an outbreak, immediate reporting of the sick should be more vigorous. The leaders should encourage members to report any person with diarrhea (refer to community case definitions).

- Emergency medical examination of food handlers and health education are key in the prevention and response to cholera outbreaks.

- Measures to ensure an emergency safe water supply should be available.

- Emergency water quality monitoring and testing should be done.

- Schools should have adequate sanitation and hygiene facilities to prevent the transmission. The minimum standard for latrine stance to learners is 1:40 in a day school.

- The army and police barracks, the latrine stance ratio for the officers and their clients is 1:40.

<!-- Source PDF page 139 -->

- Separate latrine stances should be provided for males and females respectively.

- There should be provision for urinals for the male learners.

- There should be provision for stances for the students/ people with disabilities/ limited mobility.

- A functional hand-washing facility within 5m radius of each latrine block should be provided.

- For inmates in prisons, in patients and boarding schools establishments, the latrine stance ratio should be 1:25.

- Ensure safe treatment and final disposal of waste-water.

- In case a member in a community or student develops cholera, the institution must be able to provide ORS and safe drinking water to prevent dehydration.

- As soon as a person develops cholera symptoms, they should be given ORS and taken to the nearest health unit and she/he should be drinking ORS on the journey.

- After giving ORS, the cases should immediately be reported to district health authorities and referred to the nearest health facility.

- The immediate contacts should be visited by the health workers and given appropriate health education and chemoprophylaxis (selectively).

- Any identified gap should be corrected immediately.

###### 9.1.1.1.2 General interventions to control cholera in congested settings

- Mental patients are prone to cholera because of their poor hygienic conditions resulting from their poor mental state. Patients should be well screened during admission to prevent introduction of infection into the wards.

- Investigation of diarrheal cases and isolation of suspected cholera patients should be prompt and reported immediately to in charges or high authorities and proper management instituted.

<!-- Source PDF page 140 -->

##### 9.1.1.2 Mental Health Units

- Mental patients are prone to cholera because of their poor hygienic conditions resulting from their poor mental state. Patients should be well screened during admission to prevent introduction of infection into the wards.

- Investigation of diarrheal cases and isolation of suspected cholera patients should be prompt and reported immediately to in charges or high authorities and proper management instituted.

##### 9.1.1.3 Internally Displaced Persons and Refugees Camps

The factors responsible for quick spread are the same as for other categories above.  The differences are mainly in the composition of the communities (heterogeneous or mixed background –children, adults, language variation, behaviour or culture difference, among others) and organization setting.

The risks of infection spread can be minimized during the camp construction following minimal requirements as per Humanitarian Sphere standards, that is, sufficient quantity of safe water - 15 to 20 litres per person per day. This amount suffices for drinking, food preparation, personal hygiene, and washing household items.

###### Sanitation

Disposal of human excreta should be 01 latrine stance for every 20 persons. Latrine digging tools should be provided to Internally Displaced Persons (IDPs) and refugees to enable them dig their own latrine facilities.

<!-- Source PDF page 141 -->

###### General hygiene of the camp

The camp leaders should be fully involved in all stages of preparedness and response. This includes surveillance and reporting of cases, mobilizing communities and monitoring of interventions.

**Note** : Hand-washing facilities and soap; should be provided in adequate numbers to camps. The community should access these supplies at any time of the day or night.

**Detection and treatment of patients**

In case a member in the camp develops cholera, the camp leader must be able to provide ORS or safe water for drinking to prevent dehydration.

Reporting of any case with diarrhea should be done immediately to the health authorities within the camp.

Management of cholera cases should be done at a health facility within the camp if available.

##### 9.1.1.4 Slum Areas

These are areas where cholera outbreaks were previously very difficult to control. The communities are crowded, with inadequate facilities or facilities are locked during particular times like at night.

In most of these slums there may be no place to put up sanitation facilities which are important in prevention and control efforts. Most of these facilities are communally owned. The drainage systems in these areas are usually very poor and are prone to flooding.

There should be enforcement of the Public Health Act and enacting and enforcement of bye-laws on sanitation and hygiene.

<!-- Source PDF page 142 -->

##### 9.1.1.5 Landing Sites

A number of outbreaks in the recent times have been reported in landing sites. These are as a result of unavailability of/poor status of WASH facilities due to high water tables making construction of latrines extremely difficult and expensive. Very often there is use of community latrine (which may be closed off in the evening) with open defecation as a practice.

There is a need to closely work with the urban authority for slums and Beach Management Units (BMU) for the landing sites to ensure appropriate intervention such as provision of public latrines, chlorination of the water for drinking, ensuring people do not settle very close to the water bodies among others. Local leaders can enact bye laws to reinforce these measures.

##### 9.1.1.6 Public Health Measures for Refugees from CholeraAffected Countries

Special consideration should be made in situations where refugees and other asylum seekers enter the country from neighboring or other countries that do have active cholera outbreaks.  Below are some of the recommended public health measures;

- a) Mandatory screening for cholera and a monitoring period: Refugees from cholera-affected countries should undergo cholera screening and a minimum of one (1) month of monitoring for active or latent infection at reception centers before being relocated to resettlement areas.

- b) Segregation and Medical Prophylaxis: New arrivals should be separated from existing populations for 14 days. They should also receive a single dose of the appropriate medication as a chemoprophylactic measure.

- c) Adequate Infrastructure and Staffing: Both reception centers and receiving resettlement camps must have adequate infrastructure and staffing including;

<!-- Source PDF page 143 -->

- Trained staff to handle infectious cases

   - Isolation facilities to separate and manage suspected or confirmed cholera cases

   - Essential medical supplies and equipment for prompt treatment and management

- d) Ensuring Adequate WASH Conditions: Ensure that Water, Sanitation, and Hygiene (WASH) conditions at reception centers, transit and resettlement camps meet the minimum recommended standards for health and disease prevention, including:

   - Access to safe and clean water

   - Adequate sanitation facilities

   - Proper waste management

   - Hygiene promotion and education

- e) Infection Prevention and Control (IPC) Measures: Implement IPC measures to prevent the spread of cholera, including:

   - Hand washing facilities with soap and clean water

   - `o` Hand hygiene promotion and education `o` Proper use of personal protective equipment (PPE)

These measures should also be observed during the transfer of refugees from a resettlement camp with a cholera outbreak to another camp with no cholera should such a need arise.

The key public health measures below are recommended for stakeholders involved in refugee populations with emphasis put on refugees/ asylum seekers travelling into the country from cholera affected countries;

**At Point of Entry (POEs)**

- Health screening stations: Set up designated areas for refugees to undergo health checks as soon as they arrive at the point of entry

- Symptom screening: all incoming refugees/asylum seekers from cholera affected countries should be screened for symptoms and

<!-- Source PDF page 144 -->

signs of cholera, which include acute watery diarrhea, vomiting, dehydration. This can be done through observation and brief interviews about any symptoms.

- Conduct Cholera Rapid diagnostic test (RDT) screening for all incoming persons with diarrheal symptoms

- Sample collection from all suspected cholera cases for laboratory testing for confirmation of cholera disease

- Isolation/treatment facilities; all points of entry should have isolation areas where suspected cholera cases are isolated and treated.

- Case management supplies: Ensure that the point of entry teams are trained on current cholera guideline and they have access to necessary case management supplies, including oral rehydration salts (ORS), antibiotics, and IV fluids for severe cases

- Health information and education: Display cholera IEC materials and use oral communication to educate refugees upon arrival about cholera and the importance of hygiene

- Safe drinking water: Ensure that all persons have access to safe drinking water, ideally treated with chlorine or another disinfectant.

- Sanitation facilities and practices: Ensure availability and usage of adequate sanitation facilities

- Hand hygiene: Set up handwashing stations with soap and water and encourage frequent handwashing, particularly after using the toilet or before eating.

- Continuous surveillance: Implement ongoing surveillance at the point of entry to quickly detect and respond to cholera

###### At Reception/Collection Centre

- Cholera symptom screening upon arrival

- RDT screening for cholera for all persons with diarrheal symptoms

- Designated cholera treatment units for management of suspected cholera cases

- Isolation of symptomatic and asymptomatic refugees from cholera-stricken countries for 30 days while being monitored for

<!-- Source PDF page 145 -->

active or latent infection at reception centers before being relocated to resettlement areas. Do not transport positive symptomatic cases into the resettlement areas

- Sample collection and laboratory confirmation from all suspected cholera cases

- Give recommended chemoprophylaxis for all immediate contacts and monitor them for signs and symptoms for 14 days

- Ensure the health workers working at the reception centers are trained on the latest cholera guidelines

- Sufficient case management supplies: Ensure that medical personnel have access to necessary treatment supplies, including oral rehydration salts (ORS), antibiotics, and IV fluids for severe cases

- Provide adequate supplies of safe water to all persons in the center (20 liters per day per person)

- Water treatment: Ensure that all refugees have access to safe drinking water, ideally treated with chlorine or boiled

- Sanitation facilities: Ensure each household has access to a basic sanitation facility to prevent open defecation, contamination of water sources and reduce the risk of disease transmission.

- Hand hygiene: Ensure households have handwashing stations with soap and water and              encourage frequent handwashing, particularly after using the toilet or before eating

- Restriction of interaction between the refugees in isolation and the host community.

###### While In Transit

- Ensure that persons/refugees are not transferred from collection centres, or reception centers or between settlements before completion if the 30 days’ mandatory observation period,

- Refugees should not be moved from collection centres, or reception centres or between settlements when they are case of suspected cholera among them

- Ensure adequate hand washing facilities before, during and upon arrival to the new destination. Refugees should hand wash adequately as they enter the vehicles, at any point when they stop

<!-- Source PDF page 146 -->

over along the movement including when crossing districts and upon arrival as they disembark from the vehicles

- Ensure access to safe drinking water: Ensure that all refugees have access to safe drinking water, ideally treated with chlorine or boiled while in transit

- Access to ssanitation facilities: Ensure access to adequate sanitation for the travelers along the transit to prevent open defecation.

- Special attention be given to mothers with in transit with children who may defecate along the movement routes in nappies. Care must be taken to ensure that such contaminated nappies are safely disposed off and are not scatted careless along the movement.

###### Upon Arrival at Refugee Settlement

- Ensure that isolation period of 30 days has been adhered to prior to transfer to the settlement

- A designated health facility (CTU) should be identified for isolation and management of cholera suspects

- Provide adequate supplies of safe water (20 liters per day per person)

- Sample collection and laboratory confirmation from all suspected cholera cases

- Give recommended chemoprophylaxis for all persons

- Ensure the health workers working at the health facilities in the settlement are trained on the latest cholera guidelines

- Sufficient case management supplies: Ensure that medical personnel have access to necessary treatment supplies, including oral rehydration salts (ORS), antibiotics, and IV fluids for severe cases

- Provide adequate supplies of safe water to all persons in the center (20 liters per day per person)

- Water treatment: Ensure that all refugees have access to safe drinking water, ideally treated with chlorine or boiled

<!-- Source PDF page 147 -->

- Sanitation facilities: Ensure each household has access to a basic sanitation facility to prevent open defecation, contamination of water sources and reduce the risk of disease transmission.

- Hand hygiene: Ensure households have handwashing stations with soap and water and encourage frequent handwashing, particularly after using the toilet or before eating.

- Monitoring in refugee camps: Once refugees enter the country and are settled in camps, provide continuous health education on cholera in the communities, continue monitoring their health for signs of cholera, and maintain water and sanitation standards.

- Public health follow-up: Ensure that any individuals that may subsequently become exposed to cholera within the settlement are quickly detected and linked to health care services as soon as possible.

<!-- Source PDF page 148 -->

## CHAPTER TEN: ROLE OF ORAL CHOLERA VACCINE (OCV)

![Source illustration — PDF page 148](images/illustration-148-041.png)

![Source illustration — PDF page 148](images/illustration-148-042.png)

**USE OF ORAL CHOLERA VACCINES (OCV) FOR CHOLERA PREVENTION**

**KEY WORDS** Oral Cholera Vaccines (OCV), Hotspots, WASH Promotion Integrated Approach, OCV Campaign, High risk communities

### 10.0 Useful Information

Vaccination with Oral Cholera Vaccine (OCV) is an additional intervention for prevention and control of cholera outbreaks.

Targeted mass vaccination in cholera high risk communities is useful in preventing recurrent outbreaks.

<!-- Source PDF page 149 -->

Vaccination is an important supplementary intervention for cholera prevention and control in endemic settings with well-defined cholera hotspots.

Vaccination with OCV does not replace existing priority prevention and control measures. The addition of vaccination with OCV in cholera response should be assessed and recommended by the National Cholera Taskforce to achieve the maximum impact.

While OCV is useful before and during cholera outbreak, it is preferable that risk assessments and the preventive vaccination campaigns are implemented.

### 10.1 Priority Interventions

#### 10.1.1 Types of OCVs prequalified for use by WHO

The following are the current prequalified OCVs by WHO. They consist of inactivated (killed) whole cells of V. cholerae

1. Dukoral (Crucell Sweden AB) consists of killed whole cells of _V. cholerae_ serogroup O1 and a recombinant B subunit of the cholera toxin. The cholera toxin component also helps the vaccine provide short-term protection against enterotoxigenic Escherichia coli (for around 3 months).

2. Shanchol (Shantha Biotechnics, India) contains killed whole cells of _V. cholerae_ serogroups O1 and O139 and is currently provided in single-dose vials.

3. Euvichol-Plus (Eubiologics, Republic of Korea) is identical to Shanchol: inactivated oral cholera vaccine protective against both _V.cholerae_ serotypes O1 and O139. Administered in 2 doses, 2 weeks to 6 months apart.

4. Euvichol-S: simplified version of Euvichol-Plus that is more costeffective and easier to produce. It contains five inactivated strains of _V. cholerae_ and is an inactivated whole-cell vaccine that is protective against serogroups O1

<!-- Source PDF page 150 -->

For optimum protection, two doses should be administered, two weeks to six months apart.

Conducting OCV campaign is an expensive approach to cholera prevention and control. The average cost per fully immunized individual is US Dollars 10.

##### 10.1.1.1 Target population for vaccination

People living in high-risk areas where assessment has shown that use of OCV vaccination campaign will be beneficial in prevention of cholera outbreaks.  All persons 1 year and above, including pregnant women are eligible to receive OCV.

###### Decision to use OCV

The decision to use OCV for cholera control will involve the National Cholera Task Force. The decision will be based on the findings of a detailed risk assessment to identify circumstances in which the timely use of OCV will yield the maximum impact, i.e.,

###### High risk areas (hotspots)

High risk populations or high-risk groups. Currently the national data show that the fishing villages, refugees and border communities are high risk groups.

Ministry of Health should keep a contingency stock of OCV for rapid deployment when there is need.

The use of OCV will NOT be at the expense of other priority health interventions (WASH, Case management, surveillance, social mobilization, among others.)

The existing surveillance system should be maintained and reinforced.

<!-- Source PDF page 151 -->

![Source illustration — PDF page 151](images/illustration-151-043.png)

###### Figure 10: Decision making tree for OCV use

#### 10.1.2 Resource mobilization and allocation during planning of OCV Campaign

During planning process and resource allocation, emphasis should be put on integrated approach to cholera prevention as illustrated in the figure below:

<!-- Source PDF page 152 -->

![Source illustration — PDF page 152](images/illustration-152-044.png)

**Figure 11: An integrated approach leads to synergistic cholera prevention and control**

A comprehensive work plan and budget should be developed and interventions apportioned funds as above. A campaign which does not cater for all other interventions should not be implemented since OCV only supplements the others.

#### 10.1.3 Importance of integrated approach for cholera control using OCV

- An integrated approach ensures a holistic coverage of cholera prevention and control interventions

- Vaccination alone does not provide a community with complete protection from cholera because the protection is not life-long.

<!-- Source PDF page 153 -->

- In addition, not everyone in the community will be vaccinated; herd immunity may not be achieved if coverage rates are lower than 70%.

- Other control measures such as water and sanitation improvements are the pillars of cholera prevention and increase the effectiveness of cholera vaccination and vice versa.

#### 10.1.4 Campaign timing and scheduling

- Ideally, preventive vaccination campaigns in endemic areas should take place before the cholera forecast.

- Vaccinated persons should receive a card for easy identification and follow up **(Annex 14).**

- The coverage for a given vaccination point should be computed from a tally sheet using the population of the vaccinated divided by eligible persons for vaccination times 100%. The sample tally sheet for OCV is attached, **(Annex 15).**

#### 10.1.5 OCV delivery strategies and sites

There are three strategies that can be used namely:

1. Use of permanent facilities. Fixed-site facilities such as health centers.

2. Outreach. Mobile teams set up temporary vaccination sites in schools, churches, camps, markets, among others.

3. Door-to-door delivery. This strategy gives high vaccination coverage but is time-consuming and costly.

#### 10.1.6 Organizing OCV vaccination site

- The sites should be organized to avoid excess crowding and long queues, and to ensure an efficient flow of people.

- Required Furniture

   - Two (2) tables (one for the registrar and one for the vaccinator) and three (3) chairs

<!-- Source PDF page 154 -->

- Additional seating (e.g., benches, mats to be used by caretakers/children, pregnant women and elderly people)

- Required Supplies:

   - Banner/posters to identify the site on the outside

   - Vaccine carriers

   - Safety boxes, trash bags, bins for other waste.

   - Vaccination cards, tally sheets and pens/pencils.

   - Health education materials such as wall posters and leaflets on cholera prevention.

   - WASH commodities such as soap or chlorine tablets, as available, to give to vaccine recipients.

- **Human Resource**

   - 1) Crowd controller, 2) registrar, 3) vaccinator, 4) an additional person to provide health education messages and materials, as available, and to be alert to anyone experiencing an adverse event. At least three people are needed at each site as in the picture below. The roles of each is in **Annex 16.**

##### Typical Layout of the vaccination site

![Source illustration — PDF page 154](images/illustration-154-045.png)

**_Figure 12: organization of the OCV vaccination site_**

<!-- Source PDF page 155 -->

#### 10.1.7 Storing and transporting the vaccines

OCVs should be kept at 2–8°C at all times, including when in transport, storage, and when used at a vaccination session. **Note:** Vaccines should also be monitored according to the manufacturer’s instructions.

OCV should never be frozen. Any frozen OCV vials must be discarded. The vaccinator should check the vaccine vial monitor (VVM) for vaccines that have been exposed to too much heat (stage 3 and above) and have them discarded

**Note** :  The “shake test” used for some vaccines, such as pneumococcal conjugate vaccine, does not work for OCV.

#### 10.1.8 Recording and completing the tally sheets

At the end of each vaccination session, the registrar should complete the Tally Sheet with information about the number of doses received, the number used, the number remaining, and information about any vials with VVMs that have changed color.

#### 10.1.9 Monitoring and reporting of adverse events

Like for any other vaccine, adverse events with OCV are possible.

Adverse event surveillance normally starts when the first vaccinations are given and lasts for 14 days following the campaign.

The vaccinator or health educator should tell everyone receiving the vaccination;

That an adverse event is possible but rare. Some of these may include: stomach upset, diarrhea, nausea and vomiting but these are almost mild and do not last very long.

<!-- Source PDF page 156 -->

If they experience an adverse event, they should immediately seek care at the nearest health facility.

   - **ASSESSMENT OF OCV DURING THE RESPONSE** Was risk assessment conducted prior to OCV?

1. Was implementation of WASH promoted before considering the use of OCV?

2. Was the decision tree followed in deciding to implement OCV campaign?

3. Did the team consider the cost of OCV vs the promotion of WASH?

4. Was an integrated plan for the campaign developed and resource apportioned as recommended?

5. Was monitoring and reporting of adverse events following vaccination done?

6. Were vaccines and waste material handled as recommended?

<!-- Source PDF page 157 -->

## Annexes

### ANNEX 1: CHOLERA CASE INVESTIGATION FORM

![Complete annex content — PDF page 157](images/annex-source-page-157.png)

<!-- Source PDF page 158 -->

![Complete annex content — PDF page 158](images/annex-source-page-158.png)

<!-- Source PDF page 159 -->

![Complete annex content — PDF page 159](images/annex-source-page-159.png)

<!-- Source PDF page 160 -->

![Complete annex content — PDF page 160](images/annex-source-page-160.png)

<!-- Source PDF page 161 -->

![Complete annex content — PDF page 161](images/annex-source-page-161.png)

<!-- Source PDF page 162 -->

![Complete annex content — PDF page 162](images/annex-source-page-162.png)

<!-- Source PDF page 163 -->

### ANNEX 2: CHOLERA CASE SURVEILLANCE FORM (LINE LIST)

![Complete annex content — PDF page 163](images/annex-source-page-163.png)

<!-- Source PDF page 164 -->

### ANNEX 3: CHOLERA CONTACT TRACING FORM

![Complete annex content — PDF page 164](images/annex-source-page-164.png)

<!-- Source PDF page 165 -->

### ANNEX 4: A FILLED SITUATION REPORT TEMPLATE

![Complete annex content — PDF page 165](images/annex-source-page-165.png)

<!-- Source PDF page 166 -->

![Complete annex content — PDF page 166](images/annex-source-page-166.png)

<!-- Source PDF page 167 -->

### ANNEX 5: CHOLERA STANDARD LABORATORY INVESTIGATION FORM

![Complete annex content — PDF page 167](images/annex-source-page-167.png)

<!-- Source PDF page 168 -->

![Complete annex content — PDF page 168](images/annex-source-page-168.png)

<!-- Source PDF page 169 -->

![Complete annex content — PDF page 169](images/annex-source-page-169.png)

<!-- Source PDF page 170 -->

### ANNEX 6: SUB-COMMITTEES OF THE DISTRICT TASK FORCE AND THEIR TEAM HEADS/CHAIRPERSONS

![Complete annex content — PDF page 170](images/annex-source-page-170.png)

<!-- Source PDF page 171 -->

### ANNEX: 7: A CHECKLIST OF THE REQUIRED ACTIONS FOR CHOLERA PREVENTION AND CONTROL

![Complete annex content — PDF page 171](images/annex-source-page-171.png)

<!-- Source PDF page 172 -->

![Complete annex content — PDF page 172](images/annex-source-page-172.png)

<!-- Source PDF page 173 -->

### ANNEX 8: NATIONAL CHOLERA KIT FOR 100 PATIENTS AND CONTACTS

![Complete annex content — PDF page 173](images/annex-source-page-173.png)

<!-- Source PDF page 174 -->

### ANNEX 9: END OF CHOLERA OUTBREAK REPORT TEMPLATE

![Complete annex content — PDF page 174](images/annex-source-page-174.png)

<!-- Source PDF page 175 -->

### ANNEX 10: CHOLERA PATIENT MONITORING (OBSERVATION) FORM

![Complete annex content — PDF page 175](images/annex-source-page-175.png)

<!-- Source PDF page 176 -->

### ANNEX 11: CHOLERA TREATMENT UNIT (CTU)

![Complete annex content — PDF page 176](images/annex-source-page-176.png)

<!-- Source PDF page 177 -->

![Complete annex content — PDF page 177](images/annex-source-page-177.png)

<!-- Source PDF page 178 -->

### ANNEX 12: CTU PATIENT EVALUATION FORM

![Complete annex content — PDF page 178](images/annex-source-page-178.png)

<!-- Source PDF page 179 -->

### ANNEX 13: PREPARATION AND USE OF CHLORINE DISINFECTANTS

![Complete annex content — PDF page 179](images/annex-source-page-179.png)

<!-- Source PDF page 180 -->

### ANNEX 14: ORAL CHOLERA VACCINE CARD SAMPLE

![Complete annex content — PDF page 180](images/annex-source-page-180.png)

<!-- Source PDF page 181 -->

### ANNEX 15: ORAL CHOLERA VACCINE TALLY SHEET

![Complete annex content — PDF page 181](images/annex-source-page-181.png)

<!-- Source PDF page 182 -->

### ANNEX 16: ROLES AND RESPONSIBILITY OF MEMBERS OF THE VACCINATION TEAM

![Complete annex content — PDF page 182](images/annex-source-page-182.png)

<!-- Source PDF page 183 -->

### ANNEX 17: EXCERPT OF THE KAMPALA DECLARATION ON SANITATION, 1997 (KDS) RESOLUTIONS

![Complete annex content — PDF page 183](images/annex-source-page-183.png)
