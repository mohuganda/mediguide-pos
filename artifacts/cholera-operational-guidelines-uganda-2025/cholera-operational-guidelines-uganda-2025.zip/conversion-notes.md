# Conversion Notes

Source: Prevention, Control and Elimination of Cholera_ Operational Guidelines for National and District Health Workers and Planners_2025.pdf.

All 183 PDF pages are represented in source-page comments. The PDF, rather than the partial pasted extraction, was used as the source. The cover title, subtitle, attribution and year were checked visually.

The document contains ten chapters and seventeen annexes. There is one H1 title, H2 chapters and front matter, and nested numbered sections up to H6. Repeated headers and footers are excluded; lists and simple tables are formatted as Markdown. Original spelling, clinical recommendations, quantities and source discrepancies have not been intentionally changed. This is a formatting conversion, not clinical approval.

The complete content of all annexes (PDF pages 157–183) is preserved as high-resolution page images, including investigation forms, laboratory forms, checklists and treatment-unit layouts. These pages are not searchable Markdown transcriptions. This avoids silently losing merged cells, field positions or image-only text. Diagrams throughout the chapters are included as images. Additional source-page images are provided where table structure or text coverage needed a fallback: none.

Keep the images folder beside the Markdown file. The ZIP includes the Markdown, these notes and only the referenced assets. For MediGuide publication, import image files as managed assets, replace local image references with managed URLs, regenerate the structured projection, and complete clinical and figure review. Source page comments do not establish verified clinical PDF mappings automatically.
